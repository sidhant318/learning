package com.udemy.springcloudconfigserver.controller;

public class ConfigController {

}
