package com.auth.Authorization1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Authorization1Application {

	public static void main(String[] args) {
		SpringApplication.run(Authorization1Application.class, args);
	}

}
