package com.udemy.limitsservice;

public class Ass {
	static class Node{
		int data;
		Node next;
		Node(int data){
			this.data=data;
			this.next=null;
		}
	}
	Node head,tail;
	public static void main(String[] args) {
		Ass a=new Ass();
		a.add(10);
		a.add(20);
		a.add(30);
		a.add(40);
		a.append(50);
		a.append(60);
		a.delete();
		a.print();
	}
	private void delete() {
		if(head==null)
			return;
		head=head.next;
		tail.next=head;
		
	}
	private void append(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=tail=n;
			n.next=head;
			return;
		}
		tail.next=n;
		tail=n;
		tail.next=head;
	}
	private void print() {
		Node tmp=head;
		if(head==null)
			return;
		do {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
		while(tmp!=head);
	}
	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=tail=n;
			n.next=head;
			return;
		}
		n.next=head;
		head=n;
		tail.next=head;
	}

}
