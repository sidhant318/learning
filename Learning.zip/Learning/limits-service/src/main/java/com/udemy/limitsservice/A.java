package com.udemy.limitsservice;

import java.util.ArrayList;
import java.util.List;

public class A {

	 static List<String> list = new ArrayList<String>(); 
	  
	 public static void main(String args[]) throws Exception 
	     { 
	         Integer[] array = new Integer[1000000 * 1000000* 1000000]; 
	     } 

}
