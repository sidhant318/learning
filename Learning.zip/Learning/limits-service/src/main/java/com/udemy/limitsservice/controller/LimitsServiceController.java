package com.udemy.limitsservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.udemy.limitsservice.bean.LimitConfiguration;
import com.udemy.limitsservice.config.Configuration;

@RestController
public class LimitsServiceController {
	
	@Autowired
	private Configuration config;
	
	@GetMapping("/limits")
	public LimitConfiguration retriveConfigurationLimit() {
		return new LimitConfiguration(config.getMinimum(),config.getMaximum());
	}

}
