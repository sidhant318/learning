package com.example.test1;

public class GetApplicationResponse {
	String hId;
	String hName;
	GetApplicationResponse(){
		
	}
	GetApplicationResponse(String hId,String hName){
		this.hId=hId;
		this.hName=hName;
	}
	public String gethId() {
		return hId;
	}
	public void sethId(String hId) {
		this.hId = hId;
	}
	public String gethName() {
		return hName;
	}
	public void sethName(String hName) {
		this.hName = hName;
	}
	

}
