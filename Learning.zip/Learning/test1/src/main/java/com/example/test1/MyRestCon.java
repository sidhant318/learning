package com.example.test1;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;



@RestController
public class MyRestCon {
	
	
	@PostMapping("/connection")
		public ResponseEntity createExposedTunnelConnection(
				@RequestBody @Valid ExposedConnectionRequest exposedconnectionRequest,
				@RequestHeader(value= "user_email") String userEmail) {
		System.out.println("-----------------------------------------------");
		System.out.println("-----------------------------------------------");
		ExposedConnectionRequest e=new ExposedConnectionRequest();
		e.setAsset_id("10");
		e.setAppl_instance_name("RDP");
		String url = "http://localhost:8080/internal/assetId/"+e.getAsset_id()+"/appName/"+e.getAppl_instance_name();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Map> entity = new HttpEntity<>(headers);
		
		ResponseEntity<Map> response=new RestTemplate().exchange(url,
					HttpMethod.GET, entity, Map.class);
		Map<String, Object> map=response.getBody();
		System.out.println("-----------------------------------------------");
		System.out.println("-----------------------------------------------");
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		if(map.containsKey("appResponse")) {
			System.out.println(map.get("appResponse"));
			GetApplicationResponse res=mapper.convertValue(map.get("appResponse"), GetApplicationResponse.class) ;
			System.out.println(res.gethId());
		}
		if(map.containsKey("deviceResponse")) {
			GetDeviceResponse d=mapper.convertValue(map.get("deviceResponse"), GetDeviceResponse.class) ;
			System.out.println(map.get("deviceResponse"));
		}
		
		System.out.println("-----------------------------------------------");
		System.out.println("-----------------------------------------------");
		System.out.println("-----------------------------------------------");
		System.out.println("-----------------------------------------------");
		
					return ResponseEntity.accepted().build();
			
		}



}
