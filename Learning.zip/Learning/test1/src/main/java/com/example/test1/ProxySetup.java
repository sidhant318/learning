package com.example.test1;

import java.util.ArrayList;
import java.util.List;

public class ProxySetup {
	private List<UdpBinding> udpBindings;

	public List<UdpBinding> getUdpBindings() {
		return udpBindings;
	}

	public void setUdpBindings(List<UdpBinding> udpBindings) {
		this.udpBindings = udpBindings;
	}

	private Integer idleTimeoutSec;
	private String errorHandling;

	// Getter Methods

	public Integer getIdleTimeoutSec() {
		return idleTimeoutSec;
	}

	public String getErrorHandling() {
		return errorHandling;
	}

	// Setter Methods

	public void setIdleTimeoutSec(Integer idleTimeoutSec) {
		this.idleTimeoutSec = idleTimeoutSec;
	}

	public void setErrorHandling(String errorHandling) {
		this.errorHandling = errorHandling;
	}
}
