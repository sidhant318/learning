package com.example.test1;

public class PFPojo {
	 private String linkType;
	 private String ownerUrn;
	 private String targetUrn;
	 private String ownerMailbox;
	 private String targetMailbox;
	 ProxySetup proxySetupObject;


	 // Getter Methods 

	 public String getLinkType() {
	  return linkType;
	 }

	 public String getOwnerUrn() {
	  return ownerUrn;
	 }

	 public String getTargetUrn() {
	  return targetUrn;
	 }

	 public String getOwnerMailbox() {
	  return ownerMailbox;
	 }

	 public String getTargetMailbox() {
	  return targetMailbox;
	 }

	 public ProxySetup getProxySetup() {
	  return proxySetupObject;
	 }

	 // Setter Methods 

	 public void setLinkType(String linkType) {
	  this.linkType = linkType;
	 }

	 public void setOwnerUrn(String ownerUrn) {
	  this.ownerUrn = ownerUrn;
	 }

	 public void setTargetUrn(String targetUrn) {
	  this.targetUrn = targetUrn;
	 }

	 public void setOwnerMailbox(String ownerMailbox) {
	  this.ownerMailbox = ownerMailbox;
	 }

	 public void setTargetMailbox(String targetMailbox) {
	  this.targetMailbox = targetMailbox;
	 }

	 public void setProxySetup(ProxySetup proxySetupObject) {
	  this.proxySetupObject = proxySetupObject;
	 }
	}
	
