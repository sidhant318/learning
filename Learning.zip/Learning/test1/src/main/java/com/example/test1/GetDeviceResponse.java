package com.example.test1;

public class GetDeviceResponse {
	
	private String id;
	private String device_name;
	
	GetDeviceResponse(){
		
	}
	GetDeviceResponse(String id,String device_name,String device_type){
		this.id=id;
		this.device_name=device_name;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDevice_name() {
		return device_name;
	}
	public void setDevice_name(String device_name) {
		this.device_name = device_name;
	}
	
	

}
