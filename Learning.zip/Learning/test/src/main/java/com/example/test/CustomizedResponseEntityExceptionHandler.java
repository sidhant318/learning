package com.example.test;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestController
@RestControllerAdvice(assignableTypes = MyCon2.class)
public class CustomizedResponseEntityExceptionHandler{

  @ExceptionHandler(value=StudentNotFoundException.class)
  public ErrorDetails2 handleUserNotFoundException(StudentNotFoundException ex) {
	  ErrorDetails2 errorResponse = new ErrorDetails2();
		Errors error=new Errors();
		error.setMessage(ex.getMessage());
		error.setCode("CON2001");
		MessageParameters messageParameter=new MessageParameters();
		MessageParameters[] messageParameters=new MessageParameters[] { messageParameter};
		error.setMessageParameters(messageParameters);
		Errors[] errors=new Errors[] {error};
		errorResponse.setErrors(errors);
		return errorResponse;
  }
  
	@ExceptionHandler(value = MethodArgumentNotValidException.class)
	public ErrorDetails2 handleException(MethodArgumentNotValidException exception) {
		System.out.println("------------++++++++++------------");
		BindingResult bindingResult = exception.getBindingResult();
		System.out.println("set Message"+bindingResult.getFieldError().getDefaultMessage());
		System.out.println("set code" + bindingResult.getFieldError().getCode());
		System.out.println("Name "+bindingResult.getFieldError().getField());
		System.out.println("value "+String.valueOf(bindingResult.getFieldError().getRejectedValue()));
		
		return null;
	}
}