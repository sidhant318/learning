package com.example.test;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestController
@RestControllerAdvice(assignableTypes = MyCon.class)
public class CustomizedResponseEntityExceptionHandler2{

  @ExceptionHandler(value=StudentNotFoundException.class)
  public ErrorDetails handleUserNotFoundException(StudentNotFoundException ex) {
	  System.out.println("Hiiii");
    ErrorDetails errorDetails = new ErrorDetails();
    errorDetails.setDetails("----------- Testing -------- ");
    errorDetails.setMessage(ex.getMessage());
    System.out.println("----+++++--------");
    return errorDetails;
  }
}