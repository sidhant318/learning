package com.example.test;

public class ErrorDetails {
	 // private Date timestamp;
	  private String message;
	  private String details;

	  public ErrorDetails() {
	   
	  }

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}
	  
	  
}
