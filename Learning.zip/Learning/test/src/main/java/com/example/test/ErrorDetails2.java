package com.example.test;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_EMPTY)
public class ErrorDetails2 {
	 // private Date timestamp;
	private Errors[] errors;

	public Errors[] getErrors() {
		return errors;
	}

	public void setErrors(Errors[] errors) {
		this.errors = errors;
	}

	@Override
	public String toString() {
		return "ClassPojo [errors = " + errors + "]";
	}
	  
	  
}
