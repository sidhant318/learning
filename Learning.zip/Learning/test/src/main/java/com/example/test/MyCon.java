package com.example.test;

import java.rmi.StubNotFoundException;
import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyCon {
	
	@GetMapping("/internal/assetId/{assetId}/appName/{appName}")
	public Map createExposedTunnelConnection(
			@PathVariable("assetId") String assetId,
			@PathVariable("appName") String appName) {
		
		Map<String, Object> map=new HashMap<>();
		GetDeviceResponse deviceResponse = new GetDeviceResponse("abc", "test","xyz");
		map.put("deviceResponse", deviceResponse);
		GetApplicationResponse appResponse = new GetApplicationResponse("Hello","Hellllooooo");
		  map.put("appResponse", appResponse);
		  if(!map.isEmpty()) {
			  System.out.println("---------------------------------");
			  throw new StudentNotFoundException("Hello");
		  }
		  return map;
	}

}
