package com.example.test;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY)
public class Errors {
	private String code;

	private MessageParameters[] messageParameters;

	private String message;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public MessageParameters[] getMessageParameters() {
		return messageParameters;
	}

	public void setMessageParameters(MessageParameters[] messageParameters) {
		this.messageParameters = messageParameters;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "ClassPojo [code = " + code + ", messageParameters = " + messageParameters + ", message = " + message
				+ "]";
	}
}
