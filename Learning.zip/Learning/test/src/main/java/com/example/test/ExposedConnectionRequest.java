// ----------------------------------------------------------------------------
// <copyright company="Siemens AG" file="CreateConnectionRequest.java">
//   Copyright © Siemens AG 2017. All rights reserved. Confidential.
// </copyright>
// ----------------------------------------------------------------------------
package com.example.test;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class ExposedConnectionRequest {

	@NotNull
    //@Size(min = 2)
	public String asset_id;

	public String appl_instance_name;

	//public WebCredentials webCredentials;

	public String getAsset_id() {
		return asset_id;
	}

	public void setAsset_id(String asset_id) {
		this.asset_id = asset_id;
	}

	public String getAppl_instance_name() {
		return appl_instance_name;
	}

	public void setAppl_instance_name(String appl_instance_name) {
		this.appl_instance_name = appl_instance_name;
	}

	
	
	
}
