package com.myorg.conmanagement;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;

import javax.net.ssl.SSLContext;
import javax.security.cert.X509Certificate;

import org.apache.http.HttpHost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.TrustStrategy;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class ConmanagementApplication {

	public static void main(String[] args) throws RestClientException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException {
		SpringApplication.run(ConmanagementApplication.class, args);
		
		HttpHeaders headers = new HttpHeaders();
		PFPojo pfPojo = new PFPojo();
		pfPojo.setLinkType("generic-tunnel");
		pfPojo.setOwnerUrn("operator:urn:1056");
		pfPojo.setTargetUrn("device:urn:2044262717061072816");
		pfPojo.setOwnerMailbox("crspng:operator1056:1");
		pfPojo.setTargetMailbox("crspng:device2044262717061072816:1");

		UdpBinding udpBinding = new UdpBinding();

		udpBinding.setSourceAddress("localhost");
		udpBinding.setSourcePort(9090);
		udpBinding.setTargetPort(2001);

		ProxySetup proxySetup = new ProxySetup();
		proxySetup.setErrorHandling("perConnection");
		proxySetup.setIdleTimeoutSec(60);

		proxySetup.setUdpBindings(Collections.singletonList(udpBinding));
		pfPojo.setProxySetup(proxySetup);
		HttpEntity<PFPojo> entity = new HttpEntity(pfPojo, headers);
		restTemplate().postForObject("https://wssdev.crspng.com:443/ccfRest/v0/symmetric-link-factory", entity,
				String.class);
	}

	@Bean
	public static RestTemplate restTemplate() throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
		TrustStrategy acceptingTrustStrategy = (java.security.cert.X509Certificate[] chain, String authType) -> true;

		SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy)
				.build();

		SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);

		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();

		HttpClientBuilder builder = HttpClientBuilder.create();
		builder.setProxy(new HttpHost("194.138.0.25", 9400));
		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(
				builder.build());

		clientHttpRequestFactory.setHttpClient(httpClient);
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
		return restTemplate;
	}
}
