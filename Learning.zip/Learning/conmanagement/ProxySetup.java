package com.myorg.conmanagement;

import java.util.ArrayList;
import java.util.List;

public class ProxySetup {
	private List<UdpBinding> udpBindings;

	public List<UdpBinding> getUdpBindings() {
		return udpBindings;
	}

	public void setUdpBindings(List<UdpBinding> udpBindings) {
		this.udpBindings = udpBindings;
	}

	private float idleTimeoutSec;
	private String errorHandling;

	// Getter Methods

	public float getIdleTimeoutSec() {
		return idleTimeoutSec;
	}

	public String getErrorHandling() {
		return errorHandling;
	}

	// Setter Methods

	public void setIdleTimeoutSec(float idleTimeoutSec) {
		this.idleTimeoutSec = idleTimeoutSec;
	}

	public void setErrorHandling(String errorHandling) {
		this.errorHandling = errorHandling;
	}
}
