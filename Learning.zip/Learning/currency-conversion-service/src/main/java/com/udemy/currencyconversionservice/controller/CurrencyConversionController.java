package com.udemy.currencyconversionservice.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.udemy.currencyconversionservice.Bean.CurrencyConversionBean;

@RestController
public class CurrencyConversionController {
	
	@GetMapping("/currency-converter/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversionBean getCurrencyDetails(@PathVariable("from") String from,@PathVariable("to") String to,
			@PathVariable("quantity") BigDecimal quantity) {
		System.out.println("---------------");
		Map<String, String> hm=new HashMap<String, String>();
		hm.put("from", from);
		hm.put("to", to);
		System.out.println("=====");
		ResponseEntity<CurrencyConversionBean> responseEntity = new RestTemplate()
				.getForEntity("http://localhost:8081/currency-exchange/from/{from}/to/{to}", CurrencyConversionBean.class, hm);
		System.out.println("=====");
		CurrencyConversionBean response = responseEntity.getBody();
		System.out.println("=====");
		CurrencyConversionBean currencyConversionBean=new CurrencyConversionBean(
				response.getId(), from, to, response.getConversionMultiple(), quantity, 
				quantity.multiply(response.getConversionMultiple()), response.getPort());
		return currencyConversionBean;
		
	}

}
