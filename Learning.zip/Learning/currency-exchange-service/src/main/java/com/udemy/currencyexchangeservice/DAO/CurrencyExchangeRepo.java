package com.udemy.currencyexchangeservice.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.udemy.currencyexchangeservice.entity.ExchangeValue;

@Repository
public interface CurrencyExchangeRepo extends JpaRepository<ExchangeValue, Long>{

	//@Query("select * from ExchangeValue e where e.from= and e.to=")
	ExchangeValue findByFromAndTo(String from, String to);
	
	

}
