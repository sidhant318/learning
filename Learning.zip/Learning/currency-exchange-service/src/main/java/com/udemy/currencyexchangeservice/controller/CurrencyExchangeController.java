package com.udemy.currencyexchangeservice.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.udemy.currencyexchangeservice.entity.ExchangeValue;
import com.udemy.currencyexchangeservice.service.CurrencyExchangeService;

@RestController
public class CurrencyExchangeController {
	
	@Autowired
	Environment env;
	
	@Autowired
	CurrencyExchangeService currencyService;
	
	@GetMapping("/currency-exchange/from/{from}/to/{to}")
	public ExchangeValue retriveExchangeValue(@PathVariable("from") String from,@PathVariable("to") String to) {
		ExchangeValue evalue=currencyService.getconversionMultiple(from,to);
		//new ExchangeValue(1000L, from, to, BigDecimal.valueOf(65));
		evalue.setPort(Integer.parseInt(env.getProperty("local.server.port")));
		return evalue;
	}

}
