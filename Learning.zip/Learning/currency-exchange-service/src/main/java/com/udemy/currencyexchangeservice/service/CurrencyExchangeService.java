package com.udemy.currencyexchangeservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.udemy.currencyexchangeservice.DAO.CurrencyExchangeRepo;
import com.udemy.currencyexchangeservice.entity.ExchangeValue;

@Service
public class CurrencyExchangeService {

	@Autowired
	CurrencyExchangeRepo currencyExchangeRepo;
	
	public ExchangeValue getconversionMultiple(String from, String to) {
		// TODO Auto-generated method stub
		return currencyExchangeRepo.findByFromAndTo(from,to);
	}
	
	

}
