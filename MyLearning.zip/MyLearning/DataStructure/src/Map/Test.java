package Map;

import java.util.LinkedList;
import java.util.List;

public class Test {
	public static void main(String[] args) {
		List<String> l=new LinkedList<String>();
		l.add("a");
		l.add("b");
		l.add("c");
		l.add("d");
		l.add("e");
		l.add("e");
		l.add("e");
		l.add("e");
		l.add("d");
		l.add("d");
		l.add("c");
		l.add("b");
		l.add("f");
		l.add("g");
		l.add("f");
		//l.add("e");
		System.out.print(l+" ");	
		List<String> c=getShrunkArray(l,3);
		System.out.println();
System.out.print(c+" ");
	}

	private static List<String> getShrunkArray(List<String> inputArray,int burstLength) {
		boolean tap=false;
	    for(int i=0;i<inputArray.size();i++){
	        int count=1;
	        String num=inputArray.get(i);
	        int j=0;
	        for(j=i+1;j<inputArray.size();j++){
	            if(inputArray.get(j).equals(num)){
	                count++;
	            }
	            else{
	                break;
	            }
	        }
	        if(count>=burstLength){
	            for(int k=i;k<j;k++){
	                tap=true;
	                inputArray.remove(i);
	            }
	        }
	    }
	   if(tap){
	       System.out.println(inputArray.size());
	       getShrunkArray(inputArray,burstLength);
	   }

	return inputArray;
	    }
		
	}
//	
//[a, b, c, d, e, e, e, e, d, d, c, b, f, g, f, e]
//[a, b, c, c, b, f, g, f, e]
