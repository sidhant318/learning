package Map;

public class Mytesta {

	public static void main(String[] args) {
		int[] a= {1,3,4,7,9,10};
	checkMising(a);
	}

	private static void checkMising(int[] a) {
		for(int i=0;i<a.length-1;i++) {
			int tmp=a[i+1]-a[i];
			if(tmp>1) {
				for(int j=1;j<tmp;j++) {
					System.out.print(a[i]+j);
				}
			}
		}
		
	}

	private static String collapseString(String s) {
		int n = s.length();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < n; i++) {
			int count = 1;
			while (i < n - 1 && s.charAt(i) == s.charAt(i + 1)) {
				count++;
				i++;
			}
			sb.append(count + "" + s.charAt(i));
		}
		return sb.toString();
	}

}
