package Map;

import java.util.Objects;

class Entry<K,V>{
	K key;
	V value;
	Entry<K,V> next;
	public Entry(K key, V value, Entry<K, V> next) {
        this.key = key;
        this.value = value;
        this.next = next;
    }
}
public class HashMapImpl<K,V> {
	
	private Entry<K, V>[] buckets;
	private static final int INITIAL_CAPACITY =16;
	private int size = 0;
	
	public HashMapImpl(){
		
	}
	public HashMapImpl(int capacity){
		this.buckets=new Entry[capacity];
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMapImpl h=new HashMapImpl();
		System.out.println(h.hashcode("Sidhant"));
		h.put(10,20);
	}
	private void put(K key, V value) {
		Entry tmp=new Entry(key, value, null);
		int index=index(key);
		Entry<K,V> bucket=buckets[index];
		if(bucket==null) {
			buckets[index]=tmp;
		}
	}
int hashcode(K key) {
	return Math.abs(key.hashCode());
}
int index(K key) {
	return this.hashcode(key)%INITIAL_CAPACITY;
}
}
