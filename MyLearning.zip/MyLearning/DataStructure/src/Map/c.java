package Map;

@FunctionalInterface
public interface c {
	
	void show();

}
