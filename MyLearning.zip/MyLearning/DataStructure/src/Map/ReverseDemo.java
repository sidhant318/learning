package Map;

public class ReverseDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReverseDemo r=new ReverseDemo();
		String str="sidhant";
		String str1="";
		//String rev=r.reverse(str);
		//r.reverse1(str);
		//System.out.println(rev);
		System.out.println(r.reverse2(str,str1));
	}

	private String reverse2(String str,String str1) {
		if(str.length()!=0) {
			//System.out.println(str1+str.charAt(str.length()-1));
			str1=str1+str.charAt(str.length()-1);
			return reverse2(str.substring(0, str.length()-1),str1);
		}
		return str1;
	}

	private void reverse1(String str) {
		if(str.isEmpty()) {
			System.out.println(str);
		}
		else {
			System.out.print(str.charAt(str.length()-1));
			reverse1(str.substring(0, str.length()-1));
		}
		
	}

	private String reverse(String str) {
		if(str.isEmpty()) {
			return str;
		}
		System.out.println(""+str);
		return reverse(str.substring(1))+str.charAt(0);
	}

}
