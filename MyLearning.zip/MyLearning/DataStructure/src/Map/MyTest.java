package Map;

import java.util.LinkedHashMap;
import java.util.Map;

public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a=collapseString("");
		System.out.println("------");
		System.out.println(a);
	}
	
	public static String collapseString(String inputString) {
		if (inputString.isEmpty())
            return inputString;
        Map<Character, Integer> m = new LinkedHashMap<>();
        for (Character c : inputString.toCharArray()) {
            m.put(c, m.containsKey(c) ? m.get(c) + 1 : 1);
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Character, Integer> map : m.entrySet()) {
            sb.append("" + map.getValue() + map.getKey());
        }
        return sb.toString();
    }

}
