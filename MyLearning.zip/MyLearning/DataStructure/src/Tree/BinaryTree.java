package Tree;

class Node {
	int data;
	Node left, right;

	Node(int data) {
		this.data = data;
		left = right = null;
	}
}

public class BinaryTree {
	Node root;

	public static void main(String[] arg) {
		BinaryTree b = new BinaryTree();
		b.insert(1);
		b.insert(2);
		b.insert(3);
		b.insert(4);
		b.insert(5);
		b.insert(6);
		b.insert(7);
		b.print();
		System.out.println();
		b.delete(4);
		b.print();
	}

	private void delete(int data) {
		root=deleteTree(root,data);
	}

	private Node deleteTree(Node root2,int data) {
		if(root2==null) {
			return root2;
		}
		if(root2.data==data	) {
			System.out.println("-------"+data);
		}
		deleteTree(root2.right, data);
		deleteTree(root2.left, data);
		return root2;
	}

	private void insert(int i) {
		root=insertTree(root, i);
	}

	private Node insertTree(Node root2, int data) {
		if (root2 == null) {
			root2 = new Node(data);
		}
		else {
			if (root2.right==null)
				root2.right=insertTree(root2.right, data);
			else
				root2.left=insertTree(root2.left, data);
		}
		return root2;
	}

	void print() {
		printTree(root);
	}

	private void printTree(Node node) {
		if (node == null) {
			return;
		}
		printTree(node.left);
		System.out.print(node.data+" ");
		printTree(node.right);
	}
}
