package Tree;

import java.util.ArrayList;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> l=new ArrayList<>(10);
		System.out.println(l.get(5));
		HashMapList<String, Integer> m=new HashMapList<>();
		m.put("Aman", 10);
		System.out.println(m.get("Aman"));
	}

}
