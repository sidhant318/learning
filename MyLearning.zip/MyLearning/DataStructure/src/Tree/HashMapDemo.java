package Tree;


public class HashMapDemo<K,V> {
	Entry<K, V>[] buckets;
	private int initcapacity;
	
	int size=0;
	
	HashMapDemo(){
		this.initcapacity=16;
		buckets=new Entry[initcapacity];
	}
	HashMapDemo(int capacity){
		initcapacity=capacity;
		this.buckets=new Entry[initcapacity];	
	}

	public void put(K key,V value){
		Entry<K,V> e=new Entry<>(key, value, null);
		int index=index(key);
		Entry<K,V> existing=buckets[index];
		if(existing==null) {
			buckets[index]=e;
			size++;
		}
		else {
			while(existing.next!=null) {
				if(existing.key.equals(key)) {
					existing.value=value;
					return;
				}
				existing=existing.next;
			}
			if(existing.key.equals(key)) {
				existing.value=value;
				return;
			}
			else {
				existing.next=e;
				size++;
			}
		}
		
	}
	
	public V get(K key) {
		int index=index(key);
		Entry<K,V> bucket=buckets[index];
		while(bucket!=null) {
			if(bucket.key.equals(key)) {
				return bucket.value;
			}
			bucket=bucket.next;
		}
		return null;
	}
	
	public int getHash(K key) {
		return (key==null)?0:key.hashCode();
	}
	
	public int index(K key) {
		return getHash(key)%getBucketsize();
	}
	
	public int getBucketsize() {
		return this.initcapacity;
	}

}
