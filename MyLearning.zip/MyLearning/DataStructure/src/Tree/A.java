package Tree;

public class A {
	public static void main(String[] args) {
		int[] a=new int[]{1,2,3,4};
		for(int x:a) {
			System.out.print(x);
		}
		rotateLeft(a,2);
		System.out.println();
		for(int x1:a) {
			System.out.print(x1);
		}
	}

	private static void rotateLeft(int[] a,int n) {
			if ( n >= 1 )
			   {
				int tmp=a[0];
			      for(int i=0;i<a.length-1;i++) {
			    	  a[i]=a[i+1];
			    	  a[i+1]=0;
			      }
			      a[a.length-1]=tmp;
			      rotateLeft(a, n - 1 );
			   }
		}
}
