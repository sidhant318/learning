package Tree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class HashMapList<K,V> {

	List<Entry<K, V>> buckets;
	private int initcapacity;
	
	int size=0;
	
	HashMapList(){
		this.initcapacity=16;
		buckets=new ArrayList<Entry<K,V>>(initcapacity);
	}
	HashMapList(int capacity){
		initcapacity=capacity;
		buckets=new ArrayList<Entry<K,V>>(initcapacity);
	}

	public void put(K key,V value){
		Entry<K,V> e=new Entry<>(key, value, null);
		int index=index(key);
		System.out.println(index);
		System.out.println(buckets.size());
		Entry<K,V> existing=buckets.get(index);
		if(existing==null) {
			buckets.add(e);
			size++;
		}
		else {
			while(existing.next!=null) {
				if(existing.key.equals(key)) {
					existing.value=value;
					return;
				}
				existing=existing.next;
			}
			if(existing.key.equals(key)) {
				existing.value=value;
				return;
			}
			else {
				existing.next=e;
				size++;
			}
		}
		
	}
	
	public V get(K key) {
		int index=index(key);
		Entry<K,V> bucket=buckets.get(index);
		while(bucket!=null) {
			if(bucket.key.equals(key)) {
				return bucket.value;
			}
			bucket=bucket.next;
		}
		return null;
	}
	
	public int getHash(K key) {
		return (key==null)?0:key.hashCode();
	}
	
	public int index(K key) {
		return getHash(key)%getBucketsize();
	}
	
	public int getBucketsize() {
		return this.initcapacity;
	}



}
