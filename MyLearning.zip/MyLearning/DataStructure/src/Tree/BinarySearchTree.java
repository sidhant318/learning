package Tree;

public class BinarySearchTree {
	Node root;
	public static void main(String[] args) {
		BinarySearchTree bt=new BinarySearchTree();
		bt.insert(8);
		bt.insert(3);
		bt.insert(1);
		bt.insert(6);
		bt.insert(4);
		bt.insert(7);
		bt.insert(10);
		bt.insert(14);
		bt.insert(13);
		bt.print();
		bt.delete(3);
		System.out.println();
		bt.print();

	}
	private void delete(int i) {
		root=deleteTree(root,i);
	}
	private Node deleteTree(Node node, int data) {
		if(node==null) {
			return node;
		}
		if(node.data>data) {
			node.left=deleteTree(node.left, data);
		}
		else if(node.data<data) {
			node.right=deleteTree(node.right, data);
		}
		else{
			if(node.right==null || node.left==null) {
				Node tmp=null;
				tmp=node.left==null?node.right:node.left;
				if(tmp==null)
					return null;
				else
					return tmp;
			}
			else {
				Node n=sucsessor(node);
				node.data=n.data;
				node.right=deleteTree(node.right, n.data);
			}
		}
		return node;
	}
	private Node sucsessor(Node node) {
		Node tmp=node.right;
		while(tmp.left!=null) {
			tmp=tmp.left;
		}
		return tmp;
	}
	private void print() {
		printTree(root);
	}
	private void printTree(Node root2) {
		if(root2==null)
			return;
		printTree(root2.right);
		System.out.print(root2.data+" ");
		printTree(root2.left);
	}
	private void insert(int i) {
		root=insertData(root,i);
	}
	private Node insertData(Node node, int data) {
		if(node==null) {
			node=new Node(data);
		}
		else {
			if(node.data>data) {
				node.left=insertData(node.left, data);
			}
			else {
				node.right=insertData(node.right, data);
			}
		}
		return node;
	}

}
