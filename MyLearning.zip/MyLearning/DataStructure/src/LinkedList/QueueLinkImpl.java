package LinkedList;

public class QueueLinkImpl {
	Node head;
	
	private void print() {
		Node tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
		
	}
	public static void main(String[] args) {
		QueueLinkImpl queueLinkImpl=new QueueLinkImpl();
		queueLinkImpl.enqeue(10);
		queueLinkImpl.enqeue(20);
		queueLinkImpl.enqeue(30);
		queueLinkImpl.enqeue(40);
		queueLinkImpl.deEnqeue();
		queueLinkImpl.print();
	}

	private void deEnqeue() {
		if(head==null) {
			return;
		}
		
		head=head.next;
	}
	private void enqeue(int i) {
		Node n=new Node(i);
		if(head==null) {
			n.next=head;
			head=n;
			return;
		}
		Node tmp=head;
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		n.next=tmp.next;
		tmp.next=n;	
	}

}
