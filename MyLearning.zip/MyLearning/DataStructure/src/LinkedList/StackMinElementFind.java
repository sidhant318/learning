package LinkedList;

class MyNode{
	int data;
	int min;
	MyNode next;
	MyNode(int data){
		this.data=data;
		this.min=data;
		this.next=null;
	}
}

public class StackMinElementFind {
	MyNode head;
	private void peek() {
		if(head==null)
			return;
		System.out.println("Peek Data is : "+head.data);
	}
	
	private void min() {
		if(head==null)
			return;
		System.out.println("Minimum element is : "+head.min);
	}
	public static void main(String[] args) {
		StackMinElementFind elementFind=new StackMinElementFind();
		elementFind.push(10);
		elementFind.push(20);
		elementFind.push(8);
		elementFind.delete();
		elementFind.peek();
		elementFind.min();
	}

	

	private void delete() {
		head=head.next;
		
	}

	private void push(int data) {
		MyNode tmp=new MyNode(data);
		if(head==null) {
			head=tmp;
			return;
		}
			if(head.min<data) {
				tmp.min=head.min;
			}
			tmp.next=head;
			head=tmp;
	}

}
