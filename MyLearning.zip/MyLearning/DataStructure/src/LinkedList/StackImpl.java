package LinkedList;

public class StackImpl {
	int a[];
	int top,size=10;
	
	public StackImpl() {
		a=new int[size];
		top=-1;
	}

	public static void main(String[] args) {
		StackImpl impl=new StackImpl();
		impl.push(10);
		impl.push(20);
		impl.push(30);
		impl.pop();
System.out.println(impl.peek());
System.out.println(impl.top);
	}

	private void push(int i) {
		if(top>size) {
			System.out.println("overFlow");
			return;
		}
		a[++top]=i;
	}
	private void pop() {
		if(top<0) {
			System.out.println("underFlow");
			return;
		}
		top--;
	}
	private int peek() {
		if(top<0) {
			System.out.println("underFlow");
			return 0;
		}
		
		return a[top];
	}

}
