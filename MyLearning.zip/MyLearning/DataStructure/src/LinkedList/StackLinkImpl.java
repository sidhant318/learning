package LinkedList;

public class StackLinkImpl {
	Node head;
	private void print() {
		Node n=head;
		while(n!=null) {
			System.out.println(n.data);
			n=n.next;
		}
	}
	public static void main(String[] args) {
		StackLinkImpl stackLinkImpl=new StackLinkImpl();
		stackLinkImpl.push(10);
		stackLinkImpl.push(20);
		stackLinkImpl.push(30);
		stackLinkImpl.pop();
		System.out.println(stackLinkImpl.peek());
		stackLinkImpl.print();
	}
	private int peek() {
		if(head==null)
			return 0;
		return head.data;
	}
	private void pop() {
		if(head==null)
			return;
		head=head.next;
	}
	private void push(int i) {
		Node newNode=new Node(i);
		newNode.next=head;
		head=newNode;
	}

}
