package LinkedList;

class Node{
	Node prev;
	Node next;
	int data;
	Node(int data){
		this.data=data;
	}
}
public class DoubleLinkList {
	Node head;
	public static void main(String[] args) {
		DoubleLinkList doubleLinkList=new DoubleLinkList();
		doubleLinkList.add(10);
		doubleLinkList.add(20);
		doubleLinkList.append(30);
		doubleLinkList.append(40);
		doubleLinkList.InsertAfter(doubleLinkList.head.next, 8);
		doubleLinkList.delete();
		System.out.println("hii");
		doubleLinkList.print();
	}

	private void delete() {
//		Node n=head;
//		n.next.prev=head;
//		n.next=null;
		head=head.next;
	}

	private void InsertAfter(Node next, int i) {
		Node newData=new Node(i);
		newData.next=next.next;
		newData.next.prev=newData;
		newData.prev=next;
		next.next=newData;
		
	}

	private void append(int i) {
		Node newNode=new Node(i);
		if(head==null) {
			newNode.next=head;
			newNode.prev=null;
			head=newNode;
		}
		Node n=head;
		while(n.next!=null) {
			n=n.next;
		}
		n.next=newNode;
		newNode.next=null;
		newNode.prev=n;
	}

	private void add(int i) {
		Node newNode=new Node(i);
		newNode.next=head;
		newNode.prev=null;
		if(head!=null)
			head.prev=newNode;
		head=newNode;
	}

	private void print() {
		Node n=head;
		while(n!=null) {
			System.out.println(n.data);
			n=n.next;
		}
	}

	
}
