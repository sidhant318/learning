package LinkedList;

public class QueueArrayImpl {
	int size;
	int count;
	int front,rear;
	int queue[];
	QueueArrayImpl(){
		size=10;
		queue=new int[size];
		count=0;
		front=-1;
		rear=-1;
	}
	private void print() {
		for(int i=0;i<=rear;i++) {
			System.out.println(queue[i]);
		}
	}

	public static void main(String[] args) {
		QueueArrayImpl queueArrayImpl=new QueueArrayImpl();
		queueArrayImpl.enqeue(10);
		queueArrayImpl.enqeue(20);
		queueArrayImpl.enqeue(30);
		//System.out.println(queueArrayImpl.peek());
		queueArrayImpl.deEnqeue();
		queueArrayImpl.print();
	}


	private void deEnqeue() {
		if(rear<0) {
			System.out.println("under flow");
			return;
		}
		rear--;
	}
	private int peek() {
		if(rear<0) {
			System.out.println("under flow");
			return 0;
		}
		return queue[rear];
	}

	


	private void enqeue(int data) {
		if(count==0) {
			front=0;
			rear=0;
			queue[front]=data;
		}
		else if(count==size) {
			throw new ArrayIndexOutOfBoundsException();
		}
		else {
			queue[++rear]=data;
		}
		count++;	
	}

	

}
