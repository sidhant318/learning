package com.example.demo;

import java.util.Date;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.entities.Ticket;
import com.example.demo.service.TicketBookingService;

@SpringBootApplication
public class DemoApplication{

	public static void main(String[] args) {
		ConfigurableApplicationContext cac=SpringApplication.run(DemoApplication.class, args);
		TicketBookingService bookingService=cac.getBean("ticketBookingService",TicketBookingService.class);
		Ticket t=new Ticket();
		t.setPassengerName("Sidhant");
		t.setBokingDate(new Date());
		t.setEmail("abc");
		bookingService.createTicket(t);
	}
}
