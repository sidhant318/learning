package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.TicketBookingDao;
import com.example.demo.entities.Ticket;

@Service
public class TicketBookingService {
	
	@Autowired
	private TicketBookingDao bookingDao;

	public Ticket createTicket(Ticket t) {
		return bookingDao.save(t);
	}
	
	public Optional<Ticket> getTicketById(Integer tId) {
		return bookingDao.findById(tId);
	}
	
	public Iterable<Ticket> getTickets() {
		return bookingDao.findAll();
	}
	public void deleteTicket(Integer dId) {
		bookingDao.deleteById(dId);
	}
	public void updateTicket(Integer dId, String email) {
		Optional<Ticket> t=bookingDao.findById(dId);
		Ticket t1=t.get();
		t1.setEmail(email);
		bookingDao.save(t1);
	}

}
