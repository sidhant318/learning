package com.example.demo.DAO;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Ticket;

@Repository
public interface TicketBookingDao extends CrudRepository<Ticket, Integer>{

//	@Query("select t from ticket t where t.ticketId = ?1")
//	Ticket findOne(Integer tId);

	//Ticket findOne(Integer tId);
	

}
