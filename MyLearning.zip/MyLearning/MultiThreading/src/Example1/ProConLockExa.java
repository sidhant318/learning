package Example1;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class Worker{
	
	private Lock lock=new ReentrantLock();
	Condition con=lock.newCondition();
	List<Integer> l=new ArrayList<Integer>();
	static final int limit=5;
	static final int below=0;
	int num=0;
	
	public void producer() throws InterruptedException{
		while(true) {
			lock.lock();
			try {
				if(l.size()==limit)
					con.await();
				l.add(num);
					System.out.println("Adding value : "+num);
					num++;
					con.signal();
					Thread.sleep(500);
			}
			finally {
				lock.unlock();
			}
			
		}
	}
	
	public void consumer() throws InterruptedException{
		//Thread.sleep(2000);
		System.out.println("I am a consumer");
		while(true) {
			try {
				lock.lock();
				if(l.size()==below)
					con.await();
				l.remove(--num);
				System.out.println("Removing value : "+num);
				con.signal();
				Thread.sleep(500);
			}
			finally {
				lock.unlock();
			}
			//Thread.sleep(500);
		}
		
		//System.out.println("I am Again a producer");
		
	}
}
public class ProConLockExa {
	public static void main(String[] arg) {
		Worker w=new Worker();
		Thread t1=new Thread(()-> {
		try {
			w.producer();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	});
		Thread t2=new Thread(()-> {
			try {
				w.consumer();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		t1.start();
		t2.start();
	}

}
