package Example1;

import java.util.concurrent.Semaphore;

class Work{
	Semaphore s=new Semaphore(1);
	public void producer() throws InterruptedException{
		s.acquire();
		System.out.println("I am inside producer");
		s.release();
		System.out.println("I am inside a producer");
	}
	public void consumer() throws InterruptedException{
		s.acquire();
		Thread.sleep(500);
		System.out.println("I am inside producer");
		s.release();
	}
}
public class SemaphoreExample {

	public static void main(String[] args) {
		Work w=new Work();
		Thread t1=new Thread(()-> {
		try {
			w.producer();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	});
		Thread t2=new Thread(()-> {
			try {
				w.consumer();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		t1.start();
		t2.start();
	}

}
