package Example1;


import java.util.ArrayList;
import java.util.List;

class Processor{
	List<Integer> l=new ArrayList<Integer>();
	final int limit=5;
	final int bottom=0;
	int val=0;
	public void producer() throws InterruptedException{
			while(true)
			{
				synchronized (this) {
					if(l.size()==limit)
						wait();
					l.add(val);
					System.out.println("Adding value : "+val);
					val++;
					notify();
					
				Thread.sleep(500);
			}
		}
	}
	
	public void consume() throws InterruptedException{
		while(true) {
			synchronized (this) {
				if(l.size()==bottom)
					wait();
				l.remove(--val);
				System.out.println("Removing value : "+val);
				notify();
				
				Thread.sleep(500);
			}
		}
	}
}

public class ProConActualExample {

	public static void main(String[] args) {
		Processor p=new Processor();
		Thread t1=new Thread(()->{
			try {
				p.producer();
				} catch (InterruptedException e1) {
					e1.printStackTrace();}
		});
		Thread t2=new Thread(()->{
				try {
					p.consume();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
				);
		t1.start();
		t2.start();

	}

}
