package Example1;

class EvenOdd implements Runnable{
	int remainder;
	int max=20;
	static int num=0;
	static Object lock=new Object();
	EvenOdd(int remainder){
		this.remainder=remainder;
	}

	@Override
	public void run() {
		while(num<max) {
			synchronized (lock) {
				while(num%2!=remainder) {
					try {
						lock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread().getName() + " -->  " + num);
				num++;
				lock.notify();
			}
		}
	}
	
}
public class EvenOddDemo {
	public static void main(String[] args) throws InterruptedException {
		EvenOdd even=new EvenOdd(0);
		EvenOdd odd=new EvenOdd(1);
		Thread t=new Thread(even);
		Thread t1=new Thread(odd);
		t.start();
		t1.start();
		t.join();
		t1.join();
	}
}
