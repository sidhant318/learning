package Test1;

import java.util.Stack;

class MyStack {
	Stack<Integer> s;
	Integer minEle;

	MyStack() {
		s = new Stack<Integer>();
	}

	void push(int data) {
		if (s.isEmpty()) {
			minEle = data;
			s.push(data);
			return;
		}
		if (data < minEle) {
			s.push(data * 2 - minEle);
			minEle = data;
		} else {
			s.push(data);
		}
	}

	void pop() {
		if (s.isEmpty()) {
			System.out.println("Stack is empty");
			return;
		}
		int tmp = s.pop();
		if (tmp < minEle) {
			minEle = minEle * 2 - tmp;
		}
	}

	void getMin() {
		if (s.isEmpty())
			System.out.println("Stack is empty");
		else
			System.out.println("Minimum Element in the " + " stack is: " + minEle);
	}

	void peek() {
		if (s.isEmpty()) {
			System.out.println("Stack is empty ");
			return;
		}
		Integer t = s.peek();
		System.out.print("Top Most Element is: ");
		if (t < minEle)
			System.out.println(minEle);
		else
			System.out.println(t);
	}
}

public class MinStack {

	public static void main(String[] args) {
		MyStack s = new MyStack();
		s.push(3);
		s.push(5);
		s.getMin();
		s.push(2);
		s.push(1);
		s.peek();
		s.getMin();
		s.pop();
		s.getMin();
		s.pop();
		s.peek();
		s.getMin();
	}

}
