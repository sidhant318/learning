package Test1;

public class CircularLinkList {
	static class Node{
		int data;
		Node next;
		Node(int data){
			this.data=data;
			next=null;
		}
	}
	Node head;

	public static void main(String[] args) {
		CircularLinkList c=new CircularLinkList();
		c.add(10);
		c.add(20);
		c.add(30);
		c.append(40);
		c.append(50);
		c.print();
		c.isCircular();
	}

	private void isCircular() {
		Node tmp=head;
		while(tmp.next!=null && tmp.next!=head) {
			tmp=tmp.next;
		}
		System.out.println(tmp.next==head);
	}

	private void append(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			n.next=head;
			return;
		}
		Node tmp=head;
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		tmp.next=n;
		n.next=head;
	}

	private void print() {
		if(head==null)
			return;
		Node tmp=head;
		do {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
		while(tmp!=head);
	}

	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			n.next=head;
			return;
		}
		Node tmp=head;
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		n.next=head;
		head=n;
		tmp.next=head;
	}

}
