package Test1;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class PC{
	List<Integer> l=new ArrayList<Integer>();
	final int high=5;
	final int low=0;
	int val=0;
	
	void produce() {
		while(true) {
			synchronized (this) {
				if(l.size()>5) {
					try {
						wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				l.add(val);
				System.out.println(val);
				val++;
				notify();
			}
		}
	}
	
	void consume() {
		while(true) {
			synchronized (this) {
				if(l.size()==0) {
					try {
						wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				val--;
				l.remove(val);
				System.out.println(val);
				
				notify();
			}
		}
	}
}
public class CP {

	public static void main(String[] args) {
		PC p=new PC();
		Thread t=new Thread(()->p.produce());
		Thread t1=new Thread(()->p.consume());
		t.start();
		t1.start();
	}

}
