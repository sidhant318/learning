package Test1;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

class Emp implements Comparable{
	String name;
	Emp(String name){
		this.name=name;
	}
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
}
public class Test {
	static {
		System.out.println(1);
	}
	
	Test(){
		System.out.println(3);
	}
	Test(String s){
		this();
	}
	{
		System.out.println(2);
	}

	public static void main(String[] args) {
		{
			System.out.println("----------");
		}
		Test t=new Test("Hi");
		Test t1=new Test("hi");
		t.show();
		t1.show();
//		String a="x";
//		List<String> l=new ArrayList<String>();
//		l.add(a);
//		System.out.println("----"+a.hashCode());
//		System.out.println(l.get(0)+" "+l.get(0).hashCode());
//		a="y";
//		l.add(a);
//		System.out.println(a.hashCode()+" "+a);
//		System.out.println(l.get(0)+" "+l.get(0).hashCode());
//		System.out.println(l.get(01)+" "+l.get(1).hashCode());
	}
	void show() {
		System.out.println(4);
	}

}
