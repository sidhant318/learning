package Test1;

public class DoubleLinkDemo {
	static class Node{
		int data;
		Node next;
		Node prev;
		Node(int data){
			this.data=data;
			next=prev=null;
		}
	}
	Node head;
	public static void main(String[] args) {
		DoubleLinkDemo d=new DoubleLinkDemo();
		d.add(10);
		d.add(20);
		d.add(30);
		d.apend(40);
		d.apend(50);
		d.delete();
		d.print();
	}
	private void delete() {
		if(head==null)
			return;
		head=head.next;
	}
	private void apend(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			n.prev=head;
			return;
		}
		Node tmp=head;
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		tmp.next=n;
		n.prev=tmp;
	}
	private void print() {
		Node tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
	}
	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			n.prev=head;
			return;
		}
		n.next=head;
		head=n;
		n.prev=head;
	}

}
