package Test1;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class EvenOdd implements Runnable{
	int noOfThread;
	int reminder;
	final int size=20;
	static int count=0;
	static Object o=new Object();
	public EvenOdd(int noOfThread,int reminder) {
		this.noOfThread=noOfThread;
		this.reminder=reminder;
	}

	@Override
	public void run() {
		print();
	}

	private void print() {
		while(count<size) {
			synchronized (o) {
				while(count%noOfThread!=reminder) {
					try {
						o.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(count +" "+Thread.currentThread().getName());
				count++;
				o.notifyAll();
			}
		}
		
	}
	
	
	
}
public class OddEven {

	public static void main(String[] args) {
		int noOfThread=2;
		ExecutorService ex=Executors.newFixedThreadPool(noOfThread);
		for(int i=0;i<noOfThread;i++) {
			ex.submit(new EvenOdd(noOfThread,i));
		}

	}

}
