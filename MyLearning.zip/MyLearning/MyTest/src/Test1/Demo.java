package Test1;

class apple{
	static Object o=new Object();
	static Object o1=new Object();
	void show() {
		System.out.println("hii");
		synchronized (o) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				o.wait(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			synchronized (o1) {
				System.out.println("---------------");
			}
		}
	}
	
	void show1() {
		System.out.println("hellooo");
		synchronized (o1) {
			synchronized (o) {
				System.out.println("++++++++++++++++++");
			}
			o1.notifyAll();
		}
	}
}
public class Demo {

	public static void main(String[] args) throws InterruptedException {
		apple a=new apple();
		Thread t1=new Thread(()->a.show());
		Thread t2=new Thread(()->a.show1());
		t1.start();
		t2.start();
		t1.join();
		t2.join();
	}

}
