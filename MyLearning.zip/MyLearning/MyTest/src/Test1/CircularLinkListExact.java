package Test1;

import Test1.CircularLinkList.Node;

public class CircularLinkListExact {
	static class Node{
		int data;
		Node next;
		Node(int data){
			this.data=data;
			next=null;
		}
	}
	Node head,tail;
	int size=0;

	public static void main(String[] args) {
		CircularLinkListExact c=new CircularLinkListExact();
		c.add(10);
		c.add(20);
		c.add(30);
		c.append(40);
		c.append(50);
		c.delete();
		//c.deleteAt(2);
		c.isCircular();
		c.print();
	}
	
	

	private void isCircular() {
		System.out.println(tail.next==head);
	}



	private void delete() {
		if(size==0) {
			System.out.println("Size is empty");
		}
		else {
			head=head.next;
			tail.next=head;
			size--;
		}
	}

	private void append(int i) {
		if(size==0) {
			add(i);
		}
		else {
			Node n=new Node(i);
			tail.next=n;
			tail=n;
			tail.next=head;
			size++;
		}
		
	}

	private void add(int i) {
		Node n=new Node(i);
		if(size==0) {
			head=tail=n;
			n.next=head;
		}
		else {
			Node tmp=head;
			n.next=tmp;
			head=n;
			tail.next=head;
		}
		size++;
	}

	boolean isEmpty() {
		return head==null;
	}
	
	int getSize() {
		return size;
	}
	
	private void print() {
		if(head==null)
			return;
		Node tmp=head;
		do {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
		while(tmp!=head);
	}

}
