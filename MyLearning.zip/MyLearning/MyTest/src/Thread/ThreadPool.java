package Thread;

public class ThreadPool {
	BlockingQueue<Runnable> queue;
	ThreadPool(int qsize,int nThread){
		queue=new BlockingQueue<Runnable>(qsize);
		String threadName=null;
		ThreadExecutor task=null;
		for(int i=0;i<nThread;i++) {
			threadName="Thread-"+i;
			task=new ThreadExecutor(queue);
			Thread thread=new Thread(task, threadName);
			System.out.println("hi---------");
			thread.start();
		}
	}
	public void submitTask(Runnable task) throws InterruptedException {
		queue.enqueue(task);
	}

}
