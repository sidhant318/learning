package Thread;

public class PrintString {
	
	public static void main(String[] arg) {
		String a="AAAABBBCCDDDD";
		StringBuilder b=new StringBuilder("");
		char c1=a.charAt(0);
		int count=1;
		for(int i=1;i<a.length();i++) {
			char c2=a.charAt(i); 
			if(c1==c2) {
				count=count+1;
			}
			else {
				b.append(count);//=""+count+c1;
				b.append(c1);
				c1=c2;
				count=1;
			}		
		}
		b.append(""+count+c1);
		System.out.println(b);
	}

}
