package Thread;
class Node{
	int data;
	Node left;
	Node right;
	Node(int data){
		this.data=data;
		left=right=null;
	}
}
public class DoubleLinkList {
	Node head;
	public static void main(String[] args) {
		DoubleLinkList d=new DoubleLinkList();
		d.add(10);
		d.add(20);
		d.add(30);
		d.append(40);
		d.append(50);
d.print();
	}

	private void append(int i) {
		Node n=new Node(i);
		Node tmp=head;
		while(tmp.right!=null) {
			tmp=tmp.right;
		}
		tmp.right=n;
		n.left=tmp;
	}

	private void print() {
		Node tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.right;
		}
	}

	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			n.left=head;
			return;
		}
		n.right=head;
		head=n;
		n.left=head;
	}

}
