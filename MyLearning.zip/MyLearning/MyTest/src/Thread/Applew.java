package Thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class D implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			throw new RuntimeException();
		}
		catch (Exception e) {
		System.out.println("bye");
		}
	}
	
}
public class Applew {

	public static void main(String[] args) {
		ExecutorService e=Executors.newCachedThreadPool();
		try {
			e.execute(new D());
			e.execute(new D());
			e.execute(new D());
			e.execute(new D());
		}
		catch (Exception ex) {
			System.out.println("-----------");
		}
	}

}
