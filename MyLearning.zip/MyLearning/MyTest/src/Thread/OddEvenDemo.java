package Thread;

class OddEven{
	static Object o=new Object();
	int size=20;
	static int count=0;
	int reminder;
	OddEven(int reminder){
		this.reminder=reminder;
	}
	void print() {
		while(count<size) {
			synchronized (OddEven.class) {
				//System.out.println(" ---"+reminder);
				if(count%2!=reminder-1) {
					try {
						OddEven.class.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread().getName()+" "+count);
				count++;
				OddEven.class.notifyAll();
			}
		}
	}
}
public class OddEvenDemo {
	public static void main(String[] args) {
		OddEven e=new OddEven(1);
		OddEven o=new OddEven(2);
		new Thread(()->e.print()).start();
		new Thread(()->o.print()).start();
	}

}
