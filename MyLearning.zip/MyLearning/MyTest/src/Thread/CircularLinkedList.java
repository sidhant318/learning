package Thread;
class Nodes{
	int data;
	Nodes next;
	Nodes(int data){
		this.data=data;
		next=null;
	}
}
public class CircularLinkedList {
Nodes head;
	public static void main(String[] args) {
		CircularLinkedList c=new CircularLinkedList();
		c.add(10);
		c.add(20);
		c.add(30);
		c.append(40);
		c.append(50);
		c.delete();
		c.delete();
		c.print();
	}
	private void delete() {
		Nodes tmp=head;
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		head=head.next;
		tmp.next=head;
	}
	private void append(int i) {
		Nodes n=new Nodes(i);
		Nodes tmp=head;
		if(head==null) {
			head=n;
			n.next=head;
			return;
		}
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		tmp.next=n;
		n.next=head;
	}
	private void add(int i) {
		Nodes n=new Nodes(i);
		Nodes tmp=head;
		if(head==null) {
			head=n;
			n.next=head;
			return;
		}
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		n.next=head;
		head=n;
		tmp.next=head;
	}
	private void print() {
		Nodes tmp=head;
		if(head==null)
			return;
		do {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
		while(tmp!=head);
	}

}
