package Thread;

import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Test1{
	void m1() {
		synchronized (Test1.class) {
			
			System.out.println("Calling m1");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	void m2() {
		synchronized (Test1.class) {
			System.out.println("Calling m2");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	void m3() {
		synchronized (this) {
			System.out.println("Calling m3");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	void m4() {
		synchronized (this) {
			System.out.println("Calling m4");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
public class Demo1 {

	public static void main(String[] args) {
		Thread t1=new Thread(()->new Test1().m1());
		Thread t2=new Thread(()->new Test1().m2());
		Thread t3=new Thread(()->new Test1().m3());
		Thread t4=new Thread(()->new Test1().m4());
		t1.start();
		t2.start();
		t3.start();
		t4.start();
	}

}
