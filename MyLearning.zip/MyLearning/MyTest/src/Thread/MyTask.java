package Thread;

public class MyTask implements Runnable {

	@Override
	public void run() {
		System.out.println("Starting MyTask...");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Ending MyTask...");

	}

}
