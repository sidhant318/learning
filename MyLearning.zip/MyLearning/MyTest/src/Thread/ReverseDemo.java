package Thread;

public class ReverseDemo {
	public static void main(String[] args) {
		String name="Sidhant";
		String tmp=reverse(name);
		System.out.println(tmp);
	}
	private static String reverse(String name) {
		if(name.length()<2)
			return name;
		return reverse(name.substring(1))+name.charAt(0);
	}
}
