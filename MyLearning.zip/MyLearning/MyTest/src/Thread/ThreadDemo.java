package Thread;

public class ThreadDemo {

	public static void main(String[] args) throws InterruptedException {
		ThreadPool t=new ThreadPool(10, 5);
		for(int i=0;i<5;i++) {
			MyTask m=new MyTask();
			t.submitTask(m);
		}
	}

}
