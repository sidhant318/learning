package Thread;

import java.util.ArrayList;
import java.util.List;

class ConPro{
	List<Integer> l=new ArrayList<Integer>();
	final int max=5;
	final int min=0;
	int count=0;
	
	public void producer() {
		while(true) {
			synchronized (this) {
				if(l.size()==max){
					try {
						wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				System.out.println(Thread.currentThread().getName()+" "+count);
				l.add(count);
				count++;
				notify();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public void consumer() {
		while(true) {
			synchronized (this) {
				if(l.size()==min){
					try {
						wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread().getName()+" "+count);
				count--;
				l.remove(count);
				
				notify();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
public class CPP {

	public static void main(String[] args) {
		ConPro c=new ConPro();
		new Thread(()->c.producer()).start();
		new Thread(()->c.consumer()).start();
	}

}
