package Thread;

import java.util.Deque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

public class LRUCache {
	
	static Deque<Integer> dq;
	static HashSet<Integer> map;
	static int csize;
	LRUCache(int size){
		dq=new LinkedList<Integer>();
		map=new HashSet<Integer>();
		csize=size;
	}
	public static void main(String[] args) {
		LRUCache ca=new LRUCache(3);
		ca.refer(1);  
        ca.refer(2);  
        ca.refer(3);  
        ca.refer(1);  
        ca.refer(1);  
        ca.refer(1);
		ca.print();

	}
	private void refer(int x) {
		if(!map.contains(x)) {
			if(dq.size()==csize) {
				int lst=dq.removeLast();
				map.remove(lst);
			}
		}
		else {
			int index =0 , i=0; 
            Iterator<Integer> itr = dq.iterator();  
            while(itr.hasNext())  
            {  
                if(itr.next()==x) 
                { 
                    index = i; 
                    break; 
                } 
                i++; 
            }  
            dq.remove(index);
		}
		dq.push(x);
		map.add(x);
	}
	private void print() {
		Iterator<Integer> it=dq.iterator();
		while(it.hasNext()) {
			System.out.print(it.next()+" ");
		}
	}

}
