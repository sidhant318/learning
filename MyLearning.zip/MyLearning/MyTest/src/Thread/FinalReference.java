package Thread;
class Appl{
	public int a;
	
}
public class FinalReference {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final Appl a1=new Appl();
		a1.a=10;
		Appl a2=new Appl();
		//a1=new Appl();
		
		Appl n=new Appl();
		//a1=n;
		Appl n1=a1;
		System.out.println(a1.hashCode());
		System.out.println(n.hashCode());System.out.println(a2.hashCode());
		System.out.println(n1.hashCode());
	}

}
