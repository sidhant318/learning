package Thread;

import java.util.HashMap;

class LNode{
	int key;
	int value;
	LNode prev;
	LNode next;
	LNode(int key,int value){
		this.key=key;
		this.value=value;
		prev=next=null;
	}
}
public class LRUCacheLinkedList {
	private HashMap<Integer, LNode> hm;
	private int capacity,count;
	private LNode head;
	LRUCacheLinkedList(int capacity){
		this.capacity=capacity;
		 hm=new HashMap<Integer, LNode>();
		count=0;
		//head=null;
	}
	public static void main(String[] arg) {
		LRUCacheLinkedList u=new LRUCacheLinkedList(3);
		u.set(1,10);
		u.set(2,10);
		u.set(3,10);
		u.set(1,10);
		
		//u.get(3);
		u.print();
	}
	private int get(int key) {
		if(hm.get(key)!=null) {
			LNode node=hm.get(key);
			deleteNode(node);
			addToHead(node);
			return node.value;
		}
		else {
			System.out.println("Data is not there");
			return -1;
		}
	}
	private void print() {
		LNode tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.key);
			tmp=tmp.next;
		}
		
	}
	private void set(int key, int value) {
		//System.out.println("Going to set key "+key+" value : "+value);
		if(hm.get(key)!=null) {
			LNode node=hm.get(key);
			node.value=value;
			deleteNode(node);
			addToHead(node);
		}
		else {
			LNode node=new LNode(key, value);
			hm.put(key, node);
			if(count<capacity) {
				count++;
				addToHead(node);
			}
			else {
				LNode tmp=head;
				while(tmp.next!=null) {
					tmp=tmp.next;
				}
				hm.remove(tmp.key);
				deleteNode(tmp);
				addToHead(node);
			}
		}
	}
	private void addToHead(LNode newNode) {
		newNode.next=head;
		newNode.prev=null;
		if(head!=null)
			head.prev=newNode;
		head=newNode;
	}
	private void deleteNode(LNode node) {
		node.prev.next=node.next;
		//node.next.prev=node.prev;
	}
	
}
