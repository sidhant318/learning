package JP;

import java.util.Random;

public class A {
	public static void main(String[] arg) {
		String a="Sidhant";
		System.out.println(a+" "+a.hashCode());
		a="aman";
		System.out.println(a+" "+a.hashCode());
		String b=new String("Sidhant1");
		System.out.println(b+" "+b.hashCode());
		b="Sidhant1";
		System.out.println(b+" "+b.hashCode());
		String c=new String("Sidhant");
		System.out.println(c+" "+c.hashCode());
		StringBuilder sb=new StringBuilder("Sidhant");
		StringBuilder sb1=new StringBuilder("Sidhant");
		System.out.println(sb.hashCode());
		System.out.println(sb1.hashCode());
		Random r=new Random();
		//int n=;
		System.out.println(r.nextInt(6));
	}

}
