package JP;

public class CIrcularLinkList {
	static class Node{
		int data;
		Node next;
		public Node(int data) {
			this.data=data;
			next=null;
		}
	}
	Node head,rear;
	public static void main(String[] args) {
		CIrcularLinkList c=new CIrcularLinkList();
		c.add(10);
		c.add(10);
		c.add(20);
		c.append(30);
		c.append(40);
		c.iscircular();
		//c.delete();
		c.print();
	}
	
	private void iscircular() {
		Node tmp=head;
		while(tmp.next!=null && tmp.next!=head) {
			tmp=tmp.next;
		}
		System.out.println(tmp.next==null?"Not Circular":"Circular");
	}

	private void append(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			n.next=head;
			return;
		}
		Node tmp=head;
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		tmp.next=n;
		n.next=head;
	}
	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			n.next=head;
			return;
		}
		Node tmp=head;
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		n.next=head;
		head=n;
		tmp.next=head;
	}
	private void print() {
		if(head==null)
			return;
		Node tmp=head;
		do {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
		while(tmp!=head);
	}

}
