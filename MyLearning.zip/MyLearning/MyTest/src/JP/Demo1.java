package JP;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Demo1 {

	public static void main(String[] args) {
		Map<String, String> dataSet = new HashMap<String, String>(); 
        dataSet.put("A", "C"); 
        dataSet.put("B", "C"); 
        dataSet.put("C", "F"); 
        dataSet.put("D", "E"); 
        dataSet.put("E", "F"); 
        dataSet.put("F", "F"); 
  
        populateResult(dataSet); 
	}

	private static void populateResult(Map<String, String> dataSet) {
		Map<String,List<String>> m=new HashMap<String,List<String>>();
		for(Map.Entry<String, String> hm:dataSet.entrySet()) {
			String emp=hm.getKey();
			String man=hm.getValue();
			List<String> l=m.get(man);
			if(l==null) {
				l=new ArrayList<String>();
				m.put(man, l);
			}
			l.add(emp);
		}
		
		for(Map.Entry<String,List<String>> m1:m.entrySet()) {
			System.out.print("Manager is : "+m1.getKey());
			System.out.print(" And Employee is : ");
			List<String> l=m1.getValue();
			for(String l1:l) {
				System.out.print(l1+" ");
			}
			System.out.println();
		}
		
	}

}
