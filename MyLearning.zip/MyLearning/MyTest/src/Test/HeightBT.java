package Test;

import Test.HeightBT.Node;

public class HeightBT {
	Node root;
	static class Node{
		int data;
		Node left;
		Node right;
		Node(int data){
			this.data=data;
			left=right=null;
		}
	}
	public static void main(String[] args) {
		HeightBT h=new HeightBT();
		h.root=new Node(10);
		h.root.left=new Node(8);
		h.root.left.left=new Node(6);
		h.root.left.right=new Node(9);
		h.root.right=new Node(12);
		h.root.right.left=new Node(14);
		h.root.right.right=new Node(16);
		h.height();
		h.countNode();
	}
	private void countNode() {
		int count=countNode(root);
		System.out.println("Count of Node : "+count);
	}
	private int countNode(Node root2) {
		if(root2==null) {
			return 0;
		}
		else {
			int left=countNode(root2.left);
			int right=countNode(root2.right);
			return (left+right+1);
		}
	//	return 0;
	}
	private void height() {
		int x=height(root);
		System.out.println(x);
	}
	private int height(Node root2) {
		if(root2==null) {
			return 0;
		}
		else {
			int left=height(root2.left);
			int right=height(root2.right);
			return Math.max(left+1, right+1);
			
		}
		 
	}

}
