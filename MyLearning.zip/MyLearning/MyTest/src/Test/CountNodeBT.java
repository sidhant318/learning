package Test;

import Test.HeightBT.Node;

public class CountNodeBT {


	Node root;
	static class Node{
		int data;
		Node left;
		Node right;
		Node(int data){
			this.data=data;
			left=right=null;
		}
	}
	public static void main(String[] args) {
		CountNodeBT h=new CountNodeBT();
		h.root=new Node(10);
		h.root.left=new Node(8);
		h.root.left.left=new Node(6);
		h.root.left.right=new Node(9);
		h.root.right=new Node(12);
		h.root.right.left=new Node(14);
		h.root.right.right=new Node(16);
		h.height();
		h.nodeCount();
	}
	private void nodeCount() {
		int count=nodeCount(root);
		System.out.println("Node count : "+count);
	}
	private int nodeCount(Node root2) {
		if(root2==null) {
			return 0;
		}
		else {
			int left=nodeCount(root2.left);
			int right=nodeCount(root2.right);
			return (left+right+1);
		}
	}
	private void height() {
		int x=height(root);
		System.out.println(x);
	}
	private int height(Node root2) {
		if(root2==null) {
			return 0;
		}
		else {
			int left=height(root2.left);
			int right=height(root2.right);
			return Math.max(left+1, right+1);
			
		}
		 
	}


}
