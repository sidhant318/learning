package Test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
class TestOdd implements Runnable{
	int reminder;
	int noOfThread;
	static Object o=new Object();
	static int count=0;
	final int size=20;
	TestOdd(int reminder,int noOfThread){
		this.reminder=reminder;
		this.noOfThread=noOfThread;
	}
	@Override
	public void run() {
		print();
	}

	private void print() {
		while(count<size) {
			synchronized (o) {
				while(count%noOfThread!=reminder) {
					try {
						o.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread().getName()+" "+count);
				count++;
				o.notify();
			}
		}
		
	}
	
}
public class OddEven {

	public static void main(String[] args) {
		int noOfThread=2;
		ExecutorService e=Executors.newFixedThreadPool(noOfThread);
		for(int i=0;i<noOfThread;i++) {
			e.submit(new TestOdd(i,noOfThread));
		}

	}

}
