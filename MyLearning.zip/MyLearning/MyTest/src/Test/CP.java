package Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class ConsProd{
	List<Integer> l=new ArrayList<Integer>();
	volatile static int count=0;
	final int size=5;
	final int lowsize=0;
	void produce() {
		while(true) {
			synchronized (this) {
				while(l.size()==size) {
					try {
						wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread().getName()+" "+count);
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				l.add(count++);
				notify();
			}
		}
	}
	void consume() {
		while(true) {
			synchronized (this) {
				while(l.size()==lowsize) {
					try {
						wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread().getName()+" "+ --count);
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				l.remove(count);
				notify();
			}
		}
	}
}
public class CP {

	public static void main(String[] args) {
		ConsProd c=new ConsProd();
		Thread t=new Thread(()->c.produce());
		Thread t1=new Thread(()->c.consume());
		t.start();
		t1.start();
	}

}
