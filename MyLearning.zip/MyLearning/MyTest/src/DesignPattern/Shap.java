package DesignPattern;

public interface Shap {
	void drow();
	void description();
}
