package DesignPattern;

public class AddColor extends DecoratorPattern{
	public AddColor(Shap s) {
		super(s);
	}
	@Override
	public void drow() {
		s.drow();
		System.out.println("byee");
	}
	@Override
	public void description() {
		s.description();
	}
}
