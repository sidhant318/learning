package DesignPattern;

public class Circle implements Shap{
	@Override
	public void drow() {
		System.out.println("Circle draw");
	}
	@Override
	public void description() {
		System.out.println("Circle draw");
	}
}
