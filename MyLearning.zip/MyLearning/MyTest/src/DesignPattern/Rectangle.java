package DesignPattern;

public class Rectangle implements Shap{
	@Override
	public void drow() {
		System.out.println("Rectangle draw");
	}
	@Override
	public void description() {
		System.out.println("Rectangle description");
	}
}
