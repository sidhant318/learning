package DesignPattern;

public abstract class DecoratorPattern implements Shap{
	Shap s;
	public DecoratorPattern(Shap s) {
		this.s=s;
	}
}
