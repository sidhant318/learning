package DesignPattern;

public class AddView  extends DecoratorPattern{

	public AddView(Shap s) {
		super(s);
		
	}

	@Override
	public void drow() {
		s.drow();
	}

	@Override
	public void description() {
		s.description();
	}

}
