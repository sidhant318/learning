package DesignPattern;

public class Demo {

	public static void main(String[] args) {
		Shap s=new Circle();
		Shap s1=new Rectangle();
		Shap s2=new AddColor(new Circle());
		s2.drow();
		System.out.println("-------");
		s.drow();
		s1.drow();
	}

}
