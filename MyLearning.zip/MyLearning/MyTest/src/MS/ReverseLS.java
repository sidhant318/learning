package MS;

public class ReverseLS {
	static class Node{
		int data;
		Node next;
		Node(int data){
			this.data=data;
			this.next=null;
		}
	}
	Node head;
	public static void main(String[] args) {
		ReverseLS r=new ReverseLS();
		r.add(10);
		r.add(20);
		r.add(30);
		r.add(40);
		r.print();
		r.reverse();
		System.out.println("----------");
		r.print();
	}
	private void reverse() {
		Node current=head;
		Node prev=null,next=null;
		while(current!=null) {
			next=current.next;
			current.next=prev;
			prev=current;
			current=next;
		}
		head=prev;
	}
	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			return;
		}
		n.next=head;
		head=n;
	}
	private void print() {
		Node tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
	}

}
