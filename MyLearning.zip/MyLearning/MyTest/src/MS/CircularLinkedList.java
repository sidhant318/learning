package MS;

public class CircularLinkedList {
	
	static class Node{
		int data;
		Node next;
		Node(int data){
			this.data=data;
			this.next=null;
		}
	}
	Node head,tail;
	public static void main(String[] args) {
		
		CircularLinkedList c=new CircularLinkedList();
		c.add(10);
		c.add(20);
		c.add(30);
		c.append(40);
		c.print();
		c.isCircular();
	}

	private void append(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=tail=n;
			n.next=head;
			return;
		}
		tail.next=n;
		tail=n;
		tail.next=head;
	}

	private void isCircular() {
		boolean val=head.next==null?false:true;
		System.out.println(val);
	}

	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=tail=n;
			n.next=head;
			return;
		}
		n.next=head;
		head=n;
		tail.next=head;
	}

	private void print() {
		if(head==null)
			return;
		Node tmp=head;
		do {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
		while(tmp!=head);
	}

}
