package MS;

import java.util.HashSet;

public class FindLoop {
	static class Node { 
		  
        int data; 
        Node next; 
  
        Node(int d) 
        { 
            data = d; 
            next = null; 
        } 
    } 
	static Node head;
	public static void main(String[] args) {
		FindLoop list=new FindLoop();
		list.head = new Node(50); 
        list.head.next = new Node(20); 
        list.head.next.next = new Node(15); 
        list.head.next.next.next = new Node(4); 
        list.head.next.next.next.next = new Node(10); 
  
        // Creating a loop for testing 
        head.next.next.next.next.next = head.next.next; 
        findloop();
print();
	}
	private static void print() {
		Node tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
	}
	private static void findloop() {
		HashSet<Node> h=new HashSet<FindLoop.Node>();
		Node tmp=head,tmp1=null;;
		while(tmp!=null) {
			
			if(h.contains(tmp)) {
				System.out.println("Loop Found"+tmp.data);
				tmp1.next=null;
				return;
			}
			h.add(tmp);
			tmp1=tmp;
			tmp=tmp.next;
		}
		
	}

}
