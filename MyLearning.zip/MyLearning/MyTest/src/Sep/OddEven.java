package Sep;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Demo extends Thread{
	static Object o=new Object();
	final int listSize=20;
	static int count=0;
	int reminder;
	int noOfThread;
	public Demo(int reminder,int noOfThread) {
		this.reminder=reminder;
		this.noOfThread=noOfThread;
	}
	@Override
	public void run() {
		print();
	}

	private void print() {
		while(count<listSize) {
			synchronized (o) {
				while(count%noOfThread!=reminder) {
					try {
						o.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(count+" "+Thread.currentThread().getName());
				count++;
				o.notifyAll();
			}
		}
		
	}
	
	
}
public class OddEven {

	public static void main(String[] args) {
		int nThreads=3;
		ExecutorService t=Executors.newFixedThreadPool(nThreads);
		for(int i=0;i<nThreads;i++) {
			t.submit(new Demo(i, nThreads));
		}
	}

}
