package Sep;

import java.util.Arrays;

public class MinHeapImpl {
	int capacity=10;
	int[] arr;
	int count;
	
	int getLeftChildIndex(int index) {
		return (2*index)+1;	
	}
	int getRightChildIndex(int index) {
		return (2*index)+2;	
	}
	int parentIndex(int index) {
		return (index-1)/2;
	}
	
	int getLeftChild(int index) {
		return arr[getLeftChildIndex(index)];	
	}
	int getRightChild(int index) {
		return arr[getRightChildIndex(index)];	
	}
	int getParent(int index) {
		return arr[parentIndex(index)];	
	}
	
	boolean hasLeftChild(int index) {
		return (getLeftChildIndex(index)<=count);
	}
	boolean hasRightChild(int index) {
		return (getRightChildIndex(index)<=count);
	}
	boolean hasParent(int index) {
		return (parentIndex(index)<=count);
	}
	
	
	MinHeapImpl(){
		arr=new int[capacity];
		count=0;
	}
	

	public static void main(String[] args) {
		MinHeapImpl m=new MinHeapImpl();
		m.add(14);
		m.add(13);
		m.add(10);
		m.add(3);
		m.add(7);
		m.poll();
		System.out.println(m.peek());
	}
	private void poll() {
		if(count==0)
			return;
		int val=arr[0];
		arr[0]=arr[count];
		count--;
		hepifyDown();
	}
	private void hepifyDown() {
		int index=0;
		while(hasLeftChild(index)) {
			int val=getLeftChildIndex(index);
			if(hasRightChild(index) && getLeftChild(index)>getRightChild(index)) {
				val=getRightChildIndex(index);
			}
			if(arr[index]<arr[val]) {
				break;
			}
			else {
				swap(index,val);
			}
			index=val;
		}
		
	}
	private void extraCapacity() {
		if(count==capacity) {
			capacity=2*capacity;
			arr=Arrays.copyOf(arr, capacity);
		}
	}
	public void swap(int data1,int data2) {
		int tmpvar=0;
		tmpvar=data1;
		data1=data2;
		data2=tmpvar;
	}
	private void add(int i) {
		extraCapacity();
		arr[count]=i;
		count++;
		hepifyup();
	}
	private void hepifyup() {
		int index=count--;
		while(hasParent(index) && getParent(index)>arr[index]) {
			swap(getParent(index),arr[index]);
			index=parentIndex(index);
		}	
	}
	public int peek() {
		return arr[0];
	}
}
