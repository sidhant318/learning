package Sep;

public class MergeSort {

	public static void main(String[] args) {
		int arr[]=new int[]{5,8,4,15,7,25,1};
		sort(arr);
		print(arr);
	}

	private static void sort(int[] arr) {
		System.out.println(arr.length-1);
		sort(arr,new int[arr.length],0,arr.length-1);
	}

	private static void sort(int[] arr, int[] tmp, int start, int end) {
		if(start<end) {
			int mid=(start+end)/2;
			sort(arr,tmp,start,mid);
			sort(arr,tmp,mid+1,end);
			merge(arr,tmp,start,end);
		}
		
	}

	private static void merge(int[] arr, int[] tmp, int leftStart, int rightEnd) {
		int leftend=(leftStart+rightEnd)/2;
		int rightStart=leftend+1;
		int left=leftStart;
		int right=rightStart;
		int size=rightEnd-leftStart+1;
		int k=leftStart;
		
		while(left<=leftend && right<=rightEnd) {
			if(arr[left]<arr[right]) {
				tmp[k]=arr[left];
				left++;
			}
			else {
				tmp[k]=arr[right];
				right++;
			}
			k++;
		}
		while(left<=leftend) {
			tmp[k]=arr[left];
			left++;
			k++;
		}
		while(right<=rightEnd) {
			tmp[k]=arr[right];
			right++;
			k++;
		}
		System.arraycopy(tmp, leftStart, arr, leftStart, size);
	}
	private static void print(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
