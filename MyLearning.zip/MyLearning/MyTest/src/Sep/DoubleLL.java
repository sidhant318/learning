package Sep;

public class DoubleLL {
	static class Node{
		int data;
		Node prev;
		Node next;
		Node(int data){
			this.data=data;
			this.next=this.prev=null;
		}
	}
	Node head;
	public static void main(String[] args) {
		DoubleLL d=new DoubleLL();
		d.add(10);
		d.add(20);
		d.add(30);
		d.add(40);
		d.print();

	}
	private void print() {
		Node tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
	}
	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			n.prev=head;
			return;
		}
		n.next=head;
		head=n;
		n.prev=head;
	}

}
