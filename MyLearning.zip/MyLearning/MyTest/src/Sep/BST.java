package Sep;

public class BST {
	static class Node{
		int data;
		Node left,right;
		Node(int data){
			this.data=data;
			left=right=null;
		}
	}
Node root;
	public static void main(String[] args) {
		BST b=new BST();
		b.add(10);
		b.add(20);
		b.add(12);
		b.add(6);
		b.add(33);
		b.print();
		//b.delete(20);
		System.out.println();
		b.print();
	}
	private void delete(int i) {
		root=delete(i,root);
	}
	private Node delete(int i, Node root2) {
		if(root2==null)
			return root2;
		if(root2.data>i) {
			root2.left=delete(i,root2.left);
		}
		else if(root2.data<i) {
			root2.right=delete(i,root2.right);
		}
		else {
			if(root2.left==null || root2.right==null) {
				Node tmp=null;
				tmp=root2.left==null?root2.right:root2.left;
				return tmp;
			}
			else {
				Node suc=sucssesor(root2);
				root2.data=suc.data;
				root2.right=delete(suc.data,root2.right);
			}
		}
		return root2;
	}
	private Node sucssesor(Node root2) {
		Node tmp=root2.right;
		while(tmp.left!=null) {
			tmp=tmp.left;
		}
		return tmp;
	}
	private void print() {
		print(root);
	}
	private void print(Node root2) {
		if(root2==null)
			return;
		print(root2.left);
		System.out.print(root2.data+" ");
		print(root2.right);
	}
	private void add(int i) {
		root=add(i,root);
	}
	private Node add(int i, Node root2) {
		if(root2==null) {
			root2=new Node(i);
			return root2;
		}
		else if(root2.data>i) {
			root2.left=add(i,root2.left);
		}
		else {
			root2.right=add(i,root2.right);
		}
		return root2;
	}

}
