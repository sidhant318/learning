package Sep;

public class SelectionSort {

	public static void main(String[] args) {
		int arr[]=new int[]{5,8,4,15,7,25,1};
		sort(arr);
	}

	private static void sort(int[] arr) {
		int size=arr.length;
		for(int i=0;i<size;i++) {
			int var=i;
			for(int j=i+1;j<size;j++) {
				if(arr[var]>arr[j]) {
					var=j;
				}
			}
			int tmp=arr[i];
			arr[i]=arr[var];
			arr[var]=tmp;
		}
		for(int i=0;i<size;i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
