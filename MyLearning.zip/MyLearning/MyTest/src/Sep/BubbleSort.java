package Sep;

public class BubbleSort {

	public static void main(String[] args) {
		int arr[]=new int[]{5,8,4,15,7,25,1};
		sort(arr);
		

	}

	private static void sort(int[] arr) {
		int size=arr.length;
		for(int i=0;i<size-1;i++) {
			for(int j=0;j<size-i-1;j++) {
				if(arr[j]>arr[j+1]) {
					int tmp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=tmp;
				}
			}
		}
		for(int i=0;i<size;i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
