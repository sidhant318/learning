package Sep;

public class QuickSort {

	public static void main(String[] args) {
		int arr[]=new int[] {2,9,4,6,8,1,11,65,89,12,15,16,99};
		sort(arr);
		print(arr);
	}

	private static void print(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}

	private static void sort(int[] arr) {
		sort(arr,0,arr.length-1);
	}

	private static void sort(int[] arr, int start, int end) {
		if(start<end) {
			int pivot=findPivot(arr,start,end);
			sort(arr,start,pivot-1);
			sort(arr,pivot+1,end);
		}
	}

	private static int findPivot(int[] arr, int start, int end) {
		int index=start;
		int pivot=arr[end];
		for(int i=start;i<end;i++) {
			if(arr[i]<=pivot) {
				int tmp=arr[i];
				arr[i]=arr[index];
				arr[index]=tmp;
				index++;
			}
		}
		int tmp=arr[end];
		arr[end]=arr[index];
		arr[index]=tmp;
		return index;
	}

}
