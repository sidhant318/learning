package Sep;


public class CircularLL {
	static class Node{
		int data;
		Node next;
		Node(int data){
			this.data=data;
			this.next=null;
		}
	}
	Node head,rear;
	public static void main(String[] args) {
		CircularLL c=new CircularLL();
		c.add(10);
		c.add(20);
		c.add(30);
		c.add(40);
		c.print();
		//c.delete();
	}
	private void print() {
		if(head==null)
			return;
		Node tmp=head;
		do {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
		while(tmp!=head);
	}
	private void delete() {
		
	}
	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=rear=n;
			n.next=head;
			return;
		}
		n.next=head;
		head=n;
		rear.next=head;
	}

}
