package Sep;

import java.util.ArrayList;
import java.util.List;

class Test{
	List<Integer> l=new ArrayList<Integer>();
	final int max=5;
	final int min=0;
	static int count=0;
	void producer() {
		while(true) {
			synchronized (this) {
				while(l.size()==max) {
					try {
						this.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				l.add(count);
				System.out.println(count);
				count++;
				this.notify();
			}
		}
	}
	
	void consumer() {
		while(true) {
			synchronized (this) {
				while(l.size()==min) {
					try {
						this.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				count--;
				l.remove(count);
				System.out.println(count);
				this.notify();
			}
		}
	}
}
public class PC {

	public static void main(String[] args) {
		Test t=new Test();
		Thread t1=new Thread(()->t.producer());
		Thread t2=new Thread(()->t.consumer());
		t1.start();
		t2.start();
	}

}
