package Sep;

public class InsertionSort {

	public static void main(String[] args) {
		int arr[]=new int[]{5,8,4,15,7,25,1};
		sort(arr);
	}

	private static void sort(int[] arr) {
		int size=arr.length;
		for(int i=1;i<size;i++) {
			int key=arr[i];
			int j=i-1;
			while(j>=0 && arr[j]>key) {
				arr[j+1]=arr[j];
				j--;
			}
			arr[j+1]=key;
		}
		for(int i=0;i<size;i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
