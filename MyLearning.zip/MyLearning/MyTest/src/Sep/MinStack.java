package Sep;

public class MinStack {
	static class Node{
		int data;
		int min;
		Node next;
		Node(int data,int min){
			this.data=data;
			this.min=min;
			this.next=null;
		}
		
	}
	Node head;
	public static void main(String[] args) {
		MinStack m=new MinStack();
		m.add(10);
		m.add(20);
		m.add(8);
		m.add(11);
		m.pop();
	}

	private void pop() {
		if(head==null)
			return;
		Node tmp=head;
		System.out.println(tmp.data+" "+tmp.min);
		head=head.next;
	}

	private void add(int i) {
		Node n=new Node(i, i);
		if(head==null) {
			head=n;
			return;
		}
		if(head.min<i) {
			n.min=head.min;
		}
		n.next=head;
		head=n;
	}

}
