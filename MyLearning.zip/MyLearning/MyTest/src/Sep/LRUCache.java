package Sep;

import java.util.HashMap;

import Thread.LNode;

class Node{
	int key;
	int value;
	Node prev;
	Node next;
	Node(int key,int value){
		this.key=key;
		this.value=value;
		prev=next=null;
	}
}
public class LRUCache {
	
	int size;
	Node head;
	int count=0;
	HashMap<Integer, Node> hm;
	LRUCache(int size){
		this.size=size;
		hm=new HashMap<Integer, Node>();
	}

	public static void main(String[] args) {
		LRUCache l=new LRUCache(3);
		l.add(10,10);
		
	}

	private void add(int i,int data) {
		if(hm.get(i)!=null) {
			Node tmp=hm.get(i);
			tmp.value=data;
			deleteNode(tmp);
			addToHead(tmp);
			hm.put(i, tmp);
		}
		else {
			Node tmp=new Node(i, data);
			if(count<size) {
				addToHead(tmp);
				hm.put(i, tmp);
			}
			else {
				Node tmp1=head;
				while(tmp1.next)
			}
		}
	}

	private void addToHead(Node newNode) {
		newNode.next=head;
		newNode.prev=null;
		if(head!=null)
			head.prev=newNode;
		head=newNode;
	}
	private void deleteNode(Node node) {
		node.prev.next=node.next;
		//node.next.prev=node.prev;
	}

}
