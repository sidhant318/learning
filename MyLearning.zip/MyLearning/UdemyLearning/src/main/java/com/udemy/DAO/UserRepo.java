package com.udemy.DAO;

import org.springframework.data.repository.CrudRepository;

import com.udemy.entity.UserEntity;

public interface UserRepo extends CrudRepository<UserEntity, Integer>{
	
	

}
