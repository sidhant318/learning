package com.udemy.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.udemy.DAO.UserRepo;
import com.udemy.entity.UserEntity;

@Service
public class UserService {
	
	@Autowired
	UserRepo repo;
	
	
	public UserEntity createUser(UserEntity u){
		return repo.save(u);
	}


	public Optional<UserEntity> getUser(Integer id) {
		return repo.findById(id);
	}
	

}
