package com.udemy.exception;

public class ErrorResponse {
	private String message;
	private String subCode;
	public ErrorResponse(){
		
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSubCode() {
		return subCode;
	}
	public void setSubCode(String subCode) {
		this.subCode = subCode;
	}
	
	

}
