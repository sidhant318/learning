package com.function;

import java.util.function.Function;
import java.util.function.Predicate;

class Student{
	String name;
	int marks;
	Student(){
		
	}
Student(String name,int marks){
		this.name=name;
		this.marks=marks;
	}
}
public class FunctionStudentEx {

	public static void main(String[] args) {
		Function<Student,String> p= s->{
			int mark=s.marks;
			String grade="";
			if(mark>=80) grade="A";
			else if(mark>=60) grade="B";
			else if(mark>=40) grade="C";
			else grade="Failed";
			return grade;
		};
		
		
		Student[] s= {
				new Student("Sid",100),
				new Student("Kunal",25),
				new Student("Ruchi",50),
				new Student("Nikki",70)
		};
		
		for(Student s1:s) {
			System.out.print("Name : "+s1.name);
			System.out.print("Marks : "+s1.marks);
			System.out.println("Grade : "+p.apply(s1));
		}

	}

}
