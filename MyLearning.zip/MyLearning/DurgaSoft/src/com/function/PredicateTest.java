package com.function;

import java.util.function.Predicate;

public class PredicateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<Integer> p=(e)->e%2==0;
		System.out.println(p.test(5));
		
		//String a="sidhant";
		Predicate<String> p1=s->s.length()>5;
		System.out.println(p1.test("Sidhant"));

	}

}
