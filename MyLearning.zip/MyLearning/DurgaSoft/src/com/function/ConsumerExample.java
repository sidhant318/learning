package com.function;

import java.util.function.Consumer;

class Students{
	String name;
	int marks;
	Students(){
		
	}
Students(String name,int marks){
		this.name=name;
		this.marks=marks;
	}
}
public class ConsumerExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer<Students> c=e->{
			System.out.println(e.name);
			System.out.println(e.marks);
		};
		Students[] ss= {
				new Students("Sid",100),
				new Students("Kunal",25),
				new Students("Ruchi",50),
				new Students("Nikki",70)
		};
		
		for(Students s1:ss) {
			c.accept(s1);
		}

	}

}
