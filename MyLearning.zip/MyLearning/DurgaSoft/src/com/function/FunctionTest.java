package com.function;

import java.util.function.Function;

public class FunctionTest {
	public static void main(String[] arg) {
//		Function<Integer, Integer> f=i->i*i;
//		System.out.println(f.apply(4));
		
//		Function<String, Integer> f=i->i.length();
//		System.out.println(f.apply("sidhant"));
		
		Function<String, String> f=i->i.toUpperCase();
		System.out.println(f.apply("sidhant"));
	}

}
