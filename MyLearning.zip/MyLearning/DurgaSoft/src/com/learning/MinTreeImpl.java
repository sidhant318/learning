package com.learning;

import java.util.Arrays;

public class MinTreeImpl {
	private int[] objData;
	int size = 0;
	int capacity;
	MinTreeImpl() {
		capacity = 16;
		objData = new int[capacity];
	}
	void increaseCapacity() {
		this.capacity = 2 * capacity;
		Arrays.copyOf(objData, capacity);
	}
	int size() {
		return size;
	}
	int leftChildIndex(int index) {
		return (2 * index) + 1;
	}
	int rightChildIndex(int index) {
		return (2 * index) + 2;
	}
	int parentIndex(int index) {
		return (index - 1) / 2;
	}
	boolean hasleftChildIndex(int index) {
		return leftChildIndex(index)<size;
	}
	boolean hasrightChildIndex(int index) {
		return rightChildIndex(index)<size;
	}
	boolean hasparentIndex(int index) {
		return parentIndex(index)>=0;
	}
	int leftChild(int index) {
		return objData[leftChildIndex(index)];
	}
	int rightChild(int index) {
		return objData[rightChildIndex(index)];
	}
	int parent(int index) {
		return objData[parentIndex(index)];
	}
	public static void main(String[] args) {
		MinTreeImpl m=new MinTreeImpl();
		m.insert(9);
		m.insert(8);
		m.delete();
		m.print();
	}
	private void delete() {
		if(size==0) {
			return;
		}
		objData[0]=objData[size-1];
		size--;
		hepifyDown();
	}
	private void hepifyDown() {
		int index=0;
		while(hasleftChildIndex(index)) {
			int num=leftChildIndex(index);
			if(hasrightChildIndex(index) && rightChild(index)<num) {
				num=rightChildIndex(index);
			}
			if(objData[index]<num) {
				break;
			}
			swap(index,num);
			index=num;
		}
	}
	private void insert(int i) {
		increaseCapacity();
		if(size==0) {
			objData[size]=i;
			size++;
			return;
		}
		objData[size]=i;
		size++;
		hepifyUp();
	}
	private void hepifyUp() {
		int index=size-1;
		while(hasparentIndex(index) && parent(index)>objData[index]) {
			swap(index,parentIndex(index));
			index=parentIndex(index);
		}
		
	}
	private void swap(int parent, int i) {
		int tmp=objData[parent];
		objData[parent]=objData[i];
		objData[i]=tmp;
	}
	private void print() {
		for(int i=0;i<size;i++) {
			System.out.println(objData[i]);
		}
	}

}
