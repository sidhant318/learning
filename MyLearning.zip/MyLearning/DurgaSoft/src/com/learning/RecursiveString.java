package com.learning;

public class RecursiveString {

	public static void main(String[] args) {
		RecursiveString r=new RecursiveString();
		String a="Sidhant";
		String tmp=r.reverse(a);
		System.out.println(tmp);
	}

	private String reverse(String a) {
		if(a.length()<2) {
			return a;
		}
		return reverse(a.substring(1))+a.charAt(0);
	}

}
