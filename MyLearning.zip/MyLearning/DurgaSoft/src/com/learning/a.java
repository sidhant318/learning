package com.learning;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class a {
	
	public static void main(String[] args) {
		String pepResponse="2753";
		List<Long> grantIdLists= Stream.of(pepResponse.replaceAll("\\s", "").split(","))
				.map(Long::valueOf)
				.collect(Collectors.toList());
		System.out.println(grantIdLists.size());
	}

}
