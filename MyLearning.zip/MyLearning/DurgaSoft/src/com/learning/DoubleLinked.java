package com.learning;
class Nodes{
	int data;
	Nodes next;
	Nodes prev;
	Nodes(int data){
		this.data=data;
		next=null;
		prev=null;
	}
}
public class DoubleLinked {
	Nodes head;

	public static void main(String[] args) {
		DoubleLinked d=new DoubleLinked();
		d.add(10);
		d.add(20);
		d.add(30);
		d.append(40);
		d.delete();
		d.print();
	}
	private void delete() {
		head=head.next;
	}
	private void append(int i) {
		Nodes data=new Nodes(i);
		Nodes tmp=head;
		if(head==null) {
			data.prev=head;
			head=data;
			return;
		}
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		tmp.next=data;
		data.prev=tmp;
	}
	private void add(int i) {
		Nodes data=new Nodes(i);
		if(head==null) {
			data.prev=head;
			head=data;
			return;
		}
		data.next=head;
		head.prev=data;
		head=data;
	}
	private void print() {
		Nodes next=head;
		while(next!=null) {
			System.out.println(next.data);
			next=next.next;
		}
	}
}
