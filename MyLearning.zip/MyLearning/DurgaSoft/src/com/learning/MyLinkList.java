package com.learning;

class Node{
	int data;
	Node next;
	Node(int data){
		this.data=data;
		next=null;
	}
}
public class MyLinkList {
	Node head;
	public static void main(String[] args) {
		MyLinkList myLinkList=new MyLinkList();
		myLinkList.add(10);
		myLinkList.add(20);
		myLinkList.add(30);
		myLinkList.append(40);
		myLinkList.append(50);
		myLinkList.delete();
		myLinkList.deleteEnd();
		myLinkList.deleteEnd();
		myLinkList.print();
	}
	private void deleteEnd() {
		if(head==null) {
			return;
		}
		Node tmp=head,prev=null;
		while(tmp.next!=null) {
			prev=tmp;
			tmp=tmp.next;
		}
		prev.next=null;
	}
	private void delete() {
		if(head==null) {
			return;
		}
		head=head.next;
	}
	private void append(int i) {
		Node n=new Node(i);
		Node tmp=head;
		if(head==null) {
			head=n;
			return;
		}
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		tmp.next=n;
	}
	private void print() {
		Node next=head;
		while(next!=null) {
			System.out.println(next.data);
			next=next.next;
		}
	}
	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			return;
		}
		n.next=head;
		head=n;
	}

}
