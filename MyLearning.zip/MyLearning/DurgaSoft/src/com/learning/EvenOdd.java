package com.learning;
class Print implements Runnable{
	int reminder;
	final int num=20;
	static int count=0;
	static Object o=new Object();
	Print(int reminder){
		this.reminder=reminder;
	}
	@Override
	public void run() {
		while(count<num) {
			synchronized (o) {
				while(count%2!=reminder) {
					try {
						o.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread().getName()+ "  "+count);
				count++;
				o.notifyAll();
			}
		}
		
	}
	
}
public class EvenOdd {

	public static void main(String[] args) {
		Thread t1=new Thread(new Print(0));
		Thread t2=new Thread(new Print(1));
		t1.start();
		t2.start();
	}

}
