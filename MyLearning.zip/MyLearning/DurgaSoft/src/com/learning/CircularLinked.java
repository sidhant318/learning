package com.learning;

public class CircularLinked {
	Node head;

	public static void main(String[] args) {
		CircularLinked c=new CircularLinked();
		c.add(10);
		c.add(20);
		c.add(30);
		c.append(40);
		c.append(50);
//		c.delete();
//		c.delete();
//		c.deleteLast();
//		c.deleteLast();
		c.print();
	}

	private void deleteLast() {
		Node tmp=head,prev=null;;
		while(tmp.next!=head) {
			prev=tmp;
			tmp=tmp.next;
		}
		prev.next=tmp.next;
	}

	private void delete() {
		Node tmp=head;
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		head=head.next;
		tmp.next=head;
	}

	private void append(int i) {
		Node data=new Node(i);
		if(head==null) {
			head=data;
			data.next=head;
			return;
		}
		Node tmp=head;
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		data.next=head;
		tmp.next=data;
	}

	private void add(int i) {
		Node data=new Node(i);
		if(head==null) {
			head=data;
			data.next=head;
			return;
		}
		Node tmp=head;
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		tmp.next=data;
		data.next=head;
		head=data;
	}

	private void print() {
		Node tmp=head;
		do {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
		while(tmp!=head);
//		while(tmp.next!=head) {
//			System.out.println(tmp.data);
//			tmp=tmp.next;
//		}
	}

}
