package com.learning;

class Nods{
	int data;
	Nods left,right;
	Nods(int data){
		this.data=data;
		left=right=null;
	}
}
public class BST {
	Nods root;
	public static void main(String[] args) {
		BST b=new BST();
		b.add(10);
		b.add(20);
		b.add(8);
		b.add(9);
		b.delete(8);
		b.print();
	}
	private void delete(int i) {
		root=deleteData(root,i);
	}
	private Nods deleteData(Nods root2, int data) {
		if(root2==null) {
			return root2;
		}
		if(data<root2.data) {
			root2.left=deleteData(root2.left,data);
		}
		else if(data>root2.data) {
			root2.right=deleteData(root2.right,data);
		}
		else {
			if(root2.left==null || root2.right==null) {
				Nods tmp=null;
				tmp=root2.left==null?root2.right:root2.left;
					return tmp;
			}
			else {
				Nods tmp=sucsessor(root2);
				root2.data=tmp.data;
				root2.right=deleteData(root2.right,tmp.data);
			}
		}
		return root2;
	}
	private Nods sucsessor(Nods root2) {
		Nods tmp=root2.right;
		while(tmp.left!=null) {
			tmp=tmp.left;
		}
		return tmp;
	}
	private void add(int data) {
		root=addData(root,data);
	}
	private Nods addData(Nods root2, int data) {
		Nods n=new Nods(data);
		if(root2==null) {
			root2=n;
		}
		else {
			if(data<root2.data) {
				root2.left=addData(root2.left,data);
			}
			else {
				root2.right=addData(root2.right,data);
			}
		}
		
		return root2;
	}
	private void print() {
		printData(root);
	}
	private void printData(Nods root2) {
		if(root2==null)
			return;
		printData(root2.right);
		System.out.println(root2.data);
		printData(root2.left);
	}

}
