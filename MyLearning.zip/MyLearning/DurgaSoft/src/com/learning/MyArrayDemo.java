package com.learning;

public class MyArrayDemo {
	
	private Object[] obj;
	int capacity;
	int size;
	MyArrayDemo(){
		this.capacity=16;
		obj=new Object[capacity];
	}
	MyArrayDemo(int capacity){
		this.capacity=capacity;
		obj=new Object[capacity];
	}
	
	int arraysize() {
		return size;
	}

	public static void main(String[] args) {
		MyArrayDemo m=new MyArrayDemo();
		m.add(10);
		m.add(20);
		m.add(30);
		m.addAt(0,90);
		m.add(40);
		m.add(50);
		m.delete(2);
		m.print();
	}
	private void delete(int index) {
		for(int i=index;i<arraysize();i++) {
			obj[i]=obj[i+1];
			obj[i+1]=null;
		}
		size--;
	}
	private void addAt(int index, int data) {
		for(int i=arraysize()-1;i>=index;i--) {
			obj[i+1]=obj[i];
			obj[i]=null;
		}
		obj[index]=data;
		size++;
	}
	private void add(int i) {
		obj[size]=i;
		size++;
	}
	private void print() {
		for(int i=0;i<arraysize();i++) {
			System.out.println(obj[i]);
		}
	}

}
