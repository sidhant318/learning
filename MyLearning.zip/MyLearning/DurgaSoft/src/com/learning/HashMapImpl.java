package com.learning;

class Entry<K,V>{
	K key;
	V value;
	Entry<K,V> next;
	Entry(K key,V value){
		this.key=key;
		this.value=value;
	}
}

public class HashMapImpl<K,V> {
	Entry<K,V>[] bucket;
	int initialCapacity;
	
	HashMapImpl(){
		initialCapacity=16;
		bucket=new Entry[initialCapacity];
	}

	public static void main(String[] args) {
		HashMapImpl<Integer,Integer> hm=new HashMapImpl<Integer,Integer>();
		hm.put(10,5);
		System.out.println(hm.get(10));
	}

	private V get(K key) {
		int index=gethashIndex(key);
		Entry<K,V> existing=bucket[index];
		while(existing!=null) {
			if(existing.key.equals(key)) {
				return existing.value;
			}
			existing=existing.next;
		}
		return null;
	}

	private void put(K key, V value) {
		Entry<K,V> entry=new Entry<K,V>(key, value);
		int index=gethashIndex(key);
		Entry<K,V> existing=bucket[index];
		if(existing==null) {
			bucket[index]=entry;
		}
		else {
			while(existing.next!=null) {
				if(existing.key.equals(key)) {
					existing.value=value;
					return;
				}
				existing=existing.next;
			}
			if(existing.key.equals(key)) {
				existing.value=value;
				return;
			}
			else {
				existing.next=entry;
			}
		}
		
	}

	private int gethashIndex(K key) {
		return getHashCode(key)%bucketSize();
	}

	private int getHashCode(K key) {
		return (key==null)?0:key.hashCode();
	}
	
	private int bucketSize() {
		return initialCapacity;
	}

}
