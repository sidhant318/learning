package com.durga;

@FunctionalInterface
interface interf{
	public int sum(int a,int b);
}
public class FunctionInterfaceExample {
	
	public static void main(String[] arg) {
		interf i=(a,b)->(a+b);
		System.out.println(i.sum(2, 4));
	}

}
