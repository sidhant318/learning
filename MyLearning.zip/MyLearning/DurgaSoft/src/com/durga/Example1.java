package com.durga;

import java.util.function.Function;

public class Example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Function<Integer, Integer> f=i->i*i;
//		System.out.println(f.apply(10));
		
		

	}

}
