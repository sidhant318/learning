package com.durga;

public class ThreadExample {
	public static void main(String[] arg) {
		Runnable r=()->{for(int i=0;i<10;i++) {
			System.out.println("I m in child threead");
			}
		};
		Thread t=new Thread(r);
		t.start();
		for(int i=0;i<10;i++) {
			System.out.println("I am in main ");
		}
	}

}
