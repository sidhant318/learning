package com.durga;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListExample {

	public static void main(String[] args) {
		List<Integer> l=new ArrayList<Integer>();
		l.add(10);
		l.add(20);
		l.add(40);
		l.add(30);
		l.add(11);
		l.add(55);
		l.add(2);
		Collections.sort(l,(a,b)->(a>b)?-1:(a<b)?1:0);
		//Collections.sort(l,(a,b)-> b-a);
		l.stream().forEach(System.out::println);
		

	}

}
