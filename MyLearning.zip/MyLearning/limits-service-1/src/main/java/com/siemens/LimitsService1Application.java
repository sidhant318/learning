package com.siemens;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimitsService1Application {

	public static void main(String[] args) {
		SpringApplication.run(LimitsService1Application.class, args);
	}

}
