package Random;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class A {
	public static void main(String[] arg) {
		ExecutorService e=Executors.newCachedThreadPool();
		System.out.println();
	}

}
