package Random;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class OddEven implements Runnable{
	int reminder;
	static int count=0;
	int size=20;
	int noOfThread;
	
	public OddEven(int reminder,int noOfThread) {
		this.reminder=reminder;
		this.noOfThread=noOfThread;
	}

	@Override
	public void run() {
		print();
	}

	private void print() {
		while(count<size) {
			synchronized (OddEven.class) {
				while(count%noOfThread!=reminder) {
					try {
						OddEven.class.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(count+" "+Thread.currentThread().getName());
				count++;
				OddEven.class.notifyAll();
			}
		}
		
	}
	
}
public class OddEvenDemo {

	public static void main(String[] args) {
		int noOfThread=2;
		ExecutorService e=Executors.newFixedThreadPool(2);
		for(int i=0;i<2;i++) {
			e.submit(new OddEven(i,noOfThread));
		}
	}

}
