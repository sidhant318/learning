package Random;

import java.util.ArrayList;
import java.util.List;

class PC{
	List<Integer> l=new ArrayList<Integer>();
	int count=0;
	final int size=5;
	
	void producer() {
		while(true) {
			synchronized (this) {
				if(l.size()>size) {
					try {
						this.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				l.add(count);
				System.out.println(count);
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				count++;
				this.notify();
			}
		}
	}
	
	void consumer() {
		while(true) {
			synchronized (this) {
				if(l.size()<1) {
					try {
						this.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				count--;
				System.out.println(count);
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				l.remove(count);
				//count++;
				this.notify();
			}
		}
	}
}
public class PCProblem {

	public static void main(String[] args) {
		PC p=new PC();
		Thread t=new Thread(()->p.producer());
		Thread t1=new Thread(()->p.consumer());
		t.start();
		t1.start();

	}

}
