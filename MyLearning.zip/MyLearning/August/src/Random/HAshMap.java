package Random;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HAshMap {

	public static void main(String[] args) {
		Map<String,String> myMap=new HashMap<String, String>();
		myMap.put("1", "1");
		myMap.put("2", "1");
		myMap.put("3", "1");
		myMap.put("4", "1");
		myMap.put("5", "1");
		myMap.put("6", "1");
		Iterator<String> it1 = myMap.keySet().iterator();

		while(it1.hasNext()){
			String entry = it1.next(); 
			
			if(entry.equals("3"))
			{
				System.out.println(entry);
				myMap.put("7", "1");
				break;
			}
		}

	}

}
