package Random;

public class ReverseSpecial {

	public static void main(String[] args) {
		String var="sidh@nt$ingh";
		reverse(var.toCharArray());
	}

	private static void reverse(char[] c) {
		int left=0;
		int right=c.length-1;
		while(left<right) {
			if(!isAlpha(c[left])) {
				left++;
			}
			else if(!isAlpha(c[right])) {
				right--;
			}
			else {
				char tmp=c[left];
				c[left]=c[right];
				c[right]=tmp;
				left++;right--;
			}
		}
		System.out.println(new String(c));
	}
	
	static boolean isAlpha(char c) {
		if((c >= 'A' & c<='Z') || (c >= 'a' & c<='z')){
			return true;
		}else
			return false;
	}

}
