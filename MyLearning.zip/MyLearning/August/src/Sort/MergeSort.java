package Sort;

public class MergeSort {

	public static void main(String[] args) {
		int arr[]=new int[] {2,9,4,6,8,1,11,65,89,12,15,16,99};
		sort(arr);
		print(arr);
	}

	private static void sort(int[] arr) {
		sort(arr,new int[arr.length],0,arr.length-1);
	}

	private static void sort(int[] arr, int[] tmp, int start, int end) {
		if(start<end) {
			int mid=(start+end)/2;
			sort(arr,tmp,start,mid);
			sort(arr,tmp,mid+1,end);
			merge(arr,tmp,start,end);
		}
		
	}

	private static void merge(int[] arr, int[] tmp, int leftstart, int rightend) {
		
		int leftend=(leftstart+rightend)/2;
		int rightstart=leftend+1;
		int size=rightend-leftstart+1;
		int left=leftstart;
		int right=rightstart;
		
		int k=leftstart;
		while(left<=leftend && right<=rightend) {
			if(arr[left]<arr[right]) {
				tmp[k]=arr[left];
				left++;
			}
			else {
				tmp[k]=arr[right];
				right++;
			}
			k++;
		}
		while(left<=leftend) {
			tmp[k]=arr[left];
			left++;
			k++;
		}
		while(right<=rightend) {
			tmp[k]=arr[right];
			right++;
			k++;
		}
		System.arraycopy(tmp, leftstart, arr, leftstart, size);
	}

	private static void print(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
