package Sort;

public class SelectionSort {

	public static void main(String[] args) {
		int arr[]=new int[] {2,9,4,6,8,1,11,65,89,12,15,16,99};
		sort(arr);
	}
	private static void sort(int[] arr) {
		for(int i=0;i<arr.length-1;i++) {
			int tmp=i;
			for(int j=i+1;j<arr.length;j++) {
				if(arr[tmp]>arr[j]) {
					tmp=j;
				}
			}
			int tmp1=arr[tmp];
			arr[tmp]=arr[i];
			arr[i]=tmp1;
		}
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		
	}
}
