package List;

public class SingleLinkList {
	
	static class Node{
		int data;
		Node next;
		Node(int data){
			this.data=data;
			this.next=null;
		}
	}
Node head;
	public static void main(String[] args) {
		SingleLinkList s=new SingleLinkList();
		s.add(10);
		s.add(20);
		s.add(30);
		s.addLast(40);
		s.delete();
		s.print();
	}

	private void delete() {
		head=head.next;
	}

	private void addLast(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			return;
		}
		Node tmp=head;
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		tmp.next=n;
	}

	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			return;
		}
		n.next=head;
		head=n;
	}

	private void print() {
		if(head==null)
			return;
		Node tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
	}

}
