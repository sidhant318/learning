package List;

import List.SingleLinkList.Node;

public class DoubleLinkedList {
	static class Node{
		int data;
		Node next;
		Node prev;
		Node(int data){
			this.data=data;
			this.next=null;
			this.prev=null;
		}
	}
Node head;
	public static void main(String[] args) {
		DoubleLinkedList d=new DoubleLinkedList();
		d.add(10);
		d.add(20);
		d.add(30);
		d.add(40);
		d.print();

	}
	private void add(int i) {
		Node n=new Node(i);
		if(head==null) {
			head=n;
			n.prev=head;
			return;
		}
		n.next=head;
		head=n;
		n.prev=head;
	}
	private void print() {
		if(head==null)
			return;
		Node tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
	}
}
