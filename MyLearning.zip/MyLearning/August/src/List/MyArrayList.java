package List;

import java.util.Arrays;

public class MyArrayList {
	Object[] myobj;
	int count;
	int size;
	MyArrayList(){
		this.size=10;
		myobj=new Object[size];
		count=0;
	}
	public static void main(String[] arg) {
		MyArrayList m=new MyArrayList();
		m.add(10);
		m.add(20);
		m.add(8);
		m.addStart(5);
		m.print();
	}
	private void addStart(int data) {
		if(count>(size/2)) {
			increaseCapacity();
		}
		for(int i=count;i>=0;i--) {
			//System.out.println("---"+myobj[i]);
			myobj[i+1]=myobj[i];
			myobj[i]=null;
		}
		myobj[0]=data;
		count++;
	}
	private void add(int i) {
		if(count>(size/2)) {
			increaseCapacity();
		}
		myobj[count]=i;
		count++;
	}
	private void increaseCapacity() {
		myobj=Arrays.copyOf(myobj, size*2);
	}
	private void print() {
		for(int i=0;i<arraySize();i++) {
			System.out.println(myobj[i]);
		}
	}
	private int arraySize() {
		return count;
	}

}
