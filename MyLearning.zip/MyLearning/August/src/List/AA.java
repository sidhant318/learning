package List;

public class AA {

	public static void main(String[] args) {
		int a[]=new int[] {1,2,3};
		call(a);

	}

	private static void call(int[] a) {
		for(int i=0;i<a.length;i++) {
			
		}
	}

}
