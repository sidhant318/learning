package List;
class Nodes{
	int data;
	Nodes prev;
	Nodes next;
	Nodes(int data){
		this.data=data;
		prev=null;
		next=null;
	}
}
public class DoubleLinkListDemo {
	Nodes head;
	public static void main(String[] args) {
		DoubleLinkListDemo d=new DoubleLinkListDemo();
		d.add(10);
		d.add(20);
		d.add(30);
		d.addAtLast(40);
		d.addAt(1,50);
		d.print();
	}
	private void addAt(int i,int data) {
		Nodes tmp=head;
		Nodes n=new Nodes(data);
		if(head==null) {
			n.next=head;
			head=n;
			return;
		}
		int counter=0;
		while(tmp!=null && counter+1!=i) {
			tmp=tmp.next;
			counter++;
		}
		n.next=tmp.next;
		n.prev=tmp;
		tmp.next=n;
		
	}
	private void addAtLast(int i) {
		Nodes tmp=head;
		Nodes n=new Nodes(i);
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		tmp.next=n;
		n.prev=tmp;
	}
	private void print() {
		Nodes tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
	}
	private void add(int i) {
		Nodes n=new Nodes(i);
		n.next=head;
		head=n;
	}

}
