package List;

class Node{
	int data;
	Node next;
	Node(int data){
		this.data=data;
		next=null;
	}
}

public class LinkListDemo {
	Node head;

	public static void main(String[] args) {
		LinkListDemo l=new LinkListDemo();
		l.add(10);
		l.add(20);
		l.addAtLast(30);
		l.addAtLast(40);
		l.addAt(1,50);
		l.print();
		//l.deleteLast();
		//l.deleteAt(1);
		l.deleteData(50);
		System.out.println();
		l.print();
		//System.out.println(l.size());
	}

	private void deleteData(int i) {
		Node tmp=head,pre=null;
		if(head.data==i) {
			head=head.next;
			return;
		}
		while(tmp!=null && tmp.data!=i) {
			pre=tmp;
			tmp=tmp.next;
		}
		pre.next=tmp.next;
	}

	private void deleteAt(int i) {
		Node tmp=head,prev=null;
		int count=0;
		if(i==0) {
			head=head.next;
			return;
		}
		while(tmp!=null && count!=i) {
			prev=tmp;
			tmp=tmp.next;
			count++;
		}
		if(tmp==null)
			return;
		prev.next=tmp.next;
	}

	private void deleteLast() {
		Node tmp=head,prev=null;
		while(tmp.next!=null) {
			prev=tmp;
			tmp=tmp.next;
		}
		prev.next=tmp.next;
	}
	
	

	private int size() {
		Node tmp=head;
		int counter=0;
		while(tmp!=null) {
			tmp=tmp.next;
			counter++;
		}
		return counter;
	}

	private void addAt(int index, int data) {
		Node n=new Node(data);
		Node tmp=head;
		if(index==0) {
			n.next=head.next;
			head=n;
		}
		int counter=0;
		
		//Node pre=null;
		while(tmp!=null) {
			if(counter+1==index) {
				
				n.next=tmp.next;
				tmp.next=n;
				break;
			}
			tmp=tmp.next;
			counter++;
		}
	}

	private void addAtLast(int i) {
		Node n=new Node(i);
		
		if(head==null) {
			n.next=head;
			head=n;
			return;
		}
		Node tmp=head;
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		tmp.next=n;
	}

	private void print() {
		Node n=head;
		while(n!=null) {
			System.out.print(n.data+" ");
			n=n.next;
		}
	}

	private void add(int i) {
		Node n=new Node(i);
		n.next=head;
		head=n;
	}

}
