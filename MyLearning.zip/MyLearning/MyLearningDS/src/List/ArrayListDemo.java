package List;

import java.util.Arrays;

public class ArrayListDemo {

	Object[] obj;
	int size;
	int count = 0;

	ArrayListDemo() {
		size = 10;
		obj = new Object[size];
	}

	public static void main(String[] arg) {
		ArrayListDemo a = new ArrayListDemo();
		a.add(10);
		a.add(20);
		a.add(30);
		a.delete(0);
		// System.out.println(a.get(1));
		a.print();
		System.out.println(a.size());
	}

	private Object get(int i) {
		if (i > count) {
			new ArrayIndexOutOfBoundsException();
		}
		return obj[i];
	}

	private void delete(int index) {
		if (index > count) {
			new ArrayIndexOutOfBoundsException();
		}
		for (int i = index; i < count - 1; i++) {
			obj[i] = obj[i + 1];
			obj[i + 1] = null;
		}
		count--;
	}

	private void print() {
		for (int i = 0; i < size(); i++) {
			System.out.println(obj[i]);
		}
	}

	private int size() {
		return count;
	}

	private void add(int i) {
		if (size() > size) {
			increseCount(obj);
		}
		obj[count++] = i;
	}

	private void increseCount(Object[] obj2) {
		obj = Arrays.copyOf(obj, size * 2);
	}

}
