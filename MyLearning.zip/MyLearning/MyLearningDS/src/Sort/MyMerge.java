package Sort;

import java.util.Arrays;

public class MyMerge {

	public static void main(String[] args) {
		int arr[] = {12, 11, 13, 5, 6, 7}; 

		System.out.println("Given Array"); 
		printArray(arr); 
		MyMerge m=new MyMerge();
		m.sort(arr);
		System.out.println("Sorted Array"); 
		printArray(arr); 
	}
	
	private void sort(int[] arr) {
		sortArray(arr,new int[arr.length],0,arr.length-1);
	}

	private void sortArray(int[] arr, int[] tmp, int leftStart, int rightEnd) {
		if(leftStart<rightEnd) {
			int middle=(leftStart+rightEnd)/2;
			sortArray(arr,tmp,leftStart,middle);
			sortArray(arr,tmp,middle+1,rightEnd);
			sortMerge(arr,tmp,leftStart,rightEnd);
		}
	}

	private void sortMerge(int[] arr, int[] tmp, int leftStart, int rightEnd) {
		int leftEnd=(leftStart+rightEnd)/2;
		int rightStart=leftEnd+1;
		int size=rightEnd-leftStart+1;
		
		int k=leftStart;
		int left=leftStart;
		int right=rightStart;
		
		
		while(left<=leftEnd && right<=rightEnd) {
			if(arr[left]<=arr[right]) {
				tmp[k]=arr[left];
				left++;
			}
			else {
				tmp[k]=arr[right];
				right++;
			}
			k++;
		}
		while(left<=leftEnd) {
			tmp[k]=arr[left];
			k++;
			left++;
		}
		while(right<=rightEnd) {
			tmp[k]=arr[right];
			right++;
			k++;
		}
		System.arraycopy(tmp, leftStart, arr, leftStart, size);//mainarray,mainstartpos,destinationarray,desstartposi,total size
	}

	static void printArray(int arr[]) 
	{ 
		int n = arr.length; 
		for (int i=0; i<n; ++i) 
			System.out.print(arr[i] + " "); 
		System.out.println(); 
	} 

}
