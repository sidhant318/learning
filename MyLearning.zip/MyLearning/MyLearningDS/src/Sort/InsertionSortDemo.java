package Sort;

public class InsertionSortDemo {

	public static void main(String[] args) {
		int arr[] = {64, 34, 25, 12, 22, 11, 90};
		InsertionSortDemo demo=new InsertionSortDemo();
		demo.sort(arr);
		demo.print(arr);
	}

//	private void sort(int[] arr) {
//		int n=arr.length;
//		int val,j;
//		for(int i=1;i<n;i++) {
//			val=arr[i];
//			j=i-1;
//			while(j>=0 && arr[j]>val) {
//				arr[j+1]=arr[j];
//				j--;
//			}
//			arr[j+1]=val;
//		}
//	}
	
	private void sort(int[] arr) {
		int n=arr.length;
		int val,j;
		for(int i=1;i<n;i++) {
			j=i-1;
			while(j>=0 && arr[j]>arr[j+1]) {
				int tmp=arr[j+1];
				arr[j+1]=arr[j];
				arr[j]=tmp;
				j--;
			}
		}
	}

	private void print(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
