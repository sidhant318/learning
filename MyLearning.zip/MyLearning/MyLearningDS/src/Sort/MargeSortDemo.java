package Sort;

public class MargeSortDemo {

	public static void main(String[] args) {
		int arr[] = { 12, 11, 13, 5, 6, 7 };
		System.out.println("Given Array");
		printArray(arr);
		MargeSortDemo m = new MargeSortDemo();
		m.sort(arr);
		System.out.println("Sorted Array..");
		printArray(arr);
	}

	private void sort(int[] arr) {
		mergesort(arr, new int[arr.length], 0, arr.length - 1);
	}

	private void mergesort(int[] arr, int[] tmp, int leftStart, int rightEnd) {
		if(leftStart<rightEnd) {
			int mid=(leftStart+rightEnd)/2;
			mergesort(arr, tmp, leftStart, mid);
			mergesort(arr, tmp, mid+1, rightEnd);
			merge(arr,tmp,leftStart,rightEnd);
		}
	}

	private void merge(int[] arr, int[] tmp, int leftStart, int rightEnd) {
		int leftEnd=(leftStart+rightEnd)/2;
		int rightStart=leftEnd+1;
		int size=rightEnd-leftStart+1;
		int start=leftStart;
		int end=rightStart;
		int k=leftStart;
		while(start<=leftEnd && end<=rightEnd) {
			if(arr[start]<arr[end]) {
				tmp[k]=arr[start];
				start++;
			}
			else {
				tmp[k]=arr[end];
				end++;
			}
			k++;
		}
		while(start<=leftEnd) {
			tmp[k]=arr[start];
			start++;
			k++;
		}
		while(end<=rightEnd) {
			tmp[k]=arr[end];
			end++;
			k++;
		}
		System.arraycopy(tmp, leftStart, arr, leftStart, size);
	}

	static void printArray(int arr[]) {
		int n = arr.length;
		for (int i = 0; i < n; ++i)
			System.out.print(arr[i] + " ");
		System.out.println();
	}

}
