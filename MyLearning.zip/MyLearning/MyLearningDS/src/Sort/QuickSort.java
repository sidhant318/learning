package Sort;

public class QuickSort {

	public static void main(String[] args) {
		int arr[] = { 12, 11, 13, 5, 6, 7 };
		System.out.println("Given Array");
		printArray(arr);
		QuickSort m = new QuickSort();
		m.sort(arr);
		System.out.println("Sorted Array..");
		printArray(arr);
	}
	
	private void sort(int[] arr) {
		quickSort(arr,0,arr.length-1);
	}

	private void quickSort(int[] arr, int start, int end) {
		if(start<end) {
			int pivot=pivot(arr,start,end);
			quickSort(arr, start, pivot-1);
			quickSort(arr, pivot+1, end);
		}
		
	}

	private int pivot(int[] arr, int start, int end) {
		int pivot=arr[end];
		int index=start;
		for(int i=start;i<end;i++) {
			if(arr[i]<=pivot) {
				int tmp=arr[i];
				arr[i]=arr[index];
				arr[index]=tmp;
				index++;	
			}
		}
		int tmp=arr[end];
		arr[end]=arr[index];
		arr[index]=tmp;
		return index;
	}

	static void printArray(int arr[]) {
		int n = arr.length;
		for (int i = 0; i < n; ++i)
			System.out.print(arr[i] + " ");
		System.out.println();
	}

}
