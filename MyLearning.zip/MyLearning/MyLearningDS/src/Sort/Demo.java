package Sort;

import java.util.Arrays;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {12, 11, 13, 5, 6, 7}; 
int tmp[]=new int[arr.length];
		System.out.println("Given Array"); 
		printArray(arr); 
		Arrays.copyOf(arr, arr.length);
		printArray(tmp);
	}
	
	static void printArray(int arr[]) 
	{ 
		int n = arr.length; 
		for (int i=0; i<n; ++i) 
			System.out.print(arr[i] + " "); 
		System.out.println(); 
	} 

}
