package Queue;
class Node{
	int data;
	Node next;
	Node(int data){
		this.data=data;
	}
}
public class QueueLinkListImpl {
	Node head;
	public static void main(String[] args) {
		QueueLinkListImpl impl=new QueueLinkListImpl();
		impl.enque(10);
		impl.enque(20);
		impl.enque(30);
		impl.enque(40);
		impl.pop();
		impl.peek();
		impl.print();
	}
	private void pop() {
		head=head.next;
	}
	private void peek() {
		System.out.println("Peek Element is : "+head.data);
	}
	private void print() {
		Node n=head;
		while(n!=null){
			System.out.println(n.data);
			n=n.next;
		}
	}
	private void enque(int i) {
		Node data=new Node(i);
		if(head==null) {
			head=data;
			return;
		}
		Node tmp=head;
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		tmp.next=data;
	}

}
