package Queue;

import java.util.Arrays;

public class QueueArrayImpl {
	private Object[] obj;
	int count,front,rear;
	int capacity;
	QueueArrayImpl(){
		capacity =10;
		obj=new Object[capacity];
		front=rear=-1;
		count=0;
	}
	QueueArrayImpl(int capacity){
		this.capacity =capacity;
		obj=new Object[capacity];
	}

	public static void main(String[] args) {
		QueueArrayImpl impl=new QueueArrayImpl();
		impl.enqueu(10);
		impl.enqueu(20);
		impl.enqueu(30);
		impl.enqueu(40);
		impl.dequeue();
		impl.peek();
		impl.print();
	}
	private void dequeue() {
		for(int i=0;i<count;i++) {
			obj[i]=obj[i+1];
			obj[i+1]=null;
		}
		count--;
	}
	private void peek() {
		System.out.println("Peek Element is : "+obj[front]);
	}
	private void print() {
		for(int i=0;i<count;i++) {
			System.out.println(obj[i]);
		}
	}
	private void enqueu(int i) {
		if(count<(capacity/2))
			increasesize();
		if(count==0) {
			front=rear=0;
			obj[rear]=i;
		}
		else {
			obj[rear]=i;
		}
		rear++;
		count++;
	}
	private void increasesize() {
		capacity=2*capacity;
		Arrays.copyOf(obj, capacity);
	}

}
