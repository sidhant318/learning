package List;

import java.util.Arrays;

public class MyArrayList {
	private Object[] obj;
	int capacity;
	int count;
	MyArrayList(){
		this.capacity=10;
		obj=new Object[capacity];
	}
	MyArrayList(int capacity){
		this.capacity=capacity;
		obj=new Object[capacity];
	}
	
	int size() {
		return count;
	}
	void increasecapacity() {
		Arrays.copyOf(obj, 2*capacity);
	}

	public static void main(String[] args) {
		MyArrayList m=new MyArrayList();
		m.add(10);
		m.add(20);
		m.add(30);
		m.add(40);
		m.delete(1);
		m.addAt(2,50);
		m.print();
	}
	private void delete(int index) {
		for(int i=index;i<size();i++) {
			obj[i]=obj[i+1];
			obj[i+1]=null;
		}
		count--;
	}
	private void add(int i) {
		if(size()<(capacity/2)) {
			increasecapacity();
		}
		obj[count]=i;
		count++;
	}
	private void addAt(int index,int data) {
		if(size()<(capacity/2)) {
			increasecapacity();
		}
		for(int i=count-1;i>=index;i--) {
			obj[count]=obj[count-1];
		}
		obj[index]=data;
		count++;
	}
	private void print() {
		for(int i=0;i<count;i++) {
			System.out.println(obj[i]);
		}
	}

}
