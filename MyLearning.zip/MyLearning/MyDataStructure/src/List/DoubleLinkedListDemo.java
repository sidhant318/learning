package List;
class Nodes{
	int data;
	Nodes next,prev;
	Nodes(int data){
		this.data=data;
		next=prev=null;
	}
}
public class DoubleLinkedListDemo {
	Nodes head;
	public static void main(String[] args) {
		DoubleLinkedListDemo demo=new DoubleLinkedListDemo();
		demo.add(10);
		demo.add(20);
		demo.add(30);
		demo.add(40);
		demo.append(50);
		demo.append(60);
		//demo.delete();
		//demo.deleteLast();
		//demo.deleteAt(5);
		demo.print();
	}
	
	private void delete() {
		head=head.next;
	}
	private void deleteAt(int i) {
		if(i==0) {delete();return;}
		Nodes tmp=head;
		int count=0;
		while(tmp!=null && count<i) {
			tmp=tmp.next;count++;
		}
		Nodes pre=tmp.prev;
		if(tmp.next!=null) {
			tmp.next.prev=pre;
		}
		if(tmp.prev!=null) {
			pre.next=tmp.next;}
	}
	private void deleteLast() {
		Nodes tmp=head;
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		Nodes pre=tmp.prev;
		pre.next=null;
	}
	private void append(int i) {
		Nodes data=new Nodes(i);
		Nodes tmp=head;
		if(head==null) {
			data.prev=head;head=data;return;
		}
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		tmp.next=data;
		data.prev=tmp;
	}
	private void add(int i) {
		Nodes data=new Nodes(i);
		if(head==null) {
			data.prev=head;head=data;return;
		}
		data.next=head;
		head.prev = data;
		head=data;
	}
	private void print() {
		Nodes tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
	}

}
