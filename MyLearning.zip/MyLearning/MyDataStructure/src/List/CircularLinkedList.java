package List;

public class CircularLinkedList {
	Node head;
Node left=head;
	public static void main(String[] args) {
		CircularLinkedList list=new CircularLinkedList();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.append(50);
		list.append(60);
		//list.delete();
		list.deleteLast();
		//list.deleteLast();
		System.out.println(list.circular());
		list.print();

	}
	private boolean circular() {
		if(head==null)
			return true;
		Node tmp=head.next;
		while(tmp!=null && tmp!=head) {
			tmp=tmp.next;
		}
		return (tmp==head);
	}
	private void deleteLast() {
		Node tmp=head;
		Node pre=null;
		if(tmp.next==head) {
			head=null;
			return;
		}
		while(tmp.next!=head) {
			pre=tmp;
			tmp=tmp.next;
		}
		pre.next=tmp.next;
	}
	private void delete() {
		
		Node tmp=head;
		if(tmp.next==head) {
			head=null;
			return;
		}
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		head=head.next;
		tmp.next=head;
	}
	private void append(int i) {
		Node data=new Node(i);
		Node tmp=head;
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		data.next=tmp.next;
		tmp.next=data;
	}
	private void add(int i) {
		Node data=new Node(i);
		if(head==null)
		{
			head=data;
			data.next=head;
			return;
		}
		Node tmp=head;
		while(tmp.next!=head) {
			tmp=tmp.next;
		}
		tmp.next=data;
		data.next=head;
		head=data;	
	}
	private void print() {
		Node tmp=head;
		if(head!=null) {
		do {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
		while(tmp!=head);
		}
	}

}
