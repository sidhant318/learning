package List;
class Node{
	int data;
	Node next;
	Node(int data){
		this.data=data;
		next=null;
	}
}
public class LinkedListDemo {
	Node head;
	public static void main(String[] arg) {
		LinkedListDemo listDemo=new LinkedListDemo();
		listDemo.add(10);
		listDemo.add(20);
		listDemo.append(30);
		//listDemo.delete();
		listDemo.deleteAt(0);
		//listDemo.deleteLast();
		listDemo.print();
		
	}
	private void deleteAt(int i) {
		if(i==0) {
			delete();
			return;
		}
		Node tmp=head,pre=null;
		int count=0;
		while(tmp.next!=null && count<i) {
			pre=tmp;
			tmp=tmp.next;
			count++;
		}
		pre.next=tmp.next;
	}
	private void deleteLast() {
		if(head.next==null)
		{
			delete();
			return;
		}
		Node tmp=head;
		Node pre=null;
		while(tmp.next!=null) {
			pre=tmp;
			tmp=tmp.next;
		}
		pre.next=null;
	}
	private void delete() {
		head=head.next;
	}
	private void append(int i) {
		Node data=new Node(i);
		Node tmp=head;
		if(head==null) {
			head=tmp;
			return;
		}
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		tmp.next=data;
	}
	private void add(int i) {
		Node tmp=new Node(i);
		if(head==null) {
			head=tmp;
			return;
		}	
		tmp.next=head;
		head=tmp;
	}
	private void print() {
		Node tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
	}

}
