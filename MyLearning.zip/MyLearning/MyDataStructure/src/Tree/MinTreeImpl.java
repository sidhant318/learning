package Tree;

import java.util.Arrays;

public class MinTreeImpl {
	private int[] obj;
	int size = 0;
	int capacity;

	MinTreeImpl() {
		capacity = 10;
		obj = new int[capacity];
	}

	public int getLeftIndex(int index) {
		return (2 * index) + 1;
	}

	public int getRightIndex(int index) {
		return (2 * index) + 2;
	}

	public int getParentIndex(int index) {
		return (index - 1) / 2;
	}

	public int getLeftValue(int index) {
		return obj[getLeftIndex(index)];
	}

	public int getRightValue(int index) {
		return obj[getRightIndex(index)];
	}

	public int getParentValue(int index) {
		return obj[getParentIndex(index)];
	}

	public boolean hasLeftIndex(int index) {
		return getLeftIndex(index) < size;
	}

	public boolean hasRightIndex(int index) {
		return getRightIndex(index) < size;
	}

	public boolean hasParentIndex(int index) {
		return getParentIndex(index) >= 0;
	}

	public static void main(String[] args) {
		MinTreeImpl impl=new MinTreeImpl();
		impl.add(10);
		impl.add(20);
		impl.add(8);
		impl.add(30);
		impl.delete();
		impl.peek();
	}

	private void delete() {
		if(size==0)
			throw new NullPointerException();
		obj[0]=obj[size-1];
		size--;
		hepifyDown();
	}

	private void hepifyDown() {
		int index=0;
		while(hasLeftIndex(index)) {
			int num=getLeftIndex(index);
			if(hasRightIndex(index) && getRightValue(index)<getLeftValue(index)) {
				num=getRightIndex(index);
			}
			if(obj[index]<obj[num]) {
				break;
			}
			else {
				swap(index,num);
			}
			index=num;
			
		}
	}

	private void peek() {
		System.out.println(obj[0]);
	}

	private void add(int data) {
		ensurecapacity();
		obj[size]=data;
		size++;
		hipefyUp();
	}

	private void hipefyUp() {
		int index=size-1;
		while(hasParentIndex(index) && obj[index]<getParentValue(index)) {
			swap(getParentIndex(index),index);
			index=getParentIndex(index);
		}
	}

	private void swap(int parent, int i) {
		int tmp=obj[parent];
		obj[parent]=obj[i];
		obj[i]=tmp;
	}

	private void ensurecapacity() {
		if(size==capacity) {
			capacity=2*capacity;
			Arrays.copyOf(obj, capacity);
		}
	}

}
