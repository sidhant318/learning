package Tree;

import java.util.ArrayList;
import java.util.List;

class Myclass{
	final int max=5;
	final int min=0;
	static volatile int count=0;
	List<Integer> l=new ArrayList<Integer>();
	void produce() {
		while(true) {
			synchronized (this) {
				if(l.size()==max) {
					try {
						wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				l.add(count);
				System.out.println(Thread.currentThread().getName()+"  "+count);
				count++;
				notifyAll();
			}
		}
	}
	
	void consume() {
		while(true) {
			synchronized (this) {
				if(l.size()==min) {
					try {
						wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				count--;
				System.out.println(Thread.currentThread().getName()+"  "+count);
				l.remove(count);
				notifyAll();
			}
		}
	}
}
public class PCP {

	public static void main(String[] args) {
		Myclass c=new Myclass();
		Thread t=new Thread(()->c.produce());
		Thread t1=new Thread(()->c.consume());
		t.start();
		t1.start();

	}

}
