package Tree;

import java.util.ArrayList;
import java.util.List;

class Example{
	final int size=20;
	static int count=0;
	int reminder;
	static Object obj=new Object();
	Example(int reminder){
		this.reminder=reminder;
	}
void print() {
	while(count<size) {
		synchronized (obj) {
			if(count%2!=reminder) {
				try {
					obj.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println(Thread.currentThread().getName()+" " +count);
			count++;
			obj.notify();
		}
	}
}

}
public class PSExample {
	public static void main(String[] arg) {
		Example e=new Example(0);
		Example e1=new Example(1);
		Thread t=new Thread(()->e.print());
		Thread t1=new Thread(()->e1.print());
		t.start();
		t1.start();
	}

}
