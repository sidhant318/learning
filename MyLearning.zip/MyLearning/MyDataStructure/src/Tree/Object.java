package Tree;

//class Object{
//	public static void main(String[] args) {
//		printColumn(26);
//
//	}
//}

public class Object {
	Object o2;
	Object o1=new Object();
	static{
		
	}
	public static void main(String[] args) {
		
		{
			System.out.println("hi");
		}
		synchronized(Object.class) {
			
		}
		

	}

	private static void printColumn(int i) {
		StringBuilder sb=new StringBuilder();
		while(i>0) {
			int rem=i%26;
			if(rem==0) {
				sb.append("Z");
				i=(i/26)-1;
			}
			else {
				sb.append((char)((rem-1)+'A'));
				i=i/26;
			}
		}
		System.out.println(sb.reverse());
	}

}
