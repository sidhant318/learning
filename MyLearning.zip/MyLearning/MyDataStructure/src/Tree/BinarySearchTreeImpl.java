package Tree;

class Node{
	int data;
	Node left,right;
	Node(int data){
		this.data=data;
		left=right=null;
	}
}
public class BinarySearchTreeImpl {
	Node root;
	public static void main(String[] args) {
		BinarySearchTreeImpl impl=new BinarySearchTreeImpl();
		impl.insert(10);
		impl.insert(20);
		impl.insert(30);
		impl.insert(40);
		impl.insert(50);
		impl.delete(10);
		impl.print();
	}
	private void delete(int i) {
		root=delete(root,i);
	}
	private Node delete(Node node, int data) {
		if(node==null)
			return node;
		if(node.data>data) {
			node.left=delete(node.left,data);
		}
		else if(node.data<data) {
			node.right=delete(node.right,data);
		}
		else {
			if(node.left==null || node.right==null) {
				Node tmp=null;
				tmp=node.left==null?node.right:node.left;
				return tmp;
			}
			else {
				Node tmp=sucssesor(node);
				node.data=tmp.data;
				node.right=delete(node.right,tmp.data);
			}
		}
		return node;	
	}
	private Node sucssesor(Node node) {
		Node tmp=node.right;
		while(tmp.left!=null) {
			tmp=tmp.left;
		}
		return tmp;
	}
	private void print() {
		printData(root);
	}
	private void printData(Node root2) {
		if(root2==null)
			return;
		printData(root2.right);
		System.out.println(root2.data);
		printData(root2.left);
	//InOrder- left-root-right
	//preorder- root-left-right
	//post- left-right-root
	}
	private void insert(int i) {
		root=insertData(i,root);
	}
	private Node insertData(int data, Node root2) {
		if(root2==null) {
			root2=new Node(data);
		}
		else {
			if(root2.data>data)
				root2.left=insertData(data, root2.left);
			else
				root2.right=insertData(data, root2.right);
		}
		return root2;
	}

}
