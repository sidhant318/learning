package Stack;

import java.util.Arrays;

public class StackImpl {
	private Object[] obj;
	int count;
	int capacity;
	
	StackImpl(){
		this.capacity=16;
		obj=new Object[16];
	}

	public static void main(String[] args) {
		StackImpl s=new StackImpl();
		s.push(10);
		s.push(20);
		s.push(30);
		s.peek();
		s.pop();
		s.print();
	}


	private void pop() {
		count--;
	}

	private void peek() {
		System.out.println("Peek Element : "+obj[count-1]);
	}

	private void push(int i) {
		if(count>(capacity/2))
			increasesize();
		obj[count]=i;
		count++;
	}


	private void increasesize() {
		capacity=2*capacity;
		Arrays.copyOf(obj, capacity);
	}

	private void print() {
		for(int i=0;i<size();i++) {
			System.out.println(obj[i]);
		}
	}

	private int size() {
		return count;
	}

}
