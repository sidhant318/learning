package Stack;


class Node{
	int data,min;
	Node next;
	Node(int data){
		this.data=data;
		this.min=data;
		next=null;
	}
}
public class MinimumElementStack {
Node head;
	public static void main(String[] args) {
		MinimumElementStack m=new MinimumElementStack();
		m.push(10);
		m.push(20);
		m.push(30);
		m.peek();
		m.min();
		m.print();
	}

	private void peek() {
		System.out.println("Peek Element "+head.data);
	}

	private void min() {
		System.out.println("Min Element "+head.min);
	}

	private void push(int i) {
		Node data=new Node(i);
		if(head==null) {
			head=data;
			return;
		}			
		if(i>head.min)
			data.min=head.min;
		data.next=head;
		head=data;
	}
	private void print() {
		Node tmp=head;
		while(tmp!=null) {
			System.out.println(tmp.data);
			tmp=tmp.next;
		}
	}
}
