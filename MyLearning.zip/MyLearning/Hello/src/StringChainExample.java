import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class StringChainExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String[] words = {"a", "b", "ba", "bca", "bda", "bdca"};
		List<String> words=Arrays.asList("a", "b", "ba", "bca", "bda", "bdca");
        int longestChain = longestChain(words);
        System.out.println("longestChain " + longestChain);

	}

	private static int longestChain(List<String> words) {
		// TODO Auto-generated method stub
		int max=0;
		for(String word:words) {
			if(word.length()==1) {
				if(max<1)
					max=1;
			}
			else {
				int value=getlength(word);
				if(value>max)
					max=value;
			}
			
			
		}
		return max;
	}

	private static int getlength(String word) {
		// TODO Auto-generated method stub
		HashSet<Character> h=new HashSet<Character>();
		for(char c:word.toCharArray()) {
			h.add(c);
		}
		return h.size();
	}

}
