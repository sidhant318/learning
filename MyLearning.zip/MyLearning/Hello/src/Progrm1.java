import java.util.Stack;

public class Progrm1 {
	public static void main(String[] arg) {
		String a="[()]{[}{[()()]()}";
		//char[] c=a.toCharArray();
		 if (areParenthesisBalanced(a.toCharArray())) 
	            System.out.println("Balanced "); 
	          else
	            System.out.println("Not Balanced ");   
	}
	public static boolean isMatcing(char character1, char character2) {
		if(character1=='{' & character2=='}')
			return true;
		else if(character1=='[' & character2==']')
			return true;
		else if(character1=='(' & character2==')')
			return true;
		else
		return false;
		
	}
	public static boolean areParenthesisBalanced(char[] c) {
		Stack st=new Stack();
		for(int i=0;i<c.length;i++) {
			if(c[i]=='{' || c[i]=='[' || c[i]=='(') {
				st.push(c[i]);
			}
			if (c[i] == '}' || c[i] == ')' || c[i] == ']') 
	          { 
				if(st.empty()) {
					return false;
				}
				else if(! isMatcing((char)st.pop(),c[i])) {
					return false;
				}
	          }
		}
		if (st.isEmpty()) 
	         return true; /*balanced*/
	       else
	         {   /*not balanced*/
	             return false; 
	         } 
	}

}
