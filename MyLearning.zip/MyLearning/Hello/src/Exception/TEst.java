package Exception;

public class TEst {

	public static void main(String[] args) {
		
	       // Let us search 3 in below array 
	       int arr1[] = {5, 6, 7, 8, 9, 10, 1, 2, 3}; 
	       int n = arr1.length; 
	       int key = 3; 
	       System.out.println("Index of the element is : "
	                      + pivotedBinarySearch(arr1, n, key)); 
	}

	private static int pivotedBinarySearch(int[] arr1, int n, int key) {
		// TODO Auto-generated method stub
		int pivot = findPivot(arr1, 0, n-1);
		return pivot;
	}

	static int findPivot(int arr[], int low, int high) 
    { 
       // base cases 
       if (high < low)   
            return -1; 
       if (high == low)  
            return low; 
         
       /* low + (high - low)/2; */
       int mid = (low + high)/2;    //4
       if (mid < high && arr[mid] > arr[mid + 1]) {
           return mid; 
       }
    	   
       if (mid > low && arr[mid] < arr[mid - 1]) 
           return (mid-1); 
       if (arr[low] >= arr[mid]) {
    	   System.out.println("hiii");
    	   return findPivot(arr, low, mid-1); 
       }
           
       return findPivot(arr, mid + 1, high); 
    }

}
