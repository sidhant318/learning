package Exception;

import java.lang.Thread.UncaughtExceptionHandler;

public class ExceptionHandler implements UncaughtExceptionHandler {

	@Override
	public void uncaughtException(Thread arg0, Throwable arg1) {
		System.out.println("Handling Exception for : "+arg0.getName()+" and details : "+arg1);

	}

}
