package Exception;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


class ExceptionThrow extends Thread{
	public void run(){
//		Thread.currentThread().setUncaughtExceptionHandler(new UncaughtExceptionHandler() {
//			
//			@Override
//			public void uncaughtException(Thread arg0, Throwable arg1) {
//				System.out.println("Handling Exception for : "+arg0.getName()+" and details : "+arg1);
//				
//			}
//		});
		try {
			throw new RuntimeException();
		}
		catch (Exception e) {
			System.out.println("hi");
		}
		
	}
	
	
	
}
public class ExceptionHandleThread {
	
	

	public static void main(String[] args) {
System.out.println("I am in Main Thread Starter");

//Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {
//	
//	@Override
//	public void uncaughtException(Thread arg0, Throwable arg1) {
//		System.out.println("Handling Exception for : "+arg0.getName()+" and details : "+arg1);
//		
//	}
//});
		ExecutorService e=Executors.newCachedThreadPool();
		try {
			e.execute(new ExceptionThrow());
			e.execute(new ExceptionThrow());
			e.execute(new ExceptionThrow());
			e.execute(new ExceptionThrow());
		}
		catch (Exception ex) {
			// TODO: handle exception
			System.out.println("hi");
		}
		System.out.println("I am in Main Thread Ending");

	}

}
