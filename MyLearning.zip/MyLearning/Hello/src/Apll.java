
public class Apll {
	public String name;
	public String age;
	public Apll() {
		
	}
public Apll(String name,String age) {
		this.name=name;
		this.age=age;
	}

}
