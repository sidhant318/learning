package Lambda;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class functionTest {
	public static void main(String[] arg) {
		List<Integer> l=Arrays.asList(1,2,3,4,5,6,7,8,9);
		System.out.println("Print all number");
		eval(l,n->n>3);
	}

	private static void eval(List<Integer> l,Predicate<Integer> p) {
		for(Integer i:l) {
			if(p.test(i)) {
				System.out.println(i);
			}
		}
		
	}

}
