package Lambda;

public class LambdaExample1 {
	
	public static void main(String[] arg) {
		Runnable r=new Runnable() {
			
			public void run() {
				System.out.println("Hi");
			}
		};
		
		Runnable r1=()->System.out.println("Hi");
		new Thread(r).start();
		new Thread(r1).start();
	}
//	public static int a(int x,int y) {
//		int b=(x,y)->{return x+y;}
//	}
}
