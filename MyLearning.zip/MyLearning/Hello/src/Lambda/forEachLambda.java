package Lambda;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class forEachLambda {
	public static void main(String[] arg) {
		List<String> l=Arrays.asList("Sid","Raj","aman","lok");
		for(String a:l) {
			System.out.print(a+" ");
		}
		System.out.println();
		Iterator<String> it=l.iterator();
		while(it.hasNext()) {
			System.out.print(it.next()+" ");
		}
		System.out.println();
		l.forEach(ll->System.out.print(ll+" "));
		System.out.println();
		l.forEach(System.out::print);
	}

}
