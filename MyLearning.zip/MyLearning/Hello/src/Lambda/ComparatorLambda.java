package Lambda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Customer{
	private int cId;
	private String cName;
	public Customer(int cId,String cName) {
		this.cId=cId;
		this.cName=cName;
	}
	public int getcId() {
		return cId;
	}
	public String getcName() {
		return cName;
	}
	@Override
	public String toString() {
		return "[cId=" + cId + ", cName=" + cName + "]";
	}
	
	
}
public class ComparatorLambda {
	
	public static void main(String[] arg) {
		List<Customer> l=new ArrayList<Customer>();
		l.add(new Customer(3, "Sidhant"));
		l.add(new Customer(1, "Aman"));
		l.add(new Customer(9, "Babu"));
		l.add(new Customer(6, "Colly"));
//		Collections.sort(l, new Comparator<Customer>() {
//			
//			@Override
//			public int compare(Customer c1, Customer c2) {
//				return c1.getcId()-c2.getcId();
//			}
//		});
		
		Collections.sort(l, (c1,c2)->c1.getcId()-c2.getcId());
		System.out.println(l.toString());
	}

}
