package Lambda;

import java.util.HashSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class MyExample {
	public static void main(String[] arg) {
		TreeSet<Object> t=new TreeSet<Object>();
		t.add("");
		t.add(123);
		HashSet<Object> h=new HashSet<Object>();
		h.add("");
		h.add(123);
	}

}
