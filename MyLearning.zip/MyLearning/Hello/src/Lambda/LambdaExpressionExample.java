package Lambda;

interface Drawable{  
	public String draw(int a,int b);
}  
public class LambdaExpressionExample {  
    public static void main(String[] args) {  
       // String width="10";  
  
        //without lambda, Drawable implementation using anonymous class  
        Drawable d=(a,b)->{
        	System.out.println("Bye");
        	System.out.println("HIii"+(a+b));
        return "";
       // System.out.println(d.draw());  
    }  ;
    d.draw(1,2);
}  
}
