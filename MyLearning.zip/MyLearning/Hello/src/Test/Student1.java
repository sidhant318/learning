package Test;

import java.io.Serializable;

public final class Student1 implements Serializable{
	
	private final String ename;
	private final String eadd;
	private final Student s;
	
	Student1(String ename,String eadd,Student s){
		this.ename=ename;
		this.eadd=eadd;
		this.s=s;
	}

	public String getEname() {
		return ename;
	}

	public String getEadd() {
		return eadd;
	}

	public Student getS() {
		
		Student sss=new Student(s.getName(),s.getAge());
		
		return sss;
	}
	

}
