package Test;

public class OneByFive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1,j=1;i*3<=100 && j*5<=100;) {
		
			
			if(i*3<j*5) {
				System.out.println(i*3);
				i++;
			}
			else if(i*3>j*5) {
				System.out.println(j*5);
				j++;
			}
			else {
				System.out.println(i*3);
				i++;j++;
			}
		//	break;
		}

	}

}
