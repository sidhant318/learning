package Test;

import java.util.HashMap;
import java.util.Map;

public class MyMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map m=callMap();
		System.out.println(m);
	}

	private static Map callMap() {
		// TODO Auto-generated method stub
		Map<String, Object> map=new HashMap<>();
		Application a=new Application();
		a.setId(1L);
		a.setName("Sidh");
		GetDeviceResponse b=new GetDeviceResponse();
		b.setDevice_type("RDP");
		b.setSite_id(10L);
		map.put("deviceResponse", a);
		 map.put("appResponse",b);
		 return map;
	}

}
