package Test;

public class SelectionSortDemo {
	private static void print(int[] arr) {
		// TODO Auto-generated method stub
		for(int a:arr) {
			System.out.print(a+" ");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {64,25,12,22,11};
		sort(arr);
		print(arr);
	}
	private static void sort(int[] arr) {
		// TODO Auto-generated method stub
		for(int i=0;i<arr.length-1;i++) {
			int min=i;
			for(int j=i+1;j<arr.length;j++) {
				if(arr[j]<arr[min])
					min=j;
			}
			int tmp=arr[min];
			arr[min]=arr[i];
			arr[i]=tmp;
		}
	}

	

}
