package Test;

public class FabboTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		fab(10);

	}

	private static void fab(int a) {
		// TODO Auto-generated method stub
		int x=0;
		int x1=1;
		int x2=0;
		System.out.println(x);
		for(int i=0;i<a;i++) {
			x2=x+x1;
			System.out.println(x2);
			x=x1;
			x1=x2;
		}
	}

}
