package Test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class serializationDemo {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		Student s=new Student();
		s.setName("Sidhant1");
		s.setAge(28);
		Student1 s1=new Student1("aman","hello",s);
//		s.setAge1(21);
		FileOutputStream fos=new FileOutputStream("a.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(s1);
		System.out.println("hi");
		FileInputStream fis=new FileInputStream("a.txt");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Object o=ois.readObject();
		Student1 s2=(Student1) o;
System.out.println(s2.getEname());
System.out.println(s2.getEadd());
System.out.println(s2.getS().getName());
//System.out.println(s1.getAge1());
		
//		Student1 st=new Student1("Sidhant", "abc", new Student("Aman",20));
//		System.out.println(st.getEname());
//		System.out.println(st.getEadd());
//		st.getS().setName("Raja");
//		System.out.println(st.getS().getName());
	}

}
