package Test;

public class PrimeTest {
	public static void main(String[] arg) {
		prime(10);
	}

	private static void prime(int a) {
		// TODO Auto-generated method stub
		for(int i=2;i<=a;i++) {
			if(i%2==0) {
				System.out.println(i);
			}
		}
	}

}
