package Test;

public class aaa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String apple="Sidhant";
		String apple1="Book";
		String[] a;
		a= apple.split("");
		System.out.println(a[0]);
		a= apple1.split("");
		System.out.println(a[0]);
	}

}
