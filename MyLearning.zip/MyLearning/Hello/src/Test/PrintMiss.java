package Test;

public class PrintMiss {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a=new int[] {1,2,5};
		printMiss(a);
	}

	private static void printMiss(int[] a) {
		// TODO Auto-generated method stub
		int missno=0;
		for(int i=0;i<a.length-1;i++) {
			missno=a[i+1]-a[i];
			if(missno !=1) {
				for(int j=1;j<missno;j++) {
					System.out.println(a[i]+j);
				}
			}
		}
		
	}

}
