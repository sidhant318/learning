package Test;
class Parent{
	
	static void m1() {
		System.out.println("hi");
	}
	
}
class Child extends Parent{
	static void m1() {
		System.out.println("bye");
	}
}
public class OverridingDemo {

	public static void main(String[] args) {
		Parent p=new Child();
		p.m1();
	}

}
