package Test;

public class LockTest {

	public static void main(String[] args) {
		new Object(); // <--- lock obj level
		Class clazz = Object.class;
	}
	
	
	static synchronized void x() {
		// class level
	}
	
	static synchronized void x2() {
		// class level
	}
	
	
	synchronized void x1() {
		// class level
		// this
	}
}
