package Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ComparatorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> a=new ArrayList<String>();
		a.add("a");
		a.add("x");
		a.add("b");
		a.add("n");
		Collections.sort(a,new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				return o2.compareTo(o1);
			}
		});
		
		Collections.sort(a, 
				(x,y)->{
					return y.compareTo(x);
				}
				);
		System.out.println(a);
	}

}
