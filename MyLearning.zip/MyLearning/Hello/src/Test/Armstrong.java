package Test;

public class Armstrong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=153;
		if(num==checkArm(num)) {
			System.out.println("no is armstrong");
		}
		else {
			System.out.println("No is not Arm");
		}
	}

	private static int checkArm(int num) {
		// TODO Auto-generated method stub
		int sum=0;
		while(num!=0) {
			int div=num%10;
			sum=sum+(div*div*div);
			num=num/10;
		}
		return sum;
	}

}
