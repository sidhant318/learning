import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Hello {
	public static void main(String[] a){
		cal(1,0);	

	}
	
	static void cal(int i1,int x){
		int val=65;
		int x1=calculate(i1);
		for(int i=i1;i<=26;i++) {
			x=x*i+i;
			val=val-x;
			System.out.println(x+"   "+val);
			if(val<0) {
				cal(i1+1,x1);
				return;
			}
			System.out.println("hello");
			if(val==0) {
				break;
			}	
			
		}
		System.out.println("---------------");
	}
	static int calculate(int i1){
		//System.out.println(i1);
		int x=0;
		for(int i=1;i<=i1;i++) {
			x=x*i+i;
		}
		return x;
	}

}
