package OneEight;

import java.awt.font.NumericShaper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;


public class Example1 {
	public static void main(String[] arg) {
		List<Integer> numbers=Arrays.asList(1,2,3,4,5,6,7,8,9,10);
//		System.out.println(
//				numbers.stream()
//						.filter( e-> e%2 ==0)
//						.mapToInt(e -> e*2).sum()
//				);
	//	List<Integer> dobledata=new ArrayList<Integer>();
//		numbers.stream()
//			.filter(e -> e%2==0)
//			.map(e -> e*2)
//			.forEach(e -> dobledata.add(e));
		List<Integer> dobledata=
				numbers.stream()
						.filter(e-> e%2 ==0)
						.map(e -> e*2)
						.collect(Collectors.toList());
		System.out.println(dobledata);
		
		
	}

}
