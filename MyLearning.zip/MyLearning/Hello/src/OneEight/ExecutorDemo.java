package OneEight;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorDemo {
	public static void main(String[] arg) throws InterruptedException {
		
		ExecutorService e=Executors.newFixedThreadPool(10);
		e.execute(()->{
			for(int i=0;i<10;i++) {
				System.out.println("Hiiiii");
			}
			
		});
		for(int i=0;i<10;i++) {
			Thread.sleep(100);
			System.out.println("hi");
		}
	}

}
