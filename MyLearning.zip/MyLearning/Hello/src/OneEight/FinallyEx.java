package OneEight;

public class FinallyEx {
	public static void main(String[] arg) {
		try {
			System.out.println("hi");
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		finally {
			System.out.println("hie");
			System.out.println(10/0);
			System.out.println("hil");
		}
	}

}
