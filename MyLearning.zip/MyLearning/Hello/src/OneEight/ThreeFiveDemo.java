package OneEight;

import java.util.function.Function;
import java.util.function.Predicate;

public class ThreeFiveDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		for(int i=1;i<=100;i++) {
//			if(i%3==0 || i%5==0) {
//				System.out.println(i);
//			}
//		}
//		for(int i=1;i<=100;i++) {
//			Predicate<Integer> p=g->g%3==0 || g%5==0;
//			if(p.test(i)) {
//				System.out.println(i);
//			}
//			
//			
//		}
		
		for(int i=1;i<=100;i++) {
			if(i%3==0) {
				System.out.println(i);
			}
			else if(i%5==0) {
				System.out.println(i);
			}
			
			
		}
		

	}

}
