package OneEight;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Long> grantIdListl=new ArrayList<>();
		grantIdListl.add(10L);
		grantIdListl.add(20L);
		grantIdListl.add(18L);
		grantIdListl.add(100L);
		List<Long> grantIdList=new ArrayList<>();
		grantIdList.add(10L);
//		grantIdList.add(15L);
//		grantIdList.add(18L);
		grantIdList.add(20L);
		System.out.println(grantIdList);
		String l=new ArrayList<>(new HashSet<>(grantIdList)).stream().map(Object::toString).collect(Collectors.joining(","));
		List<Long> lom=Stream.of(l.split(",")).map(Long::valueOf).collect(Collectors.toList());
		
//System.out.println(grantIdListl.stream().anyMatch(num -> grantIdList.contains(num)));
		//System.out.println(grantIdListl.stream().filter(num -> grantIdList.contains(num)).collect());
	}

}
