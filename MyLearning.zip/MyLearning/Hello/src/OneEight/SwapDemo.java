package OneEight;

public class SwapDemo {
	public static void main(String[] arg) {
		String a="apple";
		String b="Mango";
		int x=10;
		int y=5;
		x=x+y;//15
		y=x-y;
		x=x-y;
		a=a+b;
		b=a.substring(0, a.indexOf(b));
		a=a.substring(b.length(), a.length());
		System.out.println(a);
		System.out.println(b);
		System.out.println(x);
		System.out.println(y);
		
		
	}

}
