package OneEight;

import java.util.ArrayList;
import java.util.List;

class Example{
	List<Integer> al=new ArrayList<Integer>();
	 final int fixsize=5;
	 final int minsize=0;
	int val=0;
	 public void producer() throws InterruptedException {
		 while(true) {
			 synchronized (this) {
				if(al.size()==fixsize)
					wait();
				al.add(val);
				System.out.println(val);
				val++;
				notify();
				Thread.sleep(200);
			}
		 }
		 
	 }
public void consumer() throws InterruptedException {
	while(true) {
		synchronized (this) {
			if(al.size()==minsize)
				wait();
			al.remove(--val);
			//val--;
			notify();
			Thread.sleep(200);
		}
	}
		 
	 }
}
public class ConsumerProducerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Example e=new Example();
		Thread t=new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					e.producer();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
Thread t1=new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					e.consumer();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
t.start();
t1.start();
	}

}
