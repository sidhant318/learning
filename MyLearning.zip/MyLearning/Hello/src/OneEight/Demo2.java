package OneEight;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Long> userRoleList=new ArrayList<Long>();
		userRoleList.add(10L);
		userRoleList.add(15L);
		userRoleList.add(3L);
		userRoleList.add(7L);
		userRoleList.add(70L);
		List<Long> userRoleList1=null;
		if(3>2) {
			userRoleList1=new ArrayList<Long>();
			userRoleList1.add(10L);
			userRoleList1.add(15L);
			userRoleList1.add(3L);
		}
		
		
		//System.out.println(userRoleList.stream().filter(e-> !userRoleList1.contains(e)).collect(Collectors.toList()));
	}

}
