import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LargestElementExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> a=Arrays.asList(2,3,10,6,4,8,1);
		int logestValue=getLongest(a);
System.out.println(logestValue);
	}
	public static int getLongest(List<Integer> a) {
		int max=a.get(1)-a.get(0);
		int min=a.get(0);
		for(int i=1;i<a.size();i++) {
			if(a.get(i)-min>max) {
				max=a.get(i)-min;
			}
			if(a.get(i)<min) {
				min=a.get(i);
			}
		}
//		for(int i=0;i<a.size();i++) {
//			for(int j=i+1;j<a.size();j++) {
//				if(a.get(j)-a.get(i)>max) {
//					max=a.get(j)-a.get(i);
//				}
//			}
//		}
		return max;
	}
}
