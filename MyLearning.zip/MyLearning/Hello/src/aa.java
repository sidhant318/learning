import java.util.List;

public class aa {
	public static void main(String[] aa) {
		List<Long> grantIdLists=null;
		//System.out.println(CollectionUtils.isNotEmpty(grantIdLists));
	}

}
