import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;




public class FileReaderWriterDemo {
	private static final String FILE_HEADER="ID,Name,Role,Salary";
	//Delimiter used in CSV file
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";
	public static void main(String[] arg) throws IOException {
		List<Employee> emps = readCSV();
		System.out.println(emps);
		writeCSV(emps);
	}
	
	private static void writeCSV(List<Employee> emps) {
		FileWriter fileWriter=null;
		try {
			fileWriter=new FileWriter("C:\\Users\\z003yn1j\\Desktop\\aaa.csv");
			fileWriter.append(FILE_HEADER.toString());
			for(Employee e : emps) {
				fileWriter.append(NEW_LINE_SEPARATOR);
				fileWriter.append(e.getId());
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(e.getName());
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(e.getSalary());
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(e.getRole());
			}
			System.out.println("File Writted Successfully");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}

	private static List<Employee> readCSV() throws IOException {
		List<Employee> emps=new ArrayList<Employee>();
		BufferedReader bf=new BufferedReader(new FileReader("myFile.csv"));
		String line=bf.readLine();
		while((line=bf.readLine())!=null && !line.isEmpty()) {
			String[] record=line.split(",");
			Employee emp = new Employee();
			emp.setId(record[0]);
			emp.setName(record[1]);
			emp.setRole(record[2]);
			emp.setSalary(record[3]);
			emps.add(emp);
		}
		bf.close();
		return emps;
	}

}
