package Tester;

import java.util.Arrays;

public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {1,2,3,4,5,6};
		rotate(arr,2);
		for(int j=0;j<arr.length;j++) {
			System.out.print(arr[j]);
		}
	}

	private static int[] rotate(int[] arr, int no) {
		// TODO Auto-generated method stub
		int i;
		int tmp=arr[0];
		for(i=0;i<arr.length-1;i++) {
			arr[i]=arr[i+1];
		}
		arr[i]=tmp;
		if(no>1) {
			rotate(arr,no-1);
		}
		return arr;
	}

}
