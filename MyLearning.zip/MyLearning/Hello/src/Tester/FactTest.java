package Tester;

public class FactTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fact=fact(3);
		System.out.println(fact);

	}

	private static int fact(int i) {
		// TODO Auto-generated method stub
		int no;
		if(i==1)
			return 1;
		
		no=fact(i-1)*i;
		return no;
	}

}
