package Tester;
class DemoEvenOdd implements Runnable{
	int maxnumer=20;
	static int count=0;
	int reminder;
	//static Object o=new Object();
	DemoEvenOdd(int reminder){
		this.reminder=reminder;
	}
	@Override
	public void run() {
		while(count<maxnumer) {
			synchronized (DemoEvenOdd.class) {
				while(count%2!=reminder) {
					try {
						DemoEvenOdd.class.wait();
						
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread().getName() + " -->  " + count);
				count++;
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				DemoEvenOdd.class.notify();
			}
		}
		
	}
	
}
public class OddEven {

	public static void main(String[] args) throws InterruptedException {
		Thread t1=new Thread(new DemoEvenOdd(0));
		Thread t2=new Thread(new DemoEvenOdd(1));
	//	Thread t3=new Thread(new DemoEvenOdd(0));
t1.start();
t2.start();
t1.join();
t2.join();
	}

}
