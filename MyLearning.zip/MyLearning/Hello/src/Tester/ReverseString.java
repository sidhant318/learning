package Tester;

public class ReverseString {

	public static void main(String[] args) {
		String a="Sidhant";
		ReverseString r=new ReverseString();
		String tmp=r.reverseStr(a);
System.out.println(tmp);
	}

	private String reverseStr(String a) {
		if(a.length()<2)
			return a;
		System.out.println(a.substring(1));
		return reverseStr(a.substring(1))+a.charAt(0);
	}

}
