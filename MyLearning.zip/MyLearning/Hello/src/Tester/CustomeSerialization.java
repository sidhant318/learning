package Tester;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class CustomeSerialization implements Serializable{
	
	String username = "gfg_admin"; 
    transient String pwd = "geeks";
    
    private void writeObject(ObjectOutputStream oos) throws IOException {
    	oos.defaultWriteObject();
    	String epwd="123"+pwd;
    	oos.writeObject(epwd);
    }
    
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    	ois.defaultReadObject();
    	String epwd=(String)ois.readObject();
    	pwd=epwd.substring(3);
    }
    
    
	
	

}
