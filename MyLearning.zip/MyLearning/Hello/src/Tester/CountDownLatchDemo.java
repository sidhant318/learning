package Tester;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

public class CountDownLatchDemo {
	public static void main(String args[]) throws InterruptedException, BrokenBarrierException {
		// Let us create task that is going to
		// wait for four threads before it starts
		CyclicBarrier latch=new CyclicBarrier(3);
		//CountDownLatch latch=new CountDownLatch(3);
		// Let us create four worker
		// threads and start them.
		Worker first = new Worker(200, latch, "WORKER-1");
		Worker second = new Worker(400, latch, "WORKER-2");
		Worker1 third = new Worker1(10000, latch, "WORKER-3");
		//Worker fourth = new Worker(10000, latch, "WORKER-4");
		first.start();
		second.start();
		third.start();
		//fourth.start();

		// The main task waits for four threads
		//latch.await();

		// Main thread has started
		System.out.println(Thread.currentThread().getName() + " has finished");
		//latch.reset();
	}

}
