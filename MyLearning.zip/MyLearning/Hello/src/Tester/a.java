package Tester;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

class Worker extends Thread 
{ 
    private int delay; 
    private CyclicBarrier latch; 
   // CountDownLatch latch;
  
    public Worker(int delay, CyclicBarrier latch, 
                                    String name) 
    { 
        super(name); 
        this.delay = delay; 
        this.latch = latch; 
    } 
  
    @Override
    public void run() 
    { 
        try
        { 
        	
        	Thread.sleep(delay); 
        	 System.out.println(Thread.currentThread().getName() 
                     + " Started"); 
        	
            Thread.sleep(delay); 
            System.out.println(Thread.currentThread().getName() 
                    + " Finished");
            try {
				latch.await();
			} catch (BrokenBarrierException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            System.out.println(Thread.currentThread().getName() 
                    + " Finished....");
            
        } 
        catch (InterruptedException e) 
        { 
            e.printStackTrace(); 
        } 
    } 
} 