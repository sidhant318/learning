package Learning;

public class A implements A1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
A1 a=new A1() {
	
	@Override
	public void m1() {
		// TODO Auto-generated method stub
		
	}
};
	}

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		
	}



}