package Learning;

@FunctionalInterface
public interface A1 {
	
	void m1();
//	void m2();

}
