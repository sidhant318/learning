package DataStructure;

class Entry<K,V>{
	K key;
	V value;
	Entry<K,V> next;
	Entry(K key,V value,Entry<K,V> next){
		this.key=key;
		this.value=value;
		this.next=next;
	}
}

public class HashMapImpl<K, V> {
	
	Entry<K,V>[] bucket;
	int INITIAL_CAPACITY=16;
	
	HashMapImpl(){
		bucket=new Entry[INITIAL_CAPACITY];
	}
	
	HashMapImpl(int capacity){
		INITIAL_CAPACITY=capacity;
		bucket=new Entry[INITIAL_CAPACITY];
	}
	
	private int index(K key) {
		return ((hashvalue(key))%(bucketSize()));
	}
	
	private int bucketSize() {
		return INITIAL_CAPACITY;
	}

	private int hashvalue(K key) {
		return key==null?0:key.toString().charAt(0)*31;
	}

	void put(K key,V value) {
		Entry<K,V> e=new Entry<>(key, value, null);
		int index=index(key);
		Entry<K,V> tmp=bucket[index];
		if(tmp==null) {
			bucket[index]=e;
		}
		else {
			while(tmp.next!=null) {
				if(tmp.key.equals(key)) {
					tmp.value=value;
					return;
				}
				tmp=tmp.next;
			}
			if(tmp.key.equals(key)) {
				tmp.value=value;
				return;
			}
			tmp.next=e;
		}
	}
	
	V get(K key) {
		int index=index(key);
		Entry<K,V> e=bucket[index];
		while(e!=null) {
			if(e.key.equals(key)) {
				return e.value;
			}
			e=e.next;
		}
		return null;
	}
	
	
	public static void main(String[] arg) {
		HashMapImpl<String, Integer> hm=new HashMapImpl<String, Integer>();
		hm.put("Sidhant", 100);
		hm.put("Aman", 200);
		hm.put("Aman", 250);
		System.out.println(hm.get("Aman"));
		
	}

}
