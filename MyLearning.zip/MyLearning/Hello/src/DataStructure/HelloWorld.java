package DataStructure;
public class HelloWorld{

     public static void main(String []args){
        A b = new B();
        b.print();
     }
}


class A {
    public A() {
        print();
    }
    public void print() {
        System.out.println("A");
    }
}

class B extends A {
    public B() {
        print();
    }
    public void print() {
        System.out.println("B");
    }
}