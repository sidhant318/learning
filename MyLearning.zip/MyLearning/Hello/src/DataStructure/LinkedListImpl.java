package DataStructure;
class MyLinkList{
	Nodes head;
	static class Nodes{
		int data;
		Nodes next;
		Nodes(int data){
			this.data=data;
		}
	}
	void addAt(int data,int index) {
		Nodes n=new Nodes(data);
		Nodes tra=head;
		int counter=0;
		while(tra!=null) {
			if(counter+1==index) {
				n.next=tra.next;
				tra.next=n;
				break;
			}
			else {
				counter++;
				tra=tra.next;
			}
		}
	}
	void addAtLast(int data) {
		Nodes n=new Nodes(data);
		if(head==null) {
			n.next=head;
			head=n;
			return;
		}
		Nodes tmp=head;
		while(tmp.next!=null) {
			tmp=tmp.next;
		}
		n.next=tmp.next;
		tmp.next=n;
	}
	void add(int data) {
		Nodes n=new Nodes(data);
		n.next=head;
		head=n;
	}
	void print() {
		Nodes n=head;
		System.out.println("Linked List");
		while(n!=null) {
			System.out.println(n.data);
			n=n.next;
		}
	}
	int size() {
		Nodes n=head;
		int counter=0;
		while(n!=null) {
			counter++;
			n=n.next;
		}
		return counter;
	}
	void delete(int dat) {
		Nodes n=head,prev=null;
		if(n!=null && n.data==dat) {
			head=n.next;
			return;
		}
		while(n!=null && n.data!=dat) {
			prev=n;
			n=n.next;
		}
		if(n==null)
			return ;
		prev.next=n.next;
	}
	void deleteLast() {
		Nodes n=head,prev=null;
		while(n.next!=null) {
			prev=n;
			n=n.next;
		}
		prev.next=n.next;
	}
	void deleteAt(int index) {
		Nodes n=head,prev=null;
		if(index==0) {
			head=n.next;
			return;
		}
		int counter=1;
		while(n!=null && counter!=index) {
			prev=n;
			n=n.next;
			counter++;
		}
		if(n==null)
			return;
		prev.next=n.next;
	}
}


public class LinkedListImpl {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyLinkList myLinkList=new MyLinkList();
		myLinkList.add(10);
		myLinkList.add(20);
		myLinkList.add(30);
		myLinkList.addAt(40,3);
		myLinkList.addAtLast(50);
		myLinkList.deleteLast();
		//myLinkList.delete(30);
		//myLinkList.deleteAt(3);
		myLinkList.print();
		System.out.println("Size of Linked List : "+myLinkList.size());
		
	}

}
