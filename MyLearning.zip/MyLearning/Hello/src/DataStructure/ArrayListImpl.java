package DataStructure;

import java.util.Arrays;

class MyArrayList{
	Object[] obj;
	int counter=0;
	int size=0;
	public MyArrayList() {
		size=10;
		obj=new Object[size];
	}
	
	void add(Object o) {
		if(obj.length-counter<=size/2) {
			increseListSize();
		}
		obj[counter++]=o;
	}
	void addAt(int index,Object o) {
		Object tmp;
		if(obj.length-counter<=size/2) {
			increseListSize();
		}
		for(int i=index;i<=size();i++) {
			tmp=obj[i];
			obj[i]=o;
			o=tmp;
		}
		counter++;
	}
	//remove
	void remove(int index) {
		if(index>counter) {
			throw new ArrayIndexOutOfBoundsException();
		}
		for(int i=index;i<size();i++) {
			obj[i]=obj[i+1];
			obj[i+1]=null;
		}
		counter--;
	}
	//get
	Object get(int index) {
		if(index>counter) {
			throw new ArrayIndexOutOfBoundsException();
		}
		return obj[index];
	}
	int size() {
		return counter;
	}
	void increseListSize() {
		obj=Arrays.copyOf(obj, ((size*3)/2)+1);
	}
}
public class ArrayListImpl {
	public static void main(String[] args) {
		MyArrayList myList=new MyArrayList();
		myList.add(10);
		myList.add(20);
		myList.add(30);
		myList.add(40);
		myList.addAt(1,50);
		for(int i=0;i<myList.size();i++) {
			System.out.println(myList.get(i));
		}
//		myList.remove(0);
//		for(int i=0;i<myList.size();i++) {
//			System.out.println(myList.get(i));
//		}
		//System.out.println(myList.get(-1));

	}

}
