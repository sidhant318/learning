
public class RepeatElement 
{ 
    public static void main(String[] args)  
    { 
        RepeatElement repeat = new RepeatElement(); 
        int arr[] = {10, 9, 4, 8, 7,5,4,2,8,9,7,1,3, 2}; 
        int arr_size = arr.length; 
       // System.out.println(arr[arr_size]);
       // repeat.printRepeating(arr, arr_size); 
       String a= repeat.returnString(3456);
       System.out.println(a);
       printString(26);
    }

	private static void printString(int column) {
		StringBuilder columnName = new StringBuilder(); 
		while(column>0) {
			
		}
		
	}

	private String returnString(int i) {
		return ""+i;
	}

	private void printRepeating(int[] arr, int arr_size) {
		int start=0;
		int end=arr_size-1;
		for(int i=0;i<arr_size;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		while(start<end) {
			if(arr[start]%2==0 && arr[end]%2==0) {
				start++;
			}
			else if(arr[start]%2!=0 && arr[end]%2!=0) {
				end--;
			}
			else if(arr[start]%2==0) {
				start++;
			}
			else{
				int tmp=arr[start];
				arr[start]=arr[end];
				arr[end]=tmp;
				start++;
				end--;
			}
		}
		for(int i=0;i<arr_size;i++) {
			System.out.print(arr[i]+" ");
		}
	} 
} 
