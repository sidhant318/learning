package Tree;

public class BinarySearchData {
	Node root;

	public static void main(String[] args) {
		BinarySearchData bt=new BinarySearchData();
		bt.insert(8);
		bt.insert(3);
		bt.insert(1);
		bt.insert(6);
		bt.insert(4);
		bt.insert(7);
		bt.insert(10);
		bt.insert(14);
		bt.insert(13);
		bt.delete(3);
		bt.print();
		

	}

	private void delete(int i) {
		deleteData(root,i);
	}

	private Node deleteData(Node root2, int data) {
		if(root2==null)
			return root2;
		if(data<root2.data) {
			root2.left=deleteData(root2.left, data);
		}else if(data>root2.data) {
			root2.right=deleteData(root2.right,data);
		}
		else {
			if(root2.left==null || root2.right==null) {
				Node tmp=null;
				tmp=root2.left==null?root2.right:root2.left;
				if(tmp==null) {
					return null;
				}
				else {
					return tmp;
				}
			}
			else {
				Node val=sucsessor(root2);
				root2.data=val.data;
				root2.right=deleteData(root2.right, val.data);
			}
		}
		return root2;
	}

	private Node sucsessor(Node root2) {
		Node n=root2.right;
		while(n.left!=null) {
			n=n.left;
		}
		return n;
	}

	private void insert(int data) {
		
		root=insertData1(root,data);	
	}

	private Node insertData(Node root2, int data) {
		Node n=null;
		if(root2.data>=data) {
			if(root2.left==null) {
				root2.left=new Node(data);
				return root2.left;
			}
			n=root2.left;
		}
		else {
			if(root2.right==null) {
				root2.right=new Node(data);
				return root2.right;
			}
			n=root2.right;
		}
		return insertData(n, data);
	}
	
	private Node insertData1(Node root2, int data) {
		if(root2==null) {
			return new Node(data);
		}
		if(root2.data>=data) {
			root2.left=insertData1(root2.left, data);
		}
		else if(root2.data<data){
			root2.right=insertData1(root2.right, data);
		}
		return root2;
	}

	private void print() {
		printData(root);
	}

	private void printData(Node root2) {
		if(root2==null)
			return;
		printData(root2.left);
		System.out.print(root2.data+" , ");
		printData(root2.right);
	}

}
