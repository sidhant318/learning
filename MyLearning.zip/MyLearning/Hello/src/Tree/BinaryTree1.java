package Tree;

public class BinaryTree1 {
	
	Node root;
	public static void main(String[] arg) {
		BinaryTree1 bt=new BinaryTree1();
		bt.root=new Node(1);
		bt.root.left=new Node(2);
		bt.root.right=new Node(3);
		bt.root.left.left=new Node(4);
		bt.root.left.right=new Node(5);
		bt.insert(6);
		bt.print();
	}
	private void insert(int i) {
		root=insertData(root,i);
	}
	private Node insertData(Node node,int data) {
		if(node==null) {
			node=new Node(data);
		}
		else {
			if(node.right==null)
				node.right=insertData(node.right, data);
			else
				node.left=insertData(node.left, data);
		}
			return node;
		
	}
	private void print() {
		printData(root);
	}
	private void printData(Node node) {
		if(node==null)
			return;
		printData(node.left);
		System.out.println(node.data);
		printData(node.right);
	}

}
