//package com.siemens.crspng.security.users.api;
//
//import java.net.URI;
//import java.sql.Timestamp;
//import java.time.LocalDate;
//import java.time.ZoneId;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.LinkedList;
//import java.util.List;
//import java.util.Map;
//import java.util.stream.Collectors;
//import java.util.stream.Stream;
//
//import javax.annotation.Resource;
//import javax.servlet.http.HttpServletRequest;
//import javax.validation.Valid;
//import javax.ws.rs.QueryParam;
//
//import org.apache.commons.collections.CollectionUtils;
//import org.apache.commons.lang.StringUtils;
//import org.json.JSONObject;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cloud.sleuth.Span;
//import org.springframework.data.domain.Page;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.jwt.Jwt;
//import org.springframework.security.jwt.JwtHelper;
//import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestHeader;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.ResponseStatus;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
//
//import com.auth0.jwt.JWT;
//import com.auth0.jwt.exceptions.JWTDecodeException;
//import com.auth0.jwt.interfaces.Claim;
//import com.auth0.jwt.interfaces.DecodedJWT;
//import com.google.gson.Gson;
//import com.siemens.crspng.commons.accesstoken.service.AccessTokenValidationService;
//import com.siemens.crspng.commons.audit.entity.CrspngOperationStatusEnum;
//import com.siemens.crspng.commons.audit.service.AuditQueue;
//import com.siemens.crspng.commons.audit.wrapper.AuditDetails;
//import com.siemens.crspng.commons.constant.CrspngCommonsConstant;
//import com.siemens.crspng.commons.controller.CrspNgBaseController;
//import com.siemens.crspng.commons.enums.EventType;
//import com.siemens.crspng.commons.enums.OriginatingActionType;
//import com.siemens.crspng.commons.exceptions.UnauthorizedUserException;
//import com.siemens.crspng.commons.granularoauth.annotation.GranularEndPoint;
//import com.siemens.crspng.commons.granularoauth.annotation.TechGranularEndPoint;
//import com.siemens.crspng.commons.search.util.CustomCrspngRsqlSpecification;
//import com.siemens.crspng.commons.wrapper.AuthzRequest;
//import com.siemens.crspng.commons.wrapper.TokenUser;
//import com.siemens.crspng.commons.wrapper.UserOrDeviceFailedDeleteList;
//import com.siemens.crspng.commons.wrapper.UserOrDeviceFailedDeleteListRootDto;
//import com.siemens.crspng.security.config.SecurityServiceConfig;
//import com.siemens.crspng.security.data.role.Roles;
//import com.siemens.crspng.security.data.role.RolesDataService;
//import com.siemens.crspng.security.exception.DefaultFlagRequiredException;
//import com.siemens.crspng.security.exception.InvalidAccountStatus;
//import com.siemens.crspng.security.exception.InvalidRoleAssociationException;
//import com.siemens.crspng.security.exception.InvalidUserException;
//import com.siemens.crspng.security.exception.PayloadArgumentException;
//import com.siemens.crspng.security.exception.UserCreationException;
//import com.siemens.crspng.security.exception.UserDeletionException;
//import com.siemens.crspng.security.exception.UserDeniedAuthorizationException;
//import com.siemens.crspng.security.grants.facade.impl.GrantFacadeImpl;
//import com.siemens.crspng.security.onboarding.service.OnBoardingService;
//import com.siemens.crspng.security.pagination.PageResource;
//import com.siemens.crspng.security.service.RoleService;
//import com.siemens.crspng.security.users.dao.UserRoleDao;
//import com.siemens.crspng.security.users.entity.IUserDetails;
//import com.siemens.crspng.security.users.entity.UserRole;
//import com.siemens.crspng.security.users.entity.UsersEntity;
//import com.siemens.crspng.security.users.repository.CrspngUsersRepository;
//import com.siemens.crspng.security.users.service.CommonService;
//import com.siemens.crspng.security.users.service.MSUserServiceImpl;
//import com.siemens.crspng.security.users.service.UsersDataService;
//import com.siemens.crspng.security.users.wrapper.AccountStatusEnum;
//import com.siemens.crspng.security.users.wrapper.AggregatedPagingUserResponse;
//import com.siemens.crspng.security.users.wrapper.AggregatedUserResponse;
//import com.siemens.crspng.security.users.wrapper.AssignedRoleResponse;
//import com.siemens.crspng.security.users.wrapper.CreateUserRequest;
//import com.siemens.crspng.security.users.wrapper.GetInternalUserCollection;
//import com.siemens.crspng.security.users.wrapper.GetRolesResponse;
//import com.siemens.crspng.security.users.wrapper.GetUserCollection;
//import com.siemens.crspng.security.users.wrapper.GetUserInfoResponse;
//import com.siemens.crspng.security.users.wrapper.InternalRoleUsersMapper;
//import com.siemens.crspng.security.users.wrapper.OndemandData;
//import com.siemens.crspng.security.users.wrapper.RolesResponse;
//import com.siemens.crspng.security.users.wrapper.UpdateUserBulkRequest;
//import com.siemens.crspng.security.users.wrapper.UpdateUserRequest;
//import com.siemens.crspng.security.users.wrapper.UserConnections;
//import com.siemens.crspng.security.users.wrapper.UserFieldEnum;
//import com.siemens.crspng.security.users.wrapper.UserId;
//import com.siemens.crspng.security.users.wrapper.UserRoleListL1ResponseWrapper;
//import com.siemens.crspng.security.users.wrapper.UserRoleListRootResponseWrapper;
//import com.siemens.crspng.security.users.wrapper.UserWithRoleResponse;
//import com.siemens.crspng.security.users.wrapper.UsergroupUsersResponse;
//import com.siemens.crspng.security.users.wrapper.UsersTermsUsageEnum;
//
//import ch.qos.logback.classic.Logger;
//
//@RestController
//public class UserController extends CrspNgBaseController {
//
//	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger("UserController.class");
//
//	@Resource(name = "userDataService")
//	private UsersDataService userDataService;
//
//	// @Autowired
//	// private DataServiceConfig dataServiceConfig;
//
//	// @Autowired
//	// private UserRoleService userRoleService;
//
//	public static final String ACCESS_TOKEN = "access-token";
//	public static final String USERID = "userId";
//	public static final String CRSPNG_REMOTE_USER = "ng.role.remote_user";
//	public static final String CRSPNG_TENANT_ADMIN = "ng.role.tenant_admin";
//	public static final String CRSPNG_SUPER_USER = "ng.role.super_user";
//	public static final String PAGE_NUMBER = "page_number";
//	public static final String PAGE_SIZE = "page_size";
//	public static final String SORT_PROPERTY = "sort_property";
//	public static final String SORT_ASCENDING = "sort_ascending";
//	public static final String REPORT = "report";
//	private static final String TENANT_ID = "tenant_id";
//	private static final String SUB_TENANT_ID = "sub_tenant_id";
//	private static final String GET_GENERIC_REPORT = "internal/getGenericReport";
//
//	@Autowired
//	private AuditQueue auditQueue;
//
//	@Autowired
//	private SecurityServiceConfig securityServiceConfig;
//
//	@Autowired
//	private RolesDataService rolesDataService;
//
//	@Resource(name = "userRoleDao")
//	private UserRoleDao userRoleDao;
//
//	@Autowired
//	private HttpServletRequest httpServletRequest;
//
//	@Autowired
//	private RoleService roleService;
//
//	@Autowired
//	private MSUserServiceImpl msUserServiceImpl;
//
//	@Autowired
//	private GrantFacadeImpl grantFacadeImpl;
//
//	@Autowired
//	private AccessTokenValidationService tokenValidationService;
//
//	@Autowired
//	private CommonService commonService;
//
//	@Autowired
//	private OnBoardingService onBoardingService;
//
//	@Autowired
//	CrspngUsersRepository userRepository;
//
//	/**
//	 * user info details using access token.
//	 * 
//	 * @param crspNgHeaderToken
//	 *            , access token.
//	 * @return GetUserInfoResponse : user info response.
//	 * 
//	 */
//	@CrossOrigin
//	@GetMapping("/old/userinfo")
//	@GranularEndPoint(name = "GET_USERINFO", uri = "/userinfo")
//	public @ResponseBody GetUserInfoResponse getUserInfo(
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken) {
//		// TokenUser tokenUser = (TokenUser)
//		// httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		TokenUser tokenUser = extractTokenUserForMS(crspNgHeaderToken);
//		httpServletRequest.setAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER, tokenUser);
//		LOGGER.info("TokenUser found to be in userinfo {}", tokenUser);
//		String mindsphereId = msUserServiceImpl.getUserIdForGivenEmail(tokenUser.getEmail(), tokenUser);
//		if (StringUtils.isEmpty(mindsphereId)) {
//			throw new InvalidUserException("Invalid User!");
//		}
//
//		final UsersEntity user = userDataService.getUserByEmail(tokenUser.getEmail(), tokenUser);
//
//		if (user == null) {
//			CreateUserRequest request = new CreateUserRequest();
//			String[] split = tokenUser.getEmail().split("@");
//			String firstName;
//			String lastName;
//			if (split[0].contains(".")) {
//				firstName = split[0].substring(0, split[0].indexOf("."));
//				lastName = split[0].substring(split[0].indexOf(".") + 1);
//			} else {
//				firstName = split[0];
//				lastName = split[0];
//			}
//			request.setFirstname(firstName);
//			request.setLastname(lastName);
//			request.setEmail(tokenUser.getEmail());
//			request.setPhoneNumber("9999999999");
//			request.setDepartment("department");
//			request.setSiemensGid("gid");
//			request.setDuration(12);
//			if (!request.getEmail().endsWith("@siemens.com")) {
//				request.setBillingId("");
//			}
//			request.setAccountStatus(AccountStatusEnum.READY);
//			UsersEntity createdUser = createUser(request, crspNgHeaderToken, tokenUser);
//			return userDataService.getUserInfo(createdUser.getId(), crspNgHeaderToken, tokenUser);
//		}
//		checkAccountStatusAndValidity(user);
//		return userDataService.getUserInfo(user.getId(), crspNgHeaderToken, tokenUser);
//	}
//
//	private void checkAccountStatusAndValidity(final UsersEntity user) {
//		if (user.getStartDate() == null || user.getExpiryDate() == null) {
//			LOGGER.warn("start date or end date is null");
//			throw new InvalidAccountStatus("Invalid Account status");
//		}
//		Date currentDate = new Date();
//		LocalDate now = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
//		LocalDate startDate = user.getStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
//		LocalDate expiryDate = user.getExpiryDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
//		if (user.getAccountStatus().toString().equals("READY") && !now.isBefore(startDate)
//				&& !now.isAfter(expiryDate)) {
//			// No redirect
//			LOGGER.info("ACCESS ALLOWED for user " + user.getEmail());
//		} else {
//			LOGGER.warn("ACCESS DENIED for user " + user.getEmail());
//			// Throw exception here
//			throw new InvalidAccountStatus("Invalid Account status");
//		}
//	}
//
//	public TokenUser extractTokenUserForMS(String mindsphereToken) {
//
//		DecodedJWT decode;
//		try {
//			decode = JWT.decode(mindsphereToken);
//		} catch (JWTDecodeException e) {
//			LOGGER.error("unable to decode mindsphere token in extractTokenUserForMS method, exception : {}", e);
//			throw new UnauthorizedUserException("Unauthorised attempt!");
//		}
//		Map<String, Claim> claims = decode.getClaims();
//		TokenUser tokenUser = new TokenUser();
//		String email = claims.get("email").asString();
//		tokenUser.setEmail(email);
//		List<String> avialableScopesForUser = claims.get("scope").asList(String.class);
//		if (claims.get("ten") != null) {
//			String app = claims.get("client_id").asString().split("-")[0];
//			String appName = (Arrays.asList("crspng", "crsp", "crspngdev").contains(app)) ? "crsp" : app;
//			// tokenUser.setAppName(appName);
//			// tokenUser.setTenantName(claims.get("ten").toString());
//
//			avialableScopesForUser = avialableScopesForUser.stream().filter(scope -> {
//				return scope.startsWith(appName) ? true : false;
//			}).map(scope -> {
//				return "ng." + scope.substring(scope.indexOf(".") + 1);
//			}).collect(Collectors.toList());
//
//			Jwt decodedJwt = JwtHelper.decode(mindsphereToken);
//			String claims1 = decodedJwt.getClaims();
//			JSONObject jsonObject = new JSONObject(claims1);
//			if (jsonObject.get("ten") != null) {
//				tokenUser.setTenant_id(String.valueOf(jsonObject.get("ten")));
//			}
//		}
//		Map<String, List<String>> map = new HashMap<>();
//		Gson gson = new Gson();
//		map.put("scope", avialableScopesForUser);
//		String scopeJson = gson.toJson(map);
//		tokenUser.setRole(scopeJson.substring(scopeJson.indexOf("["), scopeJson.indexOf("]") + 1));
//		return tokenUser;
//	}
//
//	/**
//	 * This method is called when user is onboarded in Mindsphere but not in
//	 * cRSPNG, then on login during call of userinfo user will be onboarded by
//	 * this method.
//	 * 
//	 * @param request
//	 *            : Create user request.
//	 * @param crspNgHeaderToken
//	 *            : token for api.
//	 * @param tokenUser
//	 *            : tokenuser object.
//	 * @return
//	 */
//	private UsersEntity createUser(CreateUserRequest request, String crspNgHeaderToken, TokenUser tokenUser) {
//		LOGGER.info("Entered createUser() method for MindShere onboarding in UserController..");
//		checkToken(crspNgHeaderToken);
//		UsersEntity user = request.createEntity(tokenUser);
//		String createdBy = "mindsphere";
//		user.setCreatedBy(user.getEmail());
//		user.setModifiedBy(createdBy);
//		user.setIdProvider("webkey");
//		String msphUserId = msUserServiceImpl.getUserIdForGivenEmail(request.getEmail(), tokenUser);
//		user.setMsphUserId(msphUserId);
//		UsersEntity savedUser = userDataService.createUser(user, tokenUser);
//		LOGGER.info("MindSphere user is created for Email : {}", savedUser.getEmail());
//		if (StringUtils.isNotEmpty(savedUser.getId())) {
//			LOGGER.info("Creating operator client.");
//			try {
//				userDataService.createOperatorClient(savedUser, tokenUser);
//			} catch (UserCreationException e) {
//				LOGGER.error("Error occured with exception {}", e);
//				List<String> userIds = new ArrayList<String>();
//				userIds.add(savedUser.getId());
//
//				userDataService.delete(userIds, crspNgHeaderToken, false, tokenUser, true);
//
//				LOGGER.error(
//						"Exception thrown from createUser() for MindSphere onboarded entities in UserController. Could not create operator client. ",
//						e.getMessage());
//				// throw new RuntimeException("Could not create operator client.
//				// " + e);
//				String userType = StringUtils.lowerCase(request.getEmail())
//						.endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN) ? CrspngCommonsConstant.INTERNAL_USER
//								: CrspngCommonsConstant.EXTERNAL_USER;
//				commonService.logException(tokenUser, "CREATE " + userType.toUpperCase() + " USER",
//						"Could not create operator client.", "CREATE " + userType.toUpperCase() + " USER");
//				throw new UserCreationException("Could not create operator client. ");
//			}
//			boolean defaultRole = true;
//			try {
//				LOGGER.info("Roles:: " + tokenUser.getRole());
//				if (tokenUser.getRole().contains("rdp.ondemandconnetivity.connect")) {
//					Roles roles = roleService.fetchRoleDetailsByName(CRSPNG_REMOTE_USER, tokenUser.getTenant_id());
//					userDataService.associateRoleToMindspherUser(roles, savedUser.getId(), defaultRole, false,
//							crspNgHeaderToken, tokenUser);
//					defaultRole = false;
//					LOGGER.info("For mindSphere user, Remote role is assigned");
//				}
//				if (tokenUser.getRole().contains("ds.user.create")) {
//					Roles roles = roleService.fetchRoleDetailsByName(CRSPNG_TENANT_ADMIN, tokenUser.getTenant_id());
//					LOGGER.info("Associating role to user.");
//					userDataService.associateRoleToMindspherUser(roles, savedUser.getId(), defaultRole, false,
//							crspNgHeaderToken, tokenUser);
//					// FIXME : Default grant not required
//					/*
//					 * userDataService.defaultGrantsToOnDemandProductAndSite(
//					 * crspNgHeaderToken, savedUser.getId(), roles.getId(),
//					 * tokenUser);
//					 */
//					LOGGER.info("For mindSphere user, Admin role is assigned");
//				}
//			} catch (Exception exception) {
//				LOGGER.error("User Role creation issue::" + tokenUser.getRole() + " exception:" + exception);
//			}
//		}
//		// for system log
//		String userType = StringUtils.lowerCase(savedUser.getEmail()).endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN)
//				? CrspngCommonsConstant.INTERNAL_USER : CrspngCommonsConstant.EXTERNAL_USER;
//		String eventSource = "USER: USER_ID: " + tokenUser.getUser_id().toString() + ",USER_NAME: "
//				+ savedUser.getUserName().toUpperCase() + ",ACCOUNT_STATUS: " + savedUser.getAccountStatus()
//				+ ",OPERATION_STATUS: SUCCESS";
//		String eventDescription = "CREATE " + userType.toUpperCase() + " USER";
//		String deviceId = "";
//		auditUser(tokenUser, savedUser.getId(), "CREATE_USER", eventSource, eventDescription, deviceId);
//		return savedUser;
//	}
//
//	/**
//	 * This method is used to produce JSON response with details of all user
//	 * created.
//	 *
//	 * @param crspNgHeaderToken
//	 * @return
//	 */
//
//	@CrossOrigin
//	@GetMapping("/users")
//	@GranularEndPoint(name = "GET_USER", uri = "/users")
//	public @ResponseBody List<AggregatedUserResponse> getAllUser(
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken) {
//		Date currentDate = new Date();
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		/* Pep changes */
//		AuthzRequest authzRequest = new AuthzRequest.AuthzRequestBuilder(
//				securityServiceConfig.getServiceNameForPep(), securityServiceConfig.getUserForPep(),
//				String.valueOf(tokenUser.getUser_id())).build();
//		String pepResponse = authorize(crspNgHeaderToken, authzRequest);
//		if (pepResponse != null && pepResponse.equals("Deny")) {
//			throw new UserDeniedAuthorizationException("Unauthorized attempt!");
//		}
//		LOGGER.info("UserId pep response : "+pepResponse);
//		//Should get list of users from pep and return it here. Use it to pass it to data service.
//		List<UsersEntity> allUsers = userDataService.getAllUsers(tokenUser);
//		List<AggregatedUserResponse> newList = new ArrayList<>();
//
//		Map<String, List<AssignedRoleResponse>> userRolesMap = userDataService.getRolesForAllUser(allUsers,
//				tokenUser.getTenant_id());
//
//		for (UsersEntity obj : allUsers) {
//			AggregatedUserResponse colection = new AggregatedUserResponse();
//			colection.setId(obj.getId());
//			colection.setEmail(obj.getEmail() != null ? obj.getEmail() : "");
//			colection.setFirstname(obj.getFirstName() != null ? obj.getFirstName() : "");
//			colection.setLastname(obj.getLastName() != null ? obj.getLastName() : "");
//			colection.setAnnotation(obj.getAnnotation() != null ? obj.getAnnotation() : "");
//			colection.setAccountStatus(obj.getAccountStatus());
//			colection.setAssignedLocation(obj.getAssignedLocation() != null ? obj.getAssignedLocation() : "");
//			colection.setCreatedBy(obj.getCreatedBy() != null ? obj.getCreatedBy() : "");
//			colection.setDepartment(obj.getDepartmentName() != null ? obj.getDepartmentName() : "");
//			colection.setDuration(obj.getDuration() != null ? obj.getDuration() : 0);
//			colection.setModifiedBy(obj.getModifiedBy() != null ? obj.getModifiedBy() : "");
//			colection.setPhoneNumber(obj.getPhoneNo() != null ? obj.getPhoneNo() : "");
//			colection.setUserName(obj.getUserName() != null ? obj.getUserName() : "");
//			colection.setSiemensGid(obj.getSiemensGid() != null ? obj.getSiemensGid() : "");
//			colection.setBillingId(obj.getBillingId() != null ? obj.getBillingId() : "");
//			colection.setMaxTunnel(obj.getMaxTunnel());
//			colection.setExistingTunnelCount(obj.getExistingTunnelCount());
//			if (obj.getExpiryDate() != null) {
//				if (obj.getExpiryDate().compareTo(currentDate) < 0) {
//					colection.setAccountStatus(AccountStatusEnum.EXPIRED);
//				}
//				colection.setExpiryDate(CustomCrspngRsqlSpecification.convertDateToString(obj.getExpiryDate()));
//			}
//			if (obj.getCreationDate() != null) {
//				colection.setCreationDate(CustomCrspngRsqlSpecification.convertDateToString(obj.getCreationDate()));
//			}
//			colection.setLastModifiedDate(obj.getLastModifiedDate() != null
//					? CustomCrspngRsqlSpecification.convertDateTimeToString(obj.getLastModifiedDate()) : "");
//			if (obj.getStartDate() != null) {
//				colection.setStartDate(CustomCrspngRsqlSpecification.convertDateToString(obj.getStartDate()));
//			}
//			/*
//			 * GetRolesResponse getRolesResponse =
//			 * userDataService.getRolesForUser(obj.getId());
//			 * List<AssignedRoleResponse> roles = null; if (getRolesResponse !=
//			 * null) { roles = getRolesResponse.getRoles(); }
//			 */
//			colection.setRoles(userRolesMap.get(obj.getId()));
//			newList.add(colection);
//		}
//		return newList;
//	}
//
//	/**
//	 * Internal call
//	 *
//	 * @return
//	 */
//	@CrossOrigin
//	@GetMapping("/users/internal/search")
//	@TechGranularEndPoint(name = "GET_USER_BY_EMAIL", uri = "/users/internal/search")
//	public @ResponseBody GetInternalUserCollection getUserByEmail(@RequestParam("email") String email,
//			@RequestHeader(value = TENANT_ID) String tenantId,
//			@RequestHeader(value = SUB_TENANT_ID) String subtenantId) {
//		TokenUser tokenUser = new TokenUser();
//		tokenUser.setTenant_id(StringUtils.stripToNull(tenantId));
//		tokenUser.setSub_tenant_id(StringUtils.stripToNull(subtenantId));
//		LOGGER.info("Calling getUserByEmail() method in UserController.. for email : " + email + ", tenantID: "
//				+ tokenUser.getTenant_id() + " and subTenantID: " + tokenUser.getSub_tenant_id());
//		List<IUserDetails> userDetails = userDataService.findUserInfoByEmailAndTenant(email, tokenUser.getTenant_id());
//		GetInternalUserCollection user = new GetInternalUserCollection();
//		
//        if (CollectionUtils.isNotEmpty(userDetails)) {
//               LOGGER.info("User details is not null.");
//               IUserDetails usrDtls = userDetails.get(0);
//               user.setId(usrDtls.getId());
//               user.setEmail(usrDtls.getEmail());
//               user.setAccountStatus(usrDtls.getAccountStatus());
//               user.setFirstName(usrDtls.getFirstName());
//               user.setLastName(usrDtls.getLastName());
//               user.setTenantid(usrDtls.getTenantId());
//               user.setActiveRole(usrDtls.getRoleName());
//               user.setUserName(usrDtls.getFirstName()+ " "+usrDtls.getLastName());
//        } else {
//                LOGGER.info("User details is null.");
//                throw new UserDeniedAuthorizationException("");
//        }
//		LOGGER.info("User details is not null.");
//		return user;
//	}
//
//	/**
//	 * This method is used to get user based on email.
//	 *
//	 * @param userId
//	 * @param crspNgHeaderToken
//	 * @return
//	 */
//	@CrossOrigin
//	@GetMapping("/users/{userId}")
//	@GranularEndPoint(name = "GET_USER_UNIQUE", uri = "/users/{userId}")
//	public @ResponseBody GetUserCollection getUniqueUserDetails(@PathVariable(USERID) String userId,
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken) {
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		UsersEntity user = userDataService.getUniqueUser(userId, tokenUser);
//		GetRolesResponse getRolesResponse = userDataService.getRolesForUser(userId, tokenUser);
//		List<AssignedRoleResponse> roles = null;
//		if (getRolesResponse != null) {
//			roles = getRolesResponse.getRoles();
//		}
//		GetUserCollection userResponse = new GetUserCollection(user, roles);
//		userDataService.getCreatedByandModifiedBy(userResponse, user, tokenUser);
//		return userResponse;
//	}
//
//	/**
//	 * This method is used to create user and save the entity in table with JSON
//	 * request.
//	 *
//	 * @param request
//	 * @param crspNgHeaderToken
//	 * @return
//	 */
//	@CrossOrigin(exposedHeaders = "Location")
//	@PostMapping("/users")
//	@ResponseStatus(code = HttpStatus.CREATED)
//	@GranularEndPoint(name = "CREATE_USER", uri = "/users")
//	public @ResponseBody ResponseEntity<UsersEntity> createUser(@RequestBody @Valid CreateUserRequest request,
//			BindingResult result, @RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken) {
//
//		LOGGER.info("UserController >> createUser method ivoked " + request.toString());
//		String userType = StringUtils.lowerCase(request.getEmail()).endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN)
//				? CrspngCommonsConstant.INTERNAL_USER : CrspngCommonsConstant.EXTERNAL_USER;
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		if (result.hasErrors()) {
//			commonService.logException(tokenUser, "CREATE " + userType.toUpperCase() + " USER",
//					"Payload argument exception", "CREATE " + userType.toUpperCase() + " USER");
//			throw new PayloadArgumentException(result);
//		}
//		AuthzRequest authzRequest = new AuthzRequest.AuthzRequestBuilder(securityServiceConfig.getServiceNameForPep(),
//				securityServiceConfig.getUserPostForPep(), String.valueOf(tokenUser.getUser_id())).build();
//		String pepResponse = authorize(crspNgHeaderToken, authzRequest);
//		if (pepResponse != null && pepResponse.equals("Deny")) {
//			String userType1 = StringUtils.lowerCase(tokenUser.getEmail())
//					.endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN) ? CrspngCommonsConstant.INTERNAL_USER
//							: CrspngCommonsConstant.EXTERNAL_USER;
//			commonService.logException(tokenUser, "CREATE " + userType1.toUpperCase() + " USER",
//					"Unauthorized attempt!", "CREATE " + userType1.toUpperCase() + " USER");
//			throw new UserDeniedAuthorizationException("Unauthorized attempt!");
//		}
//		
//		UsersEntity user = request.createEntity(tokenUser);
//		userDataService.populateCreatedBy(user, tokenUser);
//		user.setIdProvider("webkey");
//		UsersEntity savedUser = userDataService.createUser(user, tokenUser);
//		if (StringUtils.isNotEmpty(savedUser.getId())) {
//			// commenting out as a part of crsp-768
//			// userDataService.createUserInUAA(request);
//			LOGGER.info("Creating operator client.");
//			try {
//				userDataService.createOperatorClient(savedUser, tokenUser);
//			} catch (UserCreationException e) {
//				LOGGER.error("Error occured with exception {}", e);
//				LOGGER.error(
//						"Exception thrown from createUser() method in UserController. Could not create operator client. ",
//						e.getMessage());
//				List<String> userIds = new ArrayList<String>();
//				userIds.add(savedUser.getId());
//				LOGGER.error(
//						"Calling userDataService.delete() method as operator client could not be created. User id: "
//								+ savedUser.getId());
//
//				userDataService.delete(userIds, crspNgHeaderToken, false, tokenUser, true); // userDeletionFlow
//																							// deletes
//																							// user
//																							// from
//																							// UAA
//				commonService.logException(tokenUser, "CREATE " + userType.toUpperCase() + " USER",
//						"Could not create operator client.", "CREATE " + userType.toUpperCase() + " USER");
//				throw new UserCreationException("Could not create operator client. ");
//			}
//			
//			Roles roleResponse = null;
//			if (request.getRoleId() != null) {
//				roleResponse = userDataService.validateAssociateRole(request.getRoleId(), tokenUser);
//				if (roleResponse != null) {
//					userDataService.associateRoleToUser(roleResponse.getId(), savedUser.getId(), true, false,
//							crspNgHeaderToken, tokenUser);
//				}else {
//					LOGGER.error("Error occured while associating roleId "+request.getRoleId());
//					throw new UserCreationException("Invalid roleId passed. ");
//				}
//			}else {
//				LOGGER.info("Associating role to user.");
//				roleResponse = rolesDataService.findRoleByRoleName(CRSPNG_REMOTE_USER, tokenUser.getTenant_id());
//				userDataService.associateRoleToUser(roleResponse.getId(), savedUser.getId(), true, false, crspNgHeaderToken,
//						tokenUser);
//			}
//			if (roleResponse != null && "ng.role.remote_power_user".equals(roleResponse.getRoleName())) {
//				try {
//					LOGGER.info("Creating on demand site.");
//					userDataService.createOndemandSite(request.getEmail(), tokenUser, savedUser.getId(),
//							crspNgHeaderToken);
//				} catch (UserCreationException e) {
//					LOGGER.error("Error occured with exception {}", e);
//					LOGGER.error(
//							"Exception thrown from createUser() method in UserController. Could not create site for the user. ",
//							e.getMessage());
//					/*
//					 * List<String> userIds = new ArrayList<String>();
//					 * userIds.add(savedUser.getId());
//					 */
//					LOGGER.error("Calling userDataService.delete() method as site could not be created. User id: "
//							+ savedUser.getId());
//
//					userDataService.delete(Arrays.asList(savedUser.getId()), crspNgHeaderToken, true, tokenUser, true); // userDeletionFlow
//																														// deletes
//																														// operator
//																														// client
//																														// and
//																														// user
//																														// from
//																														// UAA
//					// Disassociating roles from user
//					LOGGER.error("Disassociating the user as site could not be created.");
//					userDataService.associateRoleToUser(roleResponse.getId(), savedUser.getId(), true, true,
//							crspNgHeaderToken, tokenUser);
//					commonService.logException(tokenUser, "CREATE " + userType.toUpperCase() + " USER",
//							"Could not create site for the user.", "CREATE " + userType.toUpperCase() + " USER");
//					throw new UserCreationException("Could not create site for the user. ");
//				}
//
//				try {
//					userDataService.createDefaultGrant(crspNgHeaderToken, savedUser.getId(), tokenUser);
//				} catch (UserCreationException e) {
//					LOGGER.error("Error occured with exception {}", e);
//					LOGGER.error(
//							"Exception thrown from createUser() method in UserController. Could not create grants for the user. ",
//							e.getMessage());
//					LOGGER.error("Calling userDataService.delete() method as grants could not be created. User id: "
//							+ savedUser.getId());
//					userDataService.delete(Arrays.asList(savedUser.getId()), crspNgHeaderToken, true, tokenUser, false); // userDeletionFlow
//																															// deletes
//																															// operator
//																															// client
//																															// and
//																															// user
//																															// from
//																															// UAA
//					// Disassociating roles from user
//					LOGGER.error("Disassociating the user as grants could not be created.");
//					userDataService.associateRoleToUser(roleResponse.getId(), savedUser.getId(), true, true,
//							crspNgHeaderToken, tokenUser);
//					commonService.logException(tokenUser, "CREATE " + userType.toUpperCase() + " USER",
//							"Could not create grants for the user.", "CREATE " + userType.toUpperCase() + " USER");
//					throw new UserCreationException("Could not create grants for the user. ");
//				}
//			}
//		}
//
//		// for system log
//		String eventSource = "USER: USER_ID: " + savedUser.getId() + ",USER_NAME: "
//				+ savedUser.getUserName().toUpperCase() + ",ACCOUNT_STATUS: " + savedUser.getAccountStatus()
//				+ ",OPERATION_STATUS: SUCCESS";
//		String eventDescription = "CREATE " + userType.toUpperCase() + " USER";
//		String deviceId = "";
//		auditUser(tokenUser, savedUser.getId(), "CREATE " + userType.toUpperCase() + " USER", eventSource,
//				eventDescription, deviceId);
//
//		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(savedUser.getId())
//				.toUri();
//		return ResponseEntity.created(location).build();
//	}
//
//	/**
//	 * This method is used to delete the user from table with requested id.
//	 *
//	 * @param userId
//	 * @param crspNgHeaderToken
//	 * @return
//	 */
//	@CrossOrigin
//	@DeleteMapping("/users")
//	@ResponseStatus(code = HttpStatus.NO_CONTENT)
//	@GranularEndPoint(name = "DELETE_USER", uri = "/users")
//	public @ResponseBody ResponseEntity<UserOrDeviceFailedDeleteListRootDto> deleteUser(
//			@RequestParam(value = "id", required = true) List<String> userIds,
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken,
//			@RequestParam(value = "force_delete", required = false) boolean forceDelete) {
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		/* Pep changes */
//		AuthzRequest authzRequest = new AuthzRequest.AuthzRequestBuilder(securityServiceConfig.getServiceNameForPep(),
//				securityServiceConfig.getUserCudForPep(), String.valueOf(tokenUser.getUser_id())).build();
//		String pepResponse = authorize(crspNgHeaderToken, authzRequest);
//		String userType = StringUtils.lowerCase(tokenUser.getEmail()).endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN)
//				? CrspngCommonsConstant.INTERNAL_USER : CrspngCommonsConstant.EXTERNAL_USER;
//		if (pepResponse != null && pepResponse.equals("Deny")) {
//			commonService.logException(tokenUser, "DELETE " + userType.toUpperCase() + " USER", "Unauthorized attempt!",
//					"DELETE " + userType.toUpperCase() + " USER");
//			throw new UserDeniedAuthorizationException("Unauthorized attempt!");
//		}
//		List<UserOrDeviceFailedDeleteList> failedList = null;
//		try {
//
//			failedList = userDataService.delete(userIds, crspNgHeaderToken, forceDelete, tokenUser, false);
//
//		} catch (UserDeletionException e) {
//			LOGGER.error("Error occured with exception {}", e);
//			LOGGER.error("Exception thrown from deleteUser() method in UserController. ", e.getMessage());
//			// throw new RuntimeException("Exception while deleting the user.
//			// ");
//			commonService.logException(tokenUser, "DELETE USER",
//					"Exception while deleting the user.", "DELETE " + userType.toUpperCase() + " USER");
//			throw new UserDeletionException("Exception while deleting the user. ");
//		}
//		if (CollectionUtils.isNotEmpty(failedList)) {
//			for (UserOrDeviceFailedDeleteList failedObj : failedList) {
//				userIds.remove(failedObj.getId());
//			}
//		}
//
//		// for system log
//		List<UsersEntity> user = userDataService.findUserDetailsByIds(userIds, tokenUser);
//		for (int i = 0; i < user.size(); i++) {
//			String eventSource = "USER: USER_ID: " + user.get(i).getId() + ",USER_NAME: "
//					+ user.get(i).getUserName().toUpperCase() + ",ACCOUNT_STATUS: " + user.get(i).getAccountStatus()
//					+ ",OPERATION_STATUS: SUCCESS";
//			String userTypeNew = StringUtils.lowerCase(user.get(i).getEmail()).endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN)
//					? CrspngCommonsConstant.INTERNAL_USER : CrspngCommonsConstant.EXTERNAL_USER;
//			String eventDescription = "DELETE " + userTypeNew.toUpperCase() + " USER";
//			String deviceId = "";
//			auditUser(tokenUser, user.get(i).getId(), "DELETE " + userTypeNew.toUpperCase() + " USER", eventSource,
//					eventDescription, deviceId);
//		}
//
//		if (CollectionUtils.isNotEmpty(failedList)) {
//			UserOrDeviceFailedDeleteListRootDto failedDeleteListRootDto = new UserOrDeviceFailedDeleteListRootDto();
//			failedDeleteListRootDto.setFailedDeleteList(failedList);
//			return new ResponseEntity<UserOrDeviceFailedDeleteListRootDto>(failedDeleteListRootDto, HttpStatus.OK);
//		} else {
//			return new ResponseEntity<UserOrDeviceFailedDeleteListRootDto>(HttpStatus.NO_CONTENT);
//		}
//	}
//
//	private void auditUser(TokenUser tokenUser, String userId, String operation, String eventSource,
//			String eventDescription, String deviceId) {
//		AuditDetails auditDetails = new AuditDetails();
//		auditDetails.setOperation_id(operation);
//		if (tokenUser.getUser_id() != null) {
//			auditDetails.setUser_id(tokenUser.getUser_id().toString());
//		}
//		if (tokenUser.getTenant_id() != null) {
//			auditDetails.setTenant_id(tokenUser.getTenant_id().toString());
//		}
//		// Need to be changed to Id
//		if (tokenUser.getRole() != null) {
//			auditDetails.setScopes(tokenUser.getRole());
//		}
//		String jsonId = "{\"user_id\":" + userId + "}";
//		auditDetails.setOperation_specific_info(jsonId);
//		// new fields
//		auditDetails.setOperation_status(CrspngOperationStatusEnum.SUCCESS.name());
//		auditDetails.setUser_role(userDataService.getRoleNameByEmailAndTenant(tokenUser));
//		auditDetails
//				.setUser_type(StringUtils.lowerCase(tokenUser.getEmail()).endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN)
//						? CrspngCommonsConstant.INTERNAL_USER : CrspngCommonsConstant.EXTERNAL_USER);
//		auditDetails.setCustomer_system("");
//		auditDetails.setCustomer_site("");
//		auditDetails.setDevice_id(deviceId);
//		auditDetails.setOrg_id(0L);
//		auditDetails.setProd_id(0L);
//		Span span = (Span) httpServletRequest.getAttribute(CrspngCommonsConstant.TRACE_ATTRIBUTE);
//		String traceId = Long.toHexString(span.getTraceId());
//		auditDetails.setRequest_id(traceId);
//
//		// system log fields
//		auditDetails.setUser_name(tokenUser.getUser_name());
//		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
//		String timeStamp = Long.toString(timestamp.getTime());
//		auditDetails.setTime(timeStamp);
//		auditDetails.setEvent_type(EventType.INFO.toString());
//		auditDetails.setEvent_source(eventSource);
//		auditDetails.setEvent_description(eventDescription);
//		auditDetails.setOriginating_action(OriginatingActionType.USER.toString());
//		auditDetails.setDevice_id(deviceId);
//		if (tokenUser.getSub_tenant_id() != null) {
//			auditDetails.setSub_tenant_id(tokenUser.getSub_tenant_id().toString());
//		} else {
//			auditDetails.setSub_tenant_id("");
//		}
//		auditDetails.setIsOnlySystemLog(false);
//
//		auditQueue.sendMessageToQueue(auditDetails, securityServiceConfig.getSqsURL());
//	}
//
//	@CrossOrigin
//	@PutMapping("/users")
//	@ResponseStatus(code = HttpStatus.NO_CONTENT)
//	@GranularEndPoint(name = "UPDATE_USER", uri = "/users")
//	public void updateUser(@RequestBody @Valid UpdateUserRequest updateUserRequest, BindingResult result,
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken) {
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		if (result.hasErrors()) {
//			commonService.logException(tokenUser, "UPDATE USER", "Payload argument exception", "UPDATE USER");
//			throw new PayloadArgumentException(result);
//		}
//		
//		String userType = StringUtils.lowerCase(tokenUser.getEmail()).endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN) ? CrspngCommonsConstant.INTERNAL_USER : CrspngCommonsConstant.EXTERNAL_USER;
//		AuthzRequest authzRequest = new AuthzRequest.AuthzRequestBuilder(
//				securityServiceConfig.getServiceNameForPep(), securityServiceConfig.getUserForPep(),
//				String.valueOf(tokenUser.getUser_id())).build();
//		String pepResponse = authorize(crspNgHeaderToken, authzRequest);
//		LOGGER.info("Accessable User Ids::: "+ pepResponse);
//		if (pepResponse != null && pepResponse.equals("Deny")) {
//			commonService.logException(tokenUser, "UPDATE " + userType.toUpperCase() + " USER", "Unauthorized attempt!",
//					"UPDATE " + userType.toUpperCase() + " USER");
//			throw new UserDeniedAuthorizationException("Unauthorized attempt!");
//		}
//		userDataService.updateSingleUser(updateUserRequest, tokenUser);
//
//		// for system log
//		UsersEntity user = userDataService.getUniqueUser(updateUserRequest.getId(), tokenUser);
//		String userType1 = StringUtils.lowerCase(user.getEmail()).endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN)
//				? CrspngCommonsConstant.INTERNAL_USER : CrspngCommonsConstant.EXTERNAL_USER;
//		String eventSource = "USER: USER_ID: " + user.getId() + ",USER_NAME: " + user.getUserName().toUpperCase()
//				+ ",ACCOUNT_STATUS: " + user.getAccountStatus() + ",OPERATION_STATUS: SUCCESS";
//		String eventDescription = "UPDATE " + userType1.toUpperCase() + " USER";
//		String deviceId = "";
//		auditUser(tokenUser, updateUserRequest.getId(), "UPDATE " + userType1.toUpperCase() + " USER", eventSource,
//				eventDescription, deviceId);
//	}
//
//	@CrossOrigin
//	@PutMapping("/users/update")
//	@ResponseStatus(code = HttpStatus.NO_CONTENT)
//	@GranularEndPoint(name = "UPDATE_USER", uri = "/users")
//	public void bulkUpdateUser(@RequestBody @Valid UpdateUserBulkRequest updateUserData, BindingResult result,
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken) {
//
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		if (result.hasErrors()) {
//			commonService.logException(tokenUser, "UPDATE USER", "Payload argument exception", "UPDATE USER");
//			throw new PayloadArgumentException(result);
//		}
//		String userType = StringUtils.lowerCase(tokenUser.getEmail()).endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN)
//				? CrspngCommonsConstant.INTERNAL_USER : CrspngCommonsConstant.EXTERNAL_USER;
//		AuthzRequest authzRequest = new AuthzRequest.AuthzRequestBuilder(securityServiceConfig.getServiceNameForPep(),
//				securityServiceConfig.getUserUpdateForPep(), String.valueOf(tokenUser.getUser_id())).build();
//		String pepResponse = authorize(crspNgHeaderToken, authzRequest);
//		if (pepResponse != null && pepResponse.equals("Deny")) {
//			commonService.logException(tokenUser, "UPDATE " + userType.toUpperCase() + " USER", "Unauthorized attempt!",
//					"UPDATE " + userType.toUpperCase() + " USER");
//			throw new UserDeniedAuthorizationException("Unauthorized attempt!");
//		}
//		List<String> pepUserIds=new ArrayList<>();
//		LOGGER.info("UserId pep response : "+pepResponse);
//		if(!"".equals(pepResponse) && pepResponse!=null) {
//			pepUserIds= Stream.of(pepResponse.split(","))
//										.map(String::trim)
//										.collect(Collectors.toList());
//		}
//		List<UserId> reqUserIds= updateUserData.getIds();
//		List<UserId> validUserIds= new ArrayList<>();
//		for (UserId userId : reqUserIds) {
//			if(pepUserIds.contains(userId.getId())) {
//				validUserIds.add(userId);
//			}
//		}
//		if(CollectionUtils.isNotEmpty(validUserIds)){
//			updateUserData.setIds(validUserIds);
//		}
//		List<String> buldUserIds = userDataService.bulkUpdateUser(updateUserData, tokenUser);
//		// for system log
//		for (int i = 0; i < buldUserIds.size(); i++) {
//			UsersEntity user = userDataService.getUniqueUser(buldUserIds.get(i), tokenUser);
//			String eventSource = null;
//			String eventDescription = null;
//			String deviceId = "";
//			if (updateUserData.getValidityPeriod() != null) {
//				eventSource = "USER: USER_ID: " + user.getId() + ",USER_NAME: " + user.getUserName().toUpperCase()
//						+ ",START_DATE: " + user.getStartDate() + ",EXPIRY_DATE: " + user.getExpiryDate()
//						+ ",OPERATION_STATUS: SUCCESS";
//				eventDescription = "UPDATE USER VALIDITY PERIOD";
//			} else {
//				eventSource = "USER: USER_ID: " + user.getId() + ",USER_NAME: " + user.getUserName().toUpperCase()
//						+ ",ACCOUNT_STATUS: " + user.getAccountStatus() + ",OPERATION_STATUS: SUCCESS";
//				eventDescription = "UPDATE USER STATUS TO " + user.getAccountStatus();
//			}
//			auditUserUpdate(tokenUser, buldUserIds.get(i), "UPDATE " + userType.toUpperCase() + " USER", eventSource,
//					eventDescription, deviceId);
//		}
//	
//	}
//
//	private void auditUserUpdate(TokenUser tokenUser, String userIds, String operation, String eventSource,
//			String eventDescription, String deviceId) {
//		AuditDetails auditDetails = new AuditDetails();
//		auditDetails.setOperation_id(operation);
//		if (tokenUser.getUser_id() != null) {
//			auditDetails.setUser_id(tokenUser.getUser_id().toString());
//		}
//		if (tokenUser.getTenant_id() != null) {
//			auditDetails.setTenant_id(tokenUser.getTenant_id().toString());
//		}
//		// Need to be changed to Id
//		if (tokenUser.getRole() != null) {
//			auditDetails.setScopes(tokenUser.getRole());
//		}
//		String jsonId = "{\"user_id\":" + userIds + "}";
//		auditDetails.setOperation_specific_info(jsonId);
//		// new fields
//		auditDetails.setOperation_status(CrspngOperationStatusEnum.SUCCESS.name());
//		auditDetails.setUser_role(userDataService.getRoleNameByEmailAndTenant(tokenUser));
//		auditDetails
//				.setUser_type(StringUtils.lowerCase(tokenUser.getEmail()).endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN)
//						? CrspngCommonsConstant.INTERNAL_USER : CrspngCommonsConstant.EXTERNAL_USER);
//		auditDetails.setCustomer_system("");
//		auditDetails.setCustomer_site("");
//		auditDetails.setDevice_id("");
//		auditDetails.setOrg_id(0L);
//		auditDetails.setProd_id(0L);
//		Span span = (Span) httpServletRequest.getAttribute(CrspngCommonsConstant.TRACE_ATTRIBUTE);
//		String traceId = Long.toHexString(span.getTraceId());
//		auditDetails.setRequest_id(traceId);
//
//		// system log fields
//		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
//		String timeStamp = Long.toString(timestamp.getTime());
//		auditDetails.setTime(timeStamp);
//		auditDetails.setEvent_type(EventType.INFO.toString());
//		auditDetails.setEvent_source(eventSource);
//		auditDetails.setEvent_description(eventDescription);
//		auditDetails.setOriginating_action(OriginatingActionType.USER.toString());
//		auditDetails.setDevice_id(deviceId);
//		auditDetails.setUser_name(tokenUser.getUser_name());
//		if (tokenUser.getSub_tenant_id() != null) {
//			auditDetails.setSub_tenant_id(tokenUser.getSub_tenant_id().toString());
//		} else {
//			auditDetails.setSub_tenant_id("");
//		}
//		auditDetails.setIsOnlySystemLog(false);
//		auditQueue.sendMessageToQueue(auditDetails, securityServiceConfig.getSqsURL());
//	}
//
//	@CrossOrigin
//	@PostMapping("/users/{user_id}/associate/{role_id}")
//	@GranularEndPoint(name = "CREATE_USER_ROLE_ASSOCIATION", uri = "/users/{user_id}/associate/{role_id}")
//	public @ResponseBody void associateRoles(@PathVariable("user_id") String usersId,
//			@PathVariable("role_id") Long roleId, @QueryParam("set_as_default_role") Boolean set_as_default_role,
//			@QueryParam("disassociate") Boolean disassociate,
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken) {
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		AuthzRequest authzRequest = new AuthzRequest.AuthzRequestBuilder(securityServiceConfig.getServiceNameForPep(),
//				securityServiceConfig.getUserCudForPep(), String.valueOf(tokenUser.getUser_id())).build();
//		String pepResponse = authorize(crspNgHeaderToken, authzRequest);
//		String audit = "ASSOCIATE ROLE TO USER";
//		if (null == disassociate) {
//			disassociate = Boolean.FALSE.booleanValue();
//		}
//		if ((disassociate == Boolean.TRUE.booleanValue())) {
//			audit = "DISSOCIATE ROLE FROM USER";
//		}
//		if (pepResponse != null && pepResponse.equals("Deny")) {
//			commonService.logException(tokenUser, audit, "Unauthorized attempt!", audit);
//			throw new UserDeniedAuthorizationException("Unauthorized attempt!");
//		}
//		if (grantFacadeImpl.checkAccountStatusAndValidity(usersId, tokenUser)) {
//			commonService.logException(tokenUser, audit, "User has expired. Could not give Roles.", audit);
//			throw new InvalidAccountStatus("User has expired. Could not give Roles.");
//		}
//
//		validateQueryparams(set_as_default_role, disassociate, tokenUser, audit);
//		if (!canBeAssociatedDissassociated(set_as_default_role, disassociate)) {
//			commonService.logException(tokenUser, audit, "Invalid role association or disassociation for User", audit);
//			throw new InvalidRoleAssociationException("Invalid role association or disassociation for User");
//		}
//
//		Roles roleResponseId = userDataService.getRolesById(roleId);
//		UserRole userRole = userRoleDao.findByUserAndRole(usersId, roleResponseId.getId(), tokenUser.getTenant_id());
//
//		if (isMindSphereToken(crspNgHeaderToken)) {
//			userDataService.associateRoleToMindspherUser(roleResponseId, usersId, set_as_default_role, disassociate,
//					crspNgHeaderToken, tokenUser);
//		}
//		// The below is commented since token is always of Mindsphere, never
//		// gets executed.
//		// else {
//		// userDataService.associateRoleToUser(roleResponseId.getId(), usersId,
//		// set_as_default_role, disassociate,
//		// crspNgHeaderToken, tokenUser);
//		// }
//		if (roleResponseId != null && "ng.role.remote_power_user".equals(roleResponseId.getRoleName()) && !disassociate
//				&& null == userRole) {
//			userDataService.defaultGrantsToOnDemandProductAndSite(crspNgHeaderToken, usersId, roleId, tokenUser);
//		}
//
//		// for system log
//		UsersEntity user = userDataService.getUniqueUser(usersId, tokenUser);
//		String eventSource = null;
//		String eventDescription = null;
//		String deviceId = "";
//		if (audit.equals("ASSOCIATE ROLE TO USER")) {
//			eventSource = "USER_ROLE_ASSOCIATE: USER_ID: " + user.getId() + ",USER_NAME: "
//					+ user.getUserName().toUpperCase() + ",ROLE_NAME: " + roleResponseId.getRoleName().toUpperCase()
//					+ ",OPERATION_STATUS: SUCCESS";
//			eventDescription = "ASSOCIATE ROLE TO USER";
//		} else {
//			eventSource = "USER_ROLE_DISASSOCIATE: USER_ID: " + user.getId() + ",USER_NAME: "
//					+ user.getUserName().toUpperCase() + ",ROLE_NAME: " + roleResponseId.getRoleName().toUpperCase()
//					+ ",OPERATION_STATUS: SUCCESS";
//			eventDescription = "DISSOCIATE ROLE FROM USER";
//		}
//		auditUser(tokenUser, usersId, audit, eventSource, eventDescription, deviceId);
//	}
//
//	private boolean isMindSphereToken(String mindsphereToken) {
//		DecodedJWT decode;
//		try {
//			decode = JWT.decode(mindsphereToken);
//		} catch (JWTDecodeException e) {
//			LOGGER.error(
//					"unable to decode token while checking is it mindsphere token in isMindSphereToken method, exception : {}",
//					e);
//			throw new UnauthorizedUserException("");
//		}
//		Map<String, Claim> claims = decode.getClaims();
//		if (claims.get("ten") != null) {
//			return true;
//		}
//		return false;
//	}
//
//	private void validateQueryparams(Boolean set_as_default_role, Boolean disassociate, TokenUser tokenUser,
//			String audit) {
//		if (null == set_as_default_role) {
//			commonService.logException(tokenUser, audit,
//					"Set_as_default_role is mandatory for Association or Disassociation", audit);
//			throw new DefaultFlagRequiredException(
//					"set_as_default_role is mandatory for Association or Disassociation");
//		}
//	}
//
//	private boolean canBeAssociatedDissassociated(boolean isDefaultRole, boolean isDisassociation) {
//		if (isDefaultRole && isDisassociation) {
//			return false;
//		}
//		return true;
//	}
//
//	@CrossOrigin
//	@GetMapping("/internal/users/{user_id}/roles")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public @ResponseBody GetRolesResponse getRoles(@PathVariable("user_id") String usersId,
//			@RequestHeader(value = TENANT_ID) String tenantId,
//			@RequestHeader(value = SUB_TENANT_ID) String subtenantId) {
//		TokenUser tokenUser = new TokenUser();
//		tokenUser.setTenant_id(StringUtils.stripToNull(tenantId));
//		tokenUser.setSub_tenant_id(StringUtils.stripToNull(subtenantId));
//		GetRolesResponse roles = userDataService.getRolesForUser(usersId, tokenUser);
//		return roles;
//	}
//
//	@CrossOrigin
//	@GetMapping("/users/internal/{role_id}/roles")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public @ResponseBody UserWithRoleResponse getRolesUserAssociation(@PathVariable("role_id") Long roleId) {
//		UserWithRoleResponse response = userDataService.getRolesWithRoled(roleId);
//		return response;
//	}
//
//	@CrossOrigin
//	@GetMapping("/users/internal/roles/{role_id}")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public @ResponseBody UserWithRoleResponse getUserRoles(@PathVariable("role_id") Long roleId) {
//		UserWithRoleResponse response = userDataService.getRolesWithRoled(roleId);
//		return response;
//	}
//
//	@CrossOrigin
//	@GetMapping("/internal/revoke")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	@ResponseStatus(code = HttpStatus.NO_CONTENT)
//	public void internalRevokeToken(@RequestParam("email") String email) {
//		userDataService.revokeTokenForUser(email);
//	}
//
//	@CrossOrigin
//	@GetMapping("/users/{user_id}/roles")
//	@GranularEndPoint(name = "GET_ROLES_FOR_USER", uri = "/users/{user_id}/roles")
//	public @ResponseBody PageResource<RolesResponse> getRoles(@PathVariable("user_id") String usersId,
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken,
//			@RequestParam(value = PAGE_NUMBER, required = true) Integer page,
//			@RequestParam(value = PAGE_SIZE, required = true) Integer size,
//			@RequestParam(value = SORT_PROPERTY, required = false) String sortProperty,
//			@RequestParam(value = SORT_ASCENDING, required = false) Boolean sortAsc) {
//
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		Page<RolesResponse> pageResult = userDataService.getPaginatedRolesPrivilegesForUser(usersId, page, size,
//				sortProperty, sortAsc, tokenUser);
//		return new PageResource<RolesResponse>(pageResult, PAGE_NUMBER, PAGE_SIZE);
//	}
//
//	private Roles getRole(Map<String, UserRole> rolesMap, String roleName) {
//		UserRole userRole = rolesMap.get(roleName);
//		if (userRole == null) {
//			// TODO: No where we are using
//			// return roleService.fetchRoleDetailsByName(roleName);
//		}
//		return userRole.getRoleId();
//	}
//
//	private boolean isAdmin(TokenUser tokenUser) {
//		if (tokenUser.getRole().contains("ds.user.create")) {
//			return true;
//		}
//		return false;
//	}
//
//	private boolean isRemoteUser(TokenUser tokenUser) {
//		if (tokenUser.getRole().contains("rdp.ondemandconnetivity.connect")) {
//			return true;
//		}
//		return false;
//	}
//
//	private Map<String, UserRole> getRolesMap(List<UserRole> userRoles) {
//		Map<String, UserRole> rolesMap = new HashMap<>();
//		for (UserRole userRole : userRoles) {
//			if (Arrays.asList(CRSPNG_REMOTE_USER, CRSPNG_TENANT_ADMIN).contains(userRole.getRoleId().getRoleName())) {
//				rolesMap.put(userRole.getRoleId().getRoleName(), userRole);
//			}
//		}
//		return rolesMap;
//	}
//
//	private List<String> mindsphereTokenRoles(TokenUser tokenUser) {
//		List<String> assignedRoles = new LinkedList<>();
//		if (isRemoteUser(tokenUser)) {
//			assignedRoles.add(CRSPNG_REMOTE_USER);
//		}
//		if (isAdmin(tokenUser)) {
//			assignedRoles.add(CRSPNG_TENANT_ADMIN);
//		}
//		return assignedRoles;
//	}
//
//	// TODO: Pass the tenantId from technical token
//	@CrossOrigin
//	@GetMapping("/internal/user/{userId}/role/{roleId}")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public Long getUserRoleIdForUserAndRole(@PathVariable("userId") String userId, @PathVariable("roleId") Long roleId,
//			@RequestHeader(value = TENANT_ID) String tenantId,
//			@RequestHeader(value = SUB_TENANT_ID) String subtenantId) {
//		// String tenantId = "";
//		return userRoleDao.findByUserAndRole(userId, roleId, tenantId).getUserRoleId();
//	}
//
//	@CrossOrigin
//	@RequestMapping(value = "/aggregatedusers", method = RequestMethod.GET)
//	@ResponseBody
//	@GranularEndPoint(name = "GET_USER", uri = "/users")
//	public PageResource<AggregatedPagingUserResponse> aggregatedUsers(
//			@RequestParam(value = "id", required = false) final List<String> idList,
//			@RequestParam(value = "fields", required = false) final List<UserFieldEnum> fields,
//			@RequestParam(value = "query", required = false) String query,
//			@RequestParam(value = PAGE_NUMBER, required = true) Integer page,
//			@RequestParam(value = PAGE_SIZE, required = true) Integer size,
//			@RequestParam(value = SORT_PROPERTY, required = false) String sortProperty,
//			@RequestParam(value = SORT_ASCENDING, required = false) Boolean sortAsc,
//			@RequestParam(value = REPORT, required = false) boolean report,
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken) {
//
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		AuthzRequest authzRequest = new AuthzRequest.AuthzRequestBuilder(securityServiceConfig.getServiceNameForPep(),
//				securityServiceConfig.getUserForPep(), String.valueOf(tokenUser.getUser_id())).build();
//		String pepResponse = authorize(crspNgHeaderToken, authzRequest);
//		if (pepResponse != null && pepResponse.equals("Deny")) {
//			throw new UserDeniedAuthorizationException("Unauthorized attempt!");
//		}
//		LOGGER.info("UserId pep response : "+pepResponse);
//		Page<AggregatedPagingUserResponse> pageResult = userDataService.findPaginatedData(fields, idList, query, page,
//				size, sortProperty, sortAsc, crspNgHeaderToken, report, tokenUser, false);
//		return new PageResource<AggregatedPagingUserResponse>(pageResult, PAGE_NUMBER, PAGE_SIZE);
//	}
//
//	@CrossOrigin
//	@GetMapping("/internal/userbilling")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public PageResource<AggregatedPagingUserResponse> getUserBilling(
//			@RequestParam(value = "id", required = false) final List<String> idList,
//			@RequestParam(value = "fields", required = false) final List<UserFieldEnum> fields,
//			@RequestParam(value = "query", required = false) String query,
//			@RequestParam(value = PAGE_NUMBER, required = true) Integer page,
//			@RequestParam(value = PAGE_SIZE, required = true) Integer size,
//			@RequestParam(value = SORT_PROPERTY, required = false) String sortProperty,
//			@RequestParam(value = SORT_ASCENDING, required = false) Boolean sortAsc,
//			@RequestParam(value = REPORT, required = false) boolean report,
//			@RequestHeader(value = TENANT_ID) String tenantId,
//			@RequestHeader(value = SUB_TENANT_ID) String subtenantId) {
//
//		TokenUser tokenUser = new TokenUser();
//		tokenUser.setTenant_id(StringUtils.stripToNull(tenantId));
//		tokenUser.setSub_tenant_id(StringUtils.stripToNull(subtenantId));
//		Page<AggregatedPagingUserResponse> pageResult = userDataService.findPaginatedData(fields, idList, query, page,
//				size, sortProperty, sortAsc, null, report, tokenUser, report);
//		return new PageResource<AggregatedPagingUserResponse>(pageResult, PAGE_NUMBER, PAGE_SIZE);
//	}
//
//	private void auditUserSwitchStatus(TokenUser tokenUser, String json, String operation, String eventSource,
//			String eventDescription, String deviceId) {
//		AuditDetails auditDetails = new AuditDetails();
//		auditDetails.setOperation_id(operation);
//		if (tokenUser.getUser_id() != null) {
//			auditDetails.setUser_id(tokenUser.getUser_id().toString());
//		}
//		if (tokenUser.getTenant_id() != null) {
//			auditDetails.setTenant_id(tokenUser.getTenant_id().toString());
//		}
//		// Need to be changed to Id
//		if (tokenUser.getRole() != null) {
//			auditDetails.setScopes(tokenUser.getRole());
//		}
//		auditDetails.setOperation_specific_info(json);
//		// new fields
//		auditDetails.setOperation_status(CrspngOperationStatusEnum.SUCCESS.name());
//		auditDetails.setUser_role(userDataService.getRoleNameByEmailAndTenant(tokenUser));
//		auditDetails
//				.setUser_type(StringUtils.lowerCase(tokenUser.getEmail()).endsWith(CrspngCommonsConstant.SIEMENS_DOMAIN)
//						? CrspngCommonsConstant.INTERNAL_USER : CrspngCommonsConstant.EXTERNAL_USER);
//		auditDetails.setCustomer_system("");
//		auditDetails.setCustomer_site("");
//		auditDetails.setDevice_id("");
//		auditDetails.setOrg_id(0L);
//		auditDetails.setProd_id(0L);
//		Span span = (Span) httpServletRequest.getAttribute(CrspngCommonsConstant.TRACE_ATTRIBUTE);
//		String traceId = Long.toHexString(span.getTraceId());
//		auditDetails.setRequest_id(traceId);
//
//		// system log fields
//		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
//		String timeStamp = Long.toString(timestamp.getTime());
//		auditDetails.setTime(timeStamp);
//		auditDetails.setEvent_type(EventType.INFO.toString());
//		auditDetails.setEvent_source(eventSource);
//		auditDetails.setEvent_description(eventDescription);
//		auditDetails.setOriginating_action(OriginatingActionType.USER.toString());
//		auditDetails.setDevice_id(deviceId);
//		if (tokenUser.getSub_tenant_id() != null) {
//			auditDetails.setSub_tenant_id(tokenUser.getSub_tenant_id().toString());
//		} else {
//			auditDetails.setSub_tenant_id("");
//		}
//		auditDetails.setIsOnlySystemLog(false);
//		auditQueue.sendMessageToQueue(auditDetails, securityServiceConfig.getSqsURL());
//	}
//
//	@CrossOrigin
//	@RequestMapping(value = "/users/{usergroups_id}/users", method = RequestMethod.GET)
//	@GranularEndPoint(name = "GET_USERGROUPS_FOR_USER", uri = "/users/{usergroups_id}/users")
//	@ResponseBody
//	public PageResource<UsergroupUsersResponse> getUsersForUserGroupId(@PathVariable("usergroups_id") Long usergroupId,
//			@RequestParam(value = PAGE_NUMBER, required = true) Integer page,
//			@RequestParam(value = PAGE_SIZE, required = true) Integer size,
//			@RequestParam(value = SORT_PROPERTY, required = false) String sortProperty,
//			@RequestParam(value = SORT_ASCENDING, required = false) Boolean sortAsc,
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken, @QueryParam(value = "query") String query) {
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		AuthzRequest authzRequest = new AuthzRequest.AuthzRequestBuilder(securityServiceConfig.getServiceNameForPep(),
//				securityServiceConfig.getUserCudForPep(), String.valueOf(tokenUser.getUser_id())).build();
//		String pepResponse = authorize(crspNgHeaderToken, authzRequest);
//		if (pepResponse != null && pepResponse.equals("Deny")) {
//			throw new UserDeniedAuthorizationException("Unauthorized attempt!");
//		}
//		Page<UsergroupUsersResponse> pageResult = userDataService.getUsersForUserGroupIdPaged(page, size, sortProperty,
//				sortAsc, usergroupId, crspNgHeaderToken, query, tokenUser);
//		return new PageResource<>(pageResult, PAGE_NUMBER, PAGE_SIZE);
//	}
//
//	@CrossOrigin
//	@GetMapping("/internal/roleusersmap")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public InternalRoleUsersMapper getRoleUsersMap(@RequestHeader(value = TENANT_ID) String tenantId,
//			@RequestHeader(value = SUB_TENANT_ID) String subtenantId) {
//		TokenUser tokenUser = new TokenUser();
//		tokenUser.setTenant_id(StringUtils.stripToNull(tenantId));
//		tokenUser.setSub_tenant_id(StringUtils.stripToNull(subtenantId));
//		return userDataService.getRoleUsersMap(tokenUser);
//	}
//
//	@CrossOrigin
//	@PostMapping("/users/{user_id}/switch_status")
//	@GranularEndPoint(name = "USER_SWITCH_ACCOUNT_STATUS", uri = "/users/{user_id}/switch_status")
//	public @ResponseBody void switchAccountStatus(@PathVariable("user_id") String usersId,
//			@RequestParam("status") String status, @RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken) {
//
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		AuthzRequest authzRequest = new AuthzRequest.AuthzRequestBuilder(securityServiceConfig.getServiceNameForPep(),
//				securityServiceConfig.getUserCudForPep(), String.valueOf(tokenUser.getUser_id())).build();
//		String pepResponse = authorize(crspNgHeaderToken, authzRequest);
//		if (pepResponse != null && pepResponse.equals("Deny")) {
//			commonService.logException(tokenUser, "WITHDRAW USER ACCESS", "Unauthorized attempt!",
//					"WITHDRAW USER ACCESS");
//			throw new UserDeniedAuthorizationException("Unauthorized attempt!");
//		}
//		userDataService.changeAccountStatusForUser(usersId, status, tokenUser);
//
//		// for system log
//		UsersEntity user = userDataService.getUniqueUser(usersId, tokenUser);
//		String eventSource = "USER_SWITCH_STATUS: USER_NAME: " + user.getUserName().toUpperCase() + ",SWITCH_STATUS: "
//				+ user.getAccountStatus() + ",OPERATION_STATUS: SUCCESS";
//		;
//		String eventDescription = "SWITCH USER STATUS TO " + user.getAccountStatus();
//		String deviceId = "";
//		auditUserSwitchStatus(tokenUser, "{\"user_id\":" + usersId + ", \"status\":" + "\"" + status + "\"" + "}",
//				"WITHDRAW USER ACCESS", eventSource, eventDescription, deviceId);
//	}
//
//	/**
//	 * Internal call Used for updating the userExpiry based on ExpiryDate will
//	 * be called by async scheduler 3 times a day.
//	 * 
//	 */
//	@CrossOrigin
//	@PostMapping("/users/internal/updateUserOnExpire")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public @ResponseBody void updateUserOnTokenExpire() {
//		// FIXME : Need to impliement once we get clarity on tecnical token
//		String technicalToken = httpServletRequest.getHeader(CrspngCommonsConstant.TECHNICAL_USER_TOKEN);
//		TokenUser tokenUser = tokenValidationService.getTenantDetails(technicalToken);
//		userDataService.updateUserOnExpire(tokenUser);
//	}
//
//	@CrossOrigin
//	@GetMapping("/users/internal/update")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public @ResponseBody void UpdateActiveRoleForUser(@RequestParam("email") String email,
//			@RequestParam("roleid") Long roleId, @RequestParam("userole") String userole,
//			@RequestHeader(value = TENANT_ID) String tenantId,
//			@RequestHeader(value = SUB_TENANT_ID) String subtenantId) {
//		TokenUser tokenUser = new TokenUser();
//		tokenUser.setTenant_id(StringUtils.stripToNull(tenantId));
//		tokenUser.setSub_tenant_id(StringUtils.stripToNull(subtenantId));
//		userDataService.updateUserForRole(email, roleId, userole, tokenUser);
//	}
//
//	/**
//	 * This method is used to update the touStatus for corresponding user
//	 * 
//	 * @param userId
//	 * @param touStatus
//	 */
//	@CrossOrigin
//	@PostMapping("/users/{user_id}/tou_status")
//	@ResponseStatus(HttpStatus.CREATED)
//	@GranularEndPoint(name = "GET_USERINFO", uri = "/users/{user_id}/tou_status")
//	public @ResponseBody ResponseEntity<String> updateUserTouStatus(
//			@PathVariable(value = "user_id", required = true) String userId,
//			@RequestParam(value = "status", required = true) UsersTermsUsageEnum touStatus) {
//
//		TokenUser tokenUser = (TokenUser) httpServletRequest.getAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER);
//		UsersEntity user = userRepository.findUserById(userId, tokenUser.getTenant_id());
//		checkAccountStatusAndValidity(user);
//		Span span = (Span) httpServletRequest.getAttribute(CrspngCommonsConstant.TRACE_ATTRIBUTE);
//		String traceId = Long.toHexString(span.getTraceId());
//		String auditOperationSpecificJson = "{\"user_id\":" + tokenUser.getUser_id() + "}";
//		if (userDataService.updateUserTouStatus(userId, touStatus, tokenUser)) {
//
//			// for system log
//			UsersEntity userDetails = userDataService.getUniqueUser(userId, tokenUser);
//			String eventSource = "USER_ACCEPTANCE: USER_ID: " + userDetails.getId() + ",USER_NAME: "
//					+ userDetails.getUserName().toUpperCase() + ",STATUS: " + touStatus.name().toUpperCase()
//					+ ",OPERATION_STATUS: SUCCESS";
//			;
//			String eventDescription = "USER " + touStatus.name().toUpperCase() + " TERMS AND CONDITIONS";
//			String deviceId = "";
//			// String eventType = EventType.INFO.toString();
//			// String originatingAction = "SYSTEM";
//			Boolean isOnlySystemLog = false;
//			auditQueue.commonAuditDetails(tokenUser, new JSONObject(auditOperationSpecificJson),
//					"USER " + touStatus.name().toUpperCase() + " TERMS AND CONDITIONS", "success", "", "", deviceId, 0L,
//					0L, traceId, securityServiceConfig.getSqsURL(), EventType.INFO, eventSource, eventDescription,
//					OriginatingActionType.USER, isOnlySystemLog);
//			return ResponseEntity.status(HttpStatus.CREATED).build();
//		} else {
//			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
//		}
//	}
//
//	@CrossOrigin
//	@GetMapping("/internal/getAllUserRoles/{userId}")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public UserRoleListRootResponseWrapper getAllUserRolesForUser(@PathVariable("userId") String userId) {
//		UserRoleListRootResponseWrapper response = new UserRoleListRootResponseWrapper();
//		response.setUserRoles(new ArrayList<UserRoleListL1ResponseWrapper>());
//		List<UserRole> userRoles = userRoleDao.getUserRoles(userId);
//		if (CollectionUtils.isNotEmpty(userRoles)) {
//			for (UserRole userRole : userRoles) {
//				UserRoleListL1ResponseWrapper responseL1 = new UserRoleListL1ResponseWrapper();
//				responseL1.setRoleId(userRole.getRoleId().getId());
//				responseL1.setUserRoleId(userRole.getUserRoleId());
//				response.getUserRoles().add(responseL1);
//			}
//		}
//		return response;
//	}
//
//	@CrossOrigin
//	@PostMapping("/users/internal/getUpdatedByUser")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	@ResponseStatus(HttpStatus.CREATED)
//	public @ResponseBody String getUpdatedByUser(@RequestBody TokenUser tokenUser) {
//		return userDataService.getUpdatedByUser(tokenUser);
//	}
//
//	@CrossOrigin
//	@GetMapping("/checkerror")
//	public @ResponseBody void geterror() {
//		throw new NullPointerException();
//	}
//	
//	@CrossOrigin
//	@GetMapping("/internal/users/{userId}")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public @ResponseBody GetUserCollection getUniqueUserDetailsInternal(@PathVariable(USERID) String userId,
//			@RequestHeader(value = CrspngCommonsConstant.TECHNICAL_USER_TOKEN) String crspNgHeaderToken) {
//		TokenUser tokenUser = tokenValidationService.getTenantDetails(crspNgHeaderToken);
//		UsersEntity user = userDataService.getUniqueUser(userId, tokenUser);
//		GetRolesResponse getRolesResponse = userDataService.getRolesForUser(userId, tokenUser);
//		List<AssignedRoleResponse> roles = null;
//		if (getRolesResponse != null) {
//			roles = getRolesResponse.getRoles();
//		}
//		GetUserCollection userResponse = new GetUserCollection(user, roles);
//		userDataService.getCreatedByandModifiedBy(userResponse, user, tokenUser);
//		return userResponse;
//	}
//
//	@CrossOrigin
//	@GetMapping("/users/internal/getUserConnectionDetails/{userId}")
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public @ResponseBody UserConnections getUserConnectionDetails(@PathVariable("userId") String userId,
//			@RequestHeader(value = TENANT_ID) String tenantId,
//			@RequestHeader(value = SUB_TENANT_ID) String subtenantId) {
//		TokenUser tokenUser = new TokenUser();
//		tokenUser.setTenant_id(StringUtils.stripToNull(tenantId));
//		tokenUser.setSub_tenant_id(StringUtils.stripToNull(subtenantId));
//		UsersEntity user = userDataService.getUniqueUser(userId, tokenUser);
//		UserConnections userConnections = new UserConnections();
//		userConnections.setMaxTunnel(user.getMaxTunnel());
//		userConnections.setExistingTunnelCount(user.getExistingTunnelCount());
//		return userConnections;
//	}
//
//	@CrossOrigin
//	@RequestMapping(value = "/internal/globalsearch", method = RequestMethod.GET)
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	@ResponseBody
//	public Page<Object> globalSearchUsersAndGroups(
//			@RequestParam(value = "category", required = false) final String category,
//			@RequestParam(value = "search_string", required = false) final String searchString,
//			@RequestParam(value = PAGE_NUMBER, required = true) Integer pageNumber,
//			@RequestParam(value = PAGE_SIZE, required = true) Integer pageSize,
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken) {
//		String technicalToken = httpServletRequest.getHeader(CrspngCommonsConstant.TECHNICAL_USER_TOKEN);
//		TokenUser userToken = tokenValidationService.getTenantDetails(technicalToken);
//		Page<Object> pageResult = (Page<Object>) userDataService.findPaginatedDataForGlobalSearch(category,
//				searchString, pageNumber, pageSize, crspNgHeaderToken, userToken);
//		// return pageResult;
//		return new PageResource<Object>(pageResult, PAGE_NUMBER, PAGE_SIZE);
//	}
//
//	@CrossOrigin
//	@RequestMapping(value = "/internal/expiredUserNotify", method = RequestMethod.POST)
//	@TechGranularEndPoint(name = "INTERNAL_TOKEN", uri = "/internal/token")
//	public @ResponseBody void expiredUserNotification() {
//		LOGGER.info("User controller:: expiredUserNotification:: START");
//		String technicalToken = httpServletRequest.getHeader(CrspngCommonsConstant.TECHNICAL_USER_TOKEN);
//		TokenUser user = tokenValidationService.getTenantDetails(technicalToken);
//		LOGGER.info("internal/expiredUserNotify: user data {}", user.toString());
//		userDataService.notifySoonToExpireUsers(user);
//		LOGGER.info("User controller:: expiredUserNotification:: END");
//	}
//
//	@CrossOrigin
//	@RequestMapping(value = "/internal/onboard", method = RequestMethod.POST)
//	public ResponseEntity<String> onBoard(@RequestParam("tenant") String tenant,
//			@RequestParam("operation") String operation) {
//		LOGGER.info("User controller:: onBoard:: START: {} {}", tenant, operation);
//		String response = "Invalid operation";
//		if (StringUtils.equalsIgnoreCase(operation, "create_user")) {
//			response = onBoardingService.createUser(tenant);
//		}
//		LOGGER.info("User controller:: onBoard:: END");
//		return ResponseEntity.ok(response);
//	}
//
//	@CrossOrigin
//	@GetMapping("/userinfo")
//	@GranularEndPoint(name = "GET_USERINFO", uri = "/userinfo")
//	public @ResponseBody GetUserInfoResponse fetchUserInfo(
//			@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken) {
//
//		TokenUser tokenUser = extractTokenUserForMS(crspNgHeaderToken);
//		httpServletRequest.setAttribute(CrspngCommonsConstant.OBJECT_TOKEN_USER, tokenUser);
//		LOGGER.info("TokenUser found to be in userinfo {}", tokenUser);
//
//		final UsersEntity user = userDataService.getUserByEmail(tokenUser.getEmail(), tokenUser);
//		GetUserInfoResponse userInfoResponse = null;
//
//		if (user == null) {
//			String mindsphereId = msUserServiceImpl.getUserIdForGivenEmail(tokenUser.getEmail(), tokenUser);
//
//			if (StringUtils.isEmpty(mindsphereId)) {
//				throw new InvalidUserException("Invalid User!");
//			}
//
//			CreateUserRequest request = new CreateUserRequest();
//			String[] split = tokenUser.getEmail().split("@");
//			String firstName;
//			String lastName;
//			if (split[0].contains(".")) {
//				firstName = split[0].substring(0, split[0].indexOf("."));
//				lastName = split[0].substring(split[0].indexOf(".") + 1);
//			} else {
//				firstName = split[0];
//				lastName = split[0];
//			}
//			request.setFirstname(firstName);
//			request.setLastname(lastName);
//			request.setEmail(tokenUser.getEmail());
//			request.setPhoneNumber("9999999999");
//			request.setDepartment("department");
//			request.setSiemensGid("gid");
//			request.setDuration(12);
//			if (!request.getEmail().endsWith("@siemens.com")) {
//				request.setBillingId("");
//			}
//			request.setAccountStatus(AccountStatusEnum.READY);
//			UsersEntity createdUser = createUser(request, crspNgHeaderToken, tokenUser);
//			return userDataService.getUserInfo(createdUser.getId(), crspNgHeaderToken, tokenUser);
//		} else {
//			checkAccountStatusAndValidity(user);
//
//			userInfoResponse = new GetUserInfoResponse();
//			List<OndemandData> ondemandDataList = new ArrayList<>();
//
//			userInfoResponse.setEmail(user.getEmail());
//			userInfoResponse.setFirstname(user.getFirstName());
//			userInfoResponse.setLastname(user.getLastName());
//			userInfoResponse.setTouStatus(user.getTouStatus());
//			Long nodeId = null;
//			// Pending getting site from data service
//			if (user.getOndemandSiteId() != null) {
//				nodeId = userDataService.findOneSite(user.getOndemandSiteId(), crspNgHeaderToken, tokenUser);
//			}
//			if (nodeId != null) {
//				ondemandDataList.add(new OndemandData(nodeId, user.getOndemandSiteId()));
//			}
//			userInfoResponse.setOndemandData(ondemandDataList);
//			userInfoResponse.setUserId(user.getId());
//		}
//
//		return userInfoResponse;
//	}
//
//	@GetMapping(GET_GENERIC_REPORT)
//	@ResponseBody
//	@ResponseStatus(HttpStatus.OK)
//	ResponseEntity<String> getGenericReport(@RequestHeader(value = ACCESS_TOKEN) String crspNgHeaderToken, @RequestHeader(value = "userId") String userId, @RequestHeader(value = "userName") String userName) {
//
//		LOGGER.info("getGenericReport start :: "+crspNgHeaderToken+ " &&& userId :: "+userId + ":: userName"+userName);
//		
//		String technicalToken = httpServletRequest.getHeader(CrspngCommonsConstant.TECHNICAL_USER_TOKEN);
//		LOGGER.info("getGenericReport technicalToken :: "+technicalToken);
//		TokenUser userToken = tokenValidationService.getTenantDetails(technicalToken);
//		
//		LOGGER.info("getGenericReport tokenUser :: "+userToken.getTenant_id());
//		AuthzRequest authzRequest = new AuthzRequest.AuthzRequestBuilder(securityServiceConfig.getServiceNameForPep(),
//				securityServiceConfig.getUserForPep(), String.valueOf(userId)).build();
//		LOGGER.info("getGenericReport authzRequest :: "+authzRequest);
//		String pepResponse = authorize(crspNgHeaderToken, authzRequest);
//
//		LOGGER.info("pepResponse :: "+pepResponse);
//
//		if (pepResponse != null && pepResponse.equals("Deny")) {
//			throw new UserDeniedAuthorizationException("Unauthorized attempt!");
//		}
//
//		LOGGER.info("pepResponse :: "+ pepResponse);
//		
//		List<String> ids = new ArrayList<>();
//		ids.addAll(Arrays.asList(pepResponse.split(",")));
//		
//		String s3BucketUrl = userDataService.getGenericReport(ids, userToken.getTenant_id(), userName);
//		
//		LOGGER.info("getGenericReport s3BucketUrl :: "+ s3BucketUrl);
//		return ResponseEntity.ok(s3BucketUrl);
//	}
//
//}
