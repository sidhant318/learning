package Tree;

import java.util.Arrays;

public class MinHeapImpl {
	private int capacity=10;
	private int size=0;
	int[] item=new int[capacity];
	
	private int leftChildIndex(int index) {
		return 2*index+1;
	}
	private int rightChildIndex(int index) {
		return 2*index+2;
	}
	private int parentIndex(int index) {
		return (index-1)/2;
	}
	
	private boolean hasleftChildIndex(int index) {
		return leftChildIndex(index)<size;
	}
	private boolean hasrightChildIndex(int index) {
		return rightChildIndex(index)<size;
	}
	private boolean hasparentIndex(int index) {
		return parentIndex(index)>=0;
	}
	
	private int leftChild(int index) {
		return item[leftChildIndex(index)];
	}
	private int rightChild(int index) {
		return item[rightChildIndex(index)];
	}
	private int parent(int index) {
		return item[parentIndex(index)];
	}
	
	public void swap(int data1,int data2) {
		int tmpvar=0;
		tmpvar=data1;
		data1=data2;
		data2=tmpvar;
	}
	private void extraCapacity() {
		if(size==capacity) {
			capacity=2*capacity;
			item=Arrays.copyOf(item, capacity);
		}
	}
	public int peek() {
		return item[0];
	}
	public int poll() {
		if(size==0)
			throw new IllegalStateException();
		int it=item[0];
		item[0]=item[size];
		size--;
		heapifyDown();
		return it;
	}
	private void heapifyDown() {
		int index=0;
		while(hasleftChildIndex(index)) {
			int num=leftChildIndex(index);
			if(hasrightChildIndex(index) && rightChild(index)<leftChild(index)) {
				num=rightChildIndex(index);
			}
			if(item[index]<item[num]) {
				break;
			}
			else {
				swap(index,num);
			}
			index=num;
		}
		
	}
	public void add(int data) {
		extraCapacity();
		item[size]=data;
		size++;
		heapifyUp();
	}
	private void heapifyUp() {
		int index=size-1;
		while(hasparentIndex(index) && parent(index)>item[index]) {
			System.out.println("P---"+parent(index));
			System.out.println("C---"+item[index]);
			swap(parent(index),item[index]);
			System.out.println(parent(index));
			index=parentIndex(index);
		}
		
	}
	public static void main(String[] args) {
		MinHeapImpl m=new MinHeapImpl();
		m.add(14);
		m.add(13);
//		m.add(10);
//		m.add(3);
//		m.add(7);
		System.out.println(m.peek());

	}

}
