package Tree;

class Node{
	int data;
	Node left,right;
	Node(int data){
		this.data=data;
		left=right=null;
	}
}

public class BinaryTree {
	
	Node root;

	public static void main(String[] args) {
		BinaryTree bt=new BinaryTree();
		bt.root=new Node(1);
		bt.root.left=new Node(2);
		bt.root.right=new Node(3);
		bt.root.left.left=new Node(4);
		bt.root.left.right=new Node(5);
		bt.insert(6);
		bt.insert(7);
		bt.insert(8);
		bt.delete(6);
		System.out.println("Count : "+bt.count());
		bt.print();
	}

	private void delete(int i) {
		deleteData(root,i);		
	}

	private void deleteData(Node root2, int i) {
		
		
	}

	private int count() {
		return countData(root);
	}

	private int countData(Node node) {
		if(node==null)
			return 0;
		else {
			int i=1;
			i+=countData(node.left);
			i+=countData(node.right);
			return i;
		}
	
	}

	private void insert(int data) {
		root=insertData(root,data);
	}

	private Node insertData(Node root2, int data) {
		
		if(root2==null) {
			System.out.println("hiii");
			root2=new Node(data);
		}
		else {
			if(root2.right==null)
				root2.right=insertData(root2.right,data);
			else
				root2.left=insertData(root2.left,data);
		}
		return root2;
	}

	private void print() {
		if(root==null)
			return;
		inorder(root);
		
	}

	private void inorder(Node n) {
		if(n!=null) {
			//System.out.println("------"+n.data);//pre order
			inorder(n.left);
//			System.out.println(n.data);//inorder
			inorder(n.right);
			System.out.println(n.data); //postorder
		}
		
	}

}
