import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class MyClass {
	public static void main(String[] a) {
		cal(20);
		//System.out.println((char)65);
	}
static void cal(int a) {
	Map<Character, Double> hm=new TreeMap<Character, Double>();
	Double x=(double) 0;
	for(int i=1;i<=26;i++) {
		x=x*i+i;
		hm.put((char)(64+i),x);
	}//
	System.out.println(hm.size());
	for(Map.Entry<Character, Double> m: hm.entrySet()) {
		System.out.println(m.getKey()+"----------"+m.getValue());
	}
	for(int i=0;i<26;i++) {
		//int x1=0;
		System.out.println(hm.get(i));
		//Double d=hm.get(i);
//		for(int j=i+1;j<26;j++) {
//			Double d1=hm.get(j);
//			d=d+d1;
//			if(a==d) {
//				System.out.println("hello");
//				break;
//			}
//		}
	}
}
}
