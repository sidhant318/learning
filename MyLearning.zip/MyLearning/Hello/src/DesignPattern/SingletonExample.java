package DesignPattern;

import java.lang.reflect.Constructor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Singleton implements Cloneable{
	private static Singleton obj;
	private Singleton() {
		
	}
	public static Singleton getInstance() {
		if(obj==null) {
			synchronized(Singleton.class)
			{
				if(obj==null) {
					obj=new Singleton();
				}
			}
			
		}
			
		System.out.println(obj.hashCode());
		return obj;
	}
	 void show() {
		System.out.println("hiii");
	}
}
public class SingletonExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Singleton s=Singleton.getInstance();
//		Singleton s1=Singleton.getInstance();
		
	
		ExecutorService e=Executors.newCachedThreadPool();
		for(int i=0;i<100;i++) {
			e.submit(()->{
				s.getInstance();
			});
			try {
				Thread.sleep(500);
			} catch (InterruptedException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		e.shutdown();
		//for(int i=0)
		//System.out.println(s1.hashCode());
	}

}
