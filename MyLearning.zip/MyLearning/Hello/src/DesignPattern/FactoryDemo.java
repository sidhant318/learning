package DesignPattern;

abstract class Computer{
	abstract String getBrand();
	abstract String getOwner();
	abstract String getType();
}

class Dell extends Computer{
	private String brandName;
	private String ownerName;
	private String type;
	public Dell(String brandName,String ownerName,String type) {
		this.brandName=brandName;
		this.ownerName=ownerName;
		this.type=type;
	}
	@Override
	String getBrand() {
		return brandName;
	}
	@Override
	String getOwner() {
		return ownerName;
	}
	@Override
	String getType() {
		return type;
	}
}

class Lanevo extends Computer{
	private String brandName;
	private String ownerName;
	private String type;
	public Lanevo(String brandName,String ownerName,String type) {
		this.brandName=brandName;
		this.ownerName=ownerName;
		this.type=type;
	}
	@Override
	String getBrand() {
		return brandName;
	}
	@Override
	String getOwner() {
		return ownerName;
	}
	@Override
	String getType() {
		return type;
	}
}

class factoryType{
	public static Computer getDetail(String brand,String brandName,String ownerName,String type) {
		if("DELL".equalsIgnoreCase(brand))
			return new Dell(brandName, ownerName, type);
		else if("Lanevo".equalsIgnoreCase(brand))
			return new Lanevo(brandName, ownerName, type);
		return null;
	}
	
}

public class FactoryDemo {

	public static void main(String[] args) {
		Computer laptop=factoryType.getDetail("DELL", "DELL", "SIDHANT", "LAPTOP");
		Computer mobile=factoryType.getDetail("Lanevo", "LANEVO", "MANISH", "MOBILE");
		System.out.println(laptop.getBrand());
		System.out.println(mobile.getBrand());
	}

}
