package DesignPattern;

import java.util.ArrayList;
import java.util.List;

class Employee implements Cloneable{
	private List<String> eList;
	Employee(){
		eList=new ArrayList<String>();
	}
	Employee(List<String> List){
		eList=List;
	}
	public void loadData() {
		eList.add("Sidhant");
		eList.add("Sidhu");
		eList.add("Sidharth");
	}
	public List<String> getData() {
		return eList;
	}
	public Object clone() throws CloneNotSupportedException {
//		List<String> tmp=new ArrayList<String>();
//		for(String data:this.getData()) {
//			tmp.add(data);
//		}
//		return new Employee(tmp);
		return super.clone();
	}
	
}




public class PrototypeTest {
	public static void main(String[] a) throws CloneNotSupportedException {
		Employee e=new Employee();
		e.loadData();
		Employee e1=(Employee)e.clone();
		List<String> l=e1.getData();
		l.add("Manish");
		System.out.println(e.getData());
		System.out.println(e1.getData());
		
	}

}
