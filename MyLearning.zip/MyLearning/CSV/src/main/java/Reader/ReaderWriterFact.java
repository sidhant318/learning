package Reader;

public class ReaderWriterFact {
	
	public static ReaderWriterFactory getInstance(String type,String fileName) {
		if(type.equalsIgnoreCase("CSV")) {
			System.out.println("Reader"+fileName);
			return new CSVReaderWriter(fileName);
		}else if(type.equalsIgnoreCase("EXL")){
			return new EXLReaderWriter(fileName);
		}
		else {
			return null;
		}
	}

}
