package Reader;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.CSVWriter;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.MappingStrategy;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;

public class OpenCSVParserExample {

	public static void main(String[] args) throws IOException  {
		//List<Employee> emps = parseCSVFileLineByLine();
		List<Employee> emps = readCSV();
		System.out.println(emps);
		//parseCsvToFile(emps);
	}

	private static List<Employee> readCSV() throws IOException {
		List<Employee> emps=new ArrayList<Employee>();
		BufferedReader bf=new BufferedReader(new FileReader("myFile.csv"));
		String line=bf.readLine();
		while((line=bf.readLine())!=null && !line.isEmpty()) {
			String[] record=line.split(",");
			Employee emp = new Employee();
			emp.setId(record[0]);
			emp.setName(record[1]);
			emp.setRole(record[2]);
			emp.setSalary(record[3]);
			emps.add(emp);
		}
		bf.close();
		return emps;
	}

	private static void parseCsvToFile(List<Employee> emps) throws IOException {
		String csv = "data.csv";
		try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(csv),
                StandardCharsets.UTF_8)) {

            StatefulBeanToCsv<Employee> beanToCsv = new StatefulBeanToCsvBuilder<Employee>(writer)
                    .withQuotechar(CSVWriter.NO_QUOTE_CHARACTER)
                    .build();
           beanToCsv.write(emps);

       } catch (Exception ex) {
         ex.printStackTrace();
	}
	}
	
	private static List<Employee> parseCSVFileLineByLine() {
		CSVParser csvParser = new CSVParserBuilder().withSeparator(',').build();
		List<Employee> emps = new ArrayList<>();

		try (CSVReader reader = new CSVReaderBuilder(new FileReader("myFile.csv")).withCSVParser(csvParser).build()) {
			String[] record = null;
			reader.readNext();
			while ((record = reader.readNext()) != null) {
				Employee emp = new Employee();
				emp.setId(record[0]);
				emp.setName(record[1]);
				emp.setRole(record[2]);
				emp.setSalary(record[3]);
				emps.add(emp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return emps;
	}

}
