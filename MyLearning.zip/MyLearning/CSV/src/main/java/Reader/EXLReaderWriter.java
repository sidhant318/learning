package Reader;

import java.util.List;

public class EXLReaderWriter extends ReaderWriterFactory{

	String fileName;
	public EXLReaderWriter(String fileName) {
		this.fileName=fileName;
	}
	@Override
	public List<Employee> readFile() {
		System.out.println(fileName);
		return null;
	}

	@Override
	public void writeFile(String fileName,List<Employee> emps){
		// TODO Auto-generated method stub
		
	}

}
