package Reader;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReaderWriterFactory fact=ReaderWriterFact.getInstance("CSV", "myFile.csv");
		List<Employee> emps=fact.readFile();
		System.out.println(emps);
		fact.writeFile("data.csv", emps);
	}

}
