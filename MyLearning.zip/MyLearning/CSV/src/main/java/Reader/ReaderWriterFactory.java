package Reader;

import java.util.List;

public abstract class ReaderWriterFactory {
	
	public abstract List<Employee> readFile();
	public abstract void writeFile(String fileName,List<Employee> emps);

}
