package apache;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import Reader.Employee;

public class BasicReaderWriter {
	private static final String FILE_HEADER="ID,Name,Role,Salary";
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		List<Employee> emps =readFile();
		System.out.println(emps);
		writeFile(emps);
	}

	private static void writeFile(List<Employee> emps) throws IOException {
		FileWriter fileWriter=null;
		CSVPrinter csvPrinter=null;
		CSVFormat csvFormat=CSVFormat.DEFAULT.withRecordSeparator("\n");
		try {
			fileWriter=new FileWriter("C:\\Users\\z003yn1j\\Desktop\\aaa.csv");
			csvPrinter=new CSVPrinter(fileWriter,csvFormat);
			csvPrinter.printRecord(FILE_HEADER);
			for(Employee e:emps) {
				List record=new ArrayList<>();
				record.add(e.getId());
				record.add(e.getName());
				record.add(e.getRole());
				record.add(e.getSalary());
				csvPrinter.printRecord(record);
			}
			System.out.println("Done...");
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		finally {
			fileWriter.close();
			csvPrinter.close();
		}
	}

	private static List<Employee> readFile() {
		List<Employee> emps = new ArrayList<Employee>();
		CSVParser csvParser =null;
		Reader reader = null;
		try {
			reader = Files.newBufferedReader(Paths.get("myFile.csv"));
			csvParser = new CSVParser(reader, CSVFormat.DEFAULT);
			for (CSVRecord csvRecord : csvParser) {
				Employee emp = new Employee();
				emp.setId(csvRecord.get(0));
				emp.setName(csvRecord.get(1));
				emp.setRole(csvRecord.get(2));
				emp.setSalary(csvRecord.get(3));
				emps.add(emp);
			}
		} catch (Exception e) {
			
		}
		finally {
			try {
				csvParser.close();
				reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return emps;
	}

}
